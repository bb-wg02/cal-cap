import dataset
import matplotlib.pyplot as plt
import numpy as np
from sklearn.calibration import LabelEncoder
from sklearn.pipeline import Pipeline
import sqlalchemy
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix
from sklearn.metrics import classification_report
import seaborn as sns
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import time
from sklearn.model_selection import learning_curve
import components.post_llm_input_processor as post_llm_input_processor
from sklearn.model_selection import GridSearchCV
import copy

EXP_NAME_KEY = 'exp_name'
INPUT_EXP_FILTER_KEY = 's2_input_exp_filter'
GAME_SESSION_FILER_KEY = 's2_game_session_filter'


CLASS_BIN = 'bin'
CLASS_MULTI = 'multi'
EXP_15s = '15 second v5'
EXP_30s = '30 second v4  decide again'
#My_C = 1
My_C = 1
#My_C = 10000000


db = dataset.connect('sqlite:///db.db')


class Model():
    def __init__(self, db):
        self.db = db
        self.mPostLLMUtils = post_llm_input_processor.PostLLMUtils()

    def get_data(self, exp_name, bin_or_multi, llm_stage_exp_filter, game_session_filter):
        X, y = self.mPostLLMUtils.get_data(self.db,exp_name, bin_or_multi, llm_stage_exp_filter, game_session_filter)
        return X, y

    def train_test_split(self, X, y, y_stratify_label):
        X_train,  X_test, y_train, y_test = self.mPostLLMUtils.train_test_split(X, y,y_stratify_label)
        # default is to use k-fold validation so no explicit valiation set created
        return X_train, y_train, X_test, y_test

    def save_trained_model(self):
        pass

    def restore_trained_model(self):
        pass


    def exec_train(self, params, exp_name, bin_or_multi, X_train, y_train):
        # scale
        scaler = StandardScaler()
    
        # Fit the scaler and transform the features
        X_trained_scaled = scaler.fit_transform(X_train, y_train)

        # instantiate model
        if bin_or_multi == CLASS_BIN:
            model_instance = LogisticRegression(solver='saga',max_iter = 800, C = params.C_binary, penalty= params.penalty_binary)
        else:
            model_instance = LogisticRegression(solver='saga',max_iter = 800, multi_class = 'multinomial',  C = params.C_multi, penalty= params.penalty_multi)
        
        # fit
        model_instance.fit(X_trained_scaled, y_train)

        return model_instance
        
            
    def exec_tune(self, params, bin_or_multi, X_train, y_train):

        # instantiate model
        if bin_or_multi == CLASS_BIN:
            model_instance = LogisticRegression(solver='saga',max_iter = 800, tol=0.1)            
        else:
            model_instance = LogisticRegression(solver='saga',max_iter = 800, multi_class = 'multinomial', tol = 0.1)
        
        # Define a Standard Scaler to normalize inputs
        scaler = StandardScaler()

        pipe = Pipeline(steps=[("scaler", scaler), ("logistic", model_instance)])

        param_grid = {                
                'logistic__penalty': ['l1', 'l2'],
                'logistic__C': [0.001, 0.01, 0.1, 1, 10, 100]}

        search = GridSearchCV(pipe, param_grid, n_jobs=2)
        search.fit(X_train, y_train)
        print("Best parameter (CV score=%0.3f):" % search.best_score_)
        print(search.best_params_)        

        # map the best parameters back a params object
        # return that to be used for a final training by calling function
        tuned_params = copy.deepcopy(params)
        if bin_or_multi == CLASS_BIN:
            tuned_params.penalty_binary= search.best_params_['logistic__penalty']
            tuned_params.C_binary= search.best_params_['logistic__C']
        else:
            tuned_params.penalty_multi= search.best_params_['logistic__penalty']
            tuned_params.C_multi= search.best_params_['logistic__C']

        return tuned_params
       
    def exec_predict(self, model_instance, X_unscaled):
        # scale
        scaler = StandardScaler()
    
        # Fit the scaler and transform the features
        X_scaled = scaler.fit_transform(X_unscaled)

        return model_instance.predict(X_scaled)

        
        
    def exec_report():
        pass

        
