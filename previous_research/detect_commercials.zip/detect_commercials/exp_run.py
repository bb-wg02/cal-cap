import pandas as pd
import os
import exec_llm_stage
import exec_post_llm_stage
import numpy as np
from loguru import logger as l
import neptune
import components.comm_detect_uitls as cd_utils

S1_RUN_ALL = 's1_all'
S1_RUN_S1 = 's1'
S1_RUN_RPT = 's1_rpt'

S2_RUN_TRAIN = 's2_train'
S2_RUN_TUNE = 's2_tune'
S2_RUN_PRED = 's2_predict'
S2_RUN_RPT = 's2_rpt'


EXP_FILTER_ACTIVE = 'active'

log_level = "DEBUG"
log_format = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS zz}</green> | <level>{level: <8}</level> | <yellow>Line {line: >4} ({file}):</yellow> <b>{message}</b>"
l.add(".\logs\info.log", level=log_level, format=log_format, colorize=False, backtrace=True, diagnose=True)

class ExpRunner():
    def handle_overrides(self,exp, s1_run_cd_override, chunk_filter_override, instr_filter_override,s2_run_cd_override):
        # passed in values from user supercede the experiment definition file        
        if s1_run_cd_override is not None: 
            cur_s1_run_cd = s1_run_cd_override
        else:
            cur_s1_run_cd = exp['s1_run_cd']

        if chunk_filter_override is not None: 
            cur_chunk_filter = chunk_filter_override
        else:
            cur_chunk_filter = exp['chunk_filter']

        if instr_filter_override is not None: 
            cur_instr_filter = instr_filter_override
        else:
            cur_instr_filter = exp['instr_filter']

        if s2_run_cd_override is not None: 
            cur_s2_run_cd = s2_run_cd_override
        else:
            cur_s2_run_cd = exp['s2_run_cd']

        return  cur_s1_run_cd, cur_chunk_filter, cur_instr_filter, cur_s2_run_cd
    


    def get_experiments(self, exp_source, exp_excel_filter):         
        # very hacky filter concept right now. 
        # will improve 
        exp_df =  pd.read_excel(exp_source)

        # should think harder about this blanket replacement
        exp_df = exp_df.replace(np.nan, None)

        if exp_excel_filter is None:
             return exp_df
        if exp_excel_filter == EXP_FILTER_ACTIVE:
             return exp_df.loc[exp_df['exp_active'] == 'y']
        else:
             # only other filter supported right now
             return exp_df.loc[exp_df['exp_name'] == exp_excel_filter]

             
             
    
    def exec(self, exp_source = '.\exp_definitions\experiments.xlsx', exp_excel_filter = EXP_FILTER_ACTIVE, s1_run_cd_override = None,\
              chunk_filter_override = None, instr_filter_override = None, s2_run_cd_override = None):
        # get list of experiments
        experiments = self.get_experiments(exp_source, exp_excel_filter)

        l.info("{} experiments to run", len(experiments.index))        
        exp_count = 1
        exp_fail_count = 0
        for index, exp in experiments.iterrows():            
            l.info("Starting experiment number {}", exp_count)
            try:
                nept_run = neptune.init_run(mode="debug")
                #nept_run = neptune.init_run(project='bb-4v/detect-comm-proto', api_token='eyJhcGlfYWRkcmVzcyI6Imh0dHBzOi8vYXBwLm5lcHR1bmUuYWkiLCJhcGlfdXJsIjoiaHR0cHM6Ly9hcHAubmVwdHVuZS5haSIsImFwaV9rZXkiOiIzMDQzNzcyZC01NzEyLTQzMWUtOWEyNy1lNjMzYTVjOTg0ZmEifQ==')
                nept_run["algorithm"] = "chatgpt"

                # log start of experiment                
                cur_s1_run_cd, cur_chunk_filter, cur_instr_filter, cur_s2_run_cd = self.handle_overrides(exp, s1_run_cd_override, \
                                                                                                    chunk_filter_override, instr_filter_override, s2_run_cd_override)
                
                # execute stage 1 as appropriate
                
                if (cur_s1_run_cd == S1_RUN_ALL ) or (cur_s1_run_cd == S1_RUN_S1):   
                    l.debug("Starting LLM Stage for experiment number {} , name: {}", exp_count, exp['exp_name'])
                    p_inc_prev_blocks = exp['s1_inc_prev_blocks'] == "y"
                    if exp['s1_num_prev_blocks'] is not None:
                        p_num_prev_blocks = int(exp['s1_num_prev_blocks'])
                    else:
                        p_num_prev_blocks = 0
                    cur_llm_stage_params = exec_llm_stage.LLMStageParams(exp_name=exp['exp_name'],  stat_loc=exp['s1_stat_loc'], inc_prev_answer=exp['s1_inc_prev_answer'], \
                                                                    prev_ans_loc=exp['s1_prev_ans_loc'], inc_sample_data=exp['s1_inc_sample_data'], \
                                                                        sample_data_loc=exp['s1_sample_data_loc'], inc_prev_blocks=p_inc_prev_blocks, \
                                                                            num_prev_blocks=p_num_prev_blocks, prev_block_loc=exp['s1_prev_block_loc'], sleep_time=exp['s1_sleep_time'])
                    cd_utils.CommDetectUtils.nept_send_params(nept_run, "s1_model/parameters", cur_llm_stage_params)
                    cur_llm_stage = exec_llm_stage.LLMStage(cur_llm_stage_params, cur_chunk_filter, cur_instr_filter)
                    cur_llm_stage.exec(nept_run)
                if (cur_s1_run_cd == S1_RUN_ALL ) or (cur_s1_run_cd == S1_RUN_RPT):
                    l.debug("Starting LLM REPORT Stage for experiment number {} , name: {}", exp_count, exp['exp_name'])
                    cur_llm_stage_params = exec_llm_stage.LLMStageParams(exp_name=exp['exp_name'],  stat_loc=exp['s1_stat_loc'])
                    cur_llm_stage = exec_llm_stage.LLMStage(cur_llm_stage_params, cur_chunk_filter, cur_instr_filter)
                    cur_llm_stage.update_stats_and_eval(nept_run)

                # similar structure for stage2 
                if (cur_s2_run_cd == S2_RUN_TRAIN):                 
                    l.debug("Starting Post LLM Train Stage for experiment number {} , name: {}", exp_count, exp['exp_name'])
                    cur_post_llm_stage_params = exec_post_llm_stage.PostLLMStageParams(exp)
                    cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model/parameters", cur_post_llm_stage_params)
                    cur_post_llm_stage = exec_post_llm_stage.PostLLMStage(cur_post_llm_stage_params )
                    trained_bin_loc, trained_multi_loc = cur_post_llm_stage.exec_train_and_save(nept_run)

                if (cur_s2_run_cd == S2_RUN_TUNE):                 
                    l.debug("Starting Post LLM Tune Stage for experiment number {} , name: {}", exp_count, exp['exp_name'])
                    cur_post_llm_stage_params = exec_post_llm_stage.PostLLMStageParams(exp)
                    cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model/parameters", cur_post_llm_stage_params)
                    cur_post_llm_stage = exec_post_llm_stage.PostLLMStage(cur_post_llm_stage_params )
                    cur_post_llm_stage.exec_tune(nept_run)

                if (cur_s2_run_cd == S2_RUN_PRED):                 
                    l.debug("Starting Post LLM Predict for experiment number {} , name: {}", exp_count, exp['exp_name'])
                    cur_post_llm_stage_params = exec_post_llm_stage.PostLLMStageParams(exp_name=exp['exp_name'])
                    cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model/parameters", cur_post_llm_stage_params)
                    cur_post_llm_stage = exec_post_llm_stage.PostLLMStage(cur_post_llm_stage_params )
                    cur_post_llm_stage.predict(nept_run)

                if (cur_s2_run_cd == S2_RUN_RPT):                 
                    l.debug("Starting Post LLM Report for experiment number {}", exp_count)
                    cur_post_llm_stage_params = exec_post_llm_stage.PostLLMStageParams(exp_name=exp['exp_name'])
                    cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model/parameters", cur_post_llm_stage_params)
                    cur_post_llm_stage = exec_post_llm_stage.PostLLMStage(cur_post_llm_stage_params )
                    cur_post_llm_stage.report(nept_run)

            finally:
                nept_run.stop()            
            exp_count += 1
            


if __name__ == "__main__":        
    # do some testing manually
    l.info("Starting Experiment Runner")    
    experiment_runner = ExpRunner() 
    experiment_runner.exec()
    l.success("Ending Experiment Runner")    
