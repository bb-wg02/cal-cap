import dataset
import matplotlib.pyplot as plt
import numpy as np
from sklearn.calibration import LabelEncoder
from sklearn.pipeline import Pipeline
import sqlalchemy
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix, recall_score, precision_score,f1_score
from sklearn.metrics import classification_report
import seaborn as sns
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import time
from sklearn.model_selection import learning_curve
import json
from loguru import logger as l
import accuracy_metrics
import copy

class LLMStageEval():
    @staticmethod
    def eval_accuracy(exp_name, nept_run, actual_binary, pred_binary, actual_multi, pred_multi):       
        accuracy_metrics.AccuracyMetrics.eval_accuracy_detail(exp_name, 'llm_stage', nept_run, 'binary', actual_binary, pred_binary)
        #accuracy_metrics.AccuracyMetrics.eval_accuracy_detail(exp_name, 'llm_stage', nept_run, 'multi', actual_multi, pred_multi)

    def trim_prev_records(self,prev_records, desired_list_size):
        # delete from end of list forward until length equals desired list size        
        while len(prev_records) > desired_list_size:
            _ = prev_records.pop(0)            
            

    def are_all_window_values_different(self,prev_records,cur_rec, value_field, cur_window_value, window_size):        
        # if current_window_value is None return False
        # sanity check (edge case of starting window_size-1 records)
        # if in edge case and invalid to look for earlier slots in window decrement window length in the loop
        # Loop thru window and compare each value to current window value
        if cur_window_value is None:
            return True # At start of processing won't have an initial state so this will tell it to use first value as state
        
        if len(prev_records) < window_size:
            usable_window_size = len(prev_records) + 1
        else:
            usable_window_size = window_size

        all_diff_so_far = None        
        # todo: review thought process about deepcopy here
        sequenced_records = copy.deepcopy(prev_records)
        sequenced_records.append(cur_rec)
        window_slot_cntr = 1
        while window_slot_cntr <= usable_window_size:
            # start from the latest value and work backwards unto the usable window
            window_pointer = len(sequenced_records) - window_slot_cntr
            w_rec = sequenced_records[window_pointer]
            cur_is_diff = w_rec[value_field]  != cur_window_value[value_field]
            if all_diff_so_far is None:
                all_diff_so_far = cur_is_diff
            else: 
                all_diff_so_far = all_diff_so_far and cur_is_diff
            if not all_diff_so_far:
                break
            window_slot_cntr += 1
        if all_diff_so_far is None:
            raise Exception("no records in window while trying to check if all values are different in window")
        
        # GC should clean this. I should not have to release the list - take this line out
        sequenced_records = None
        return all_diff_so_far



        
    def calc_block_window_states(self,sequenced_records, id_field, value_field, window_size = 2):
        window_values = []
        prev_records = []
        cur_window_value  = None        
        for cur_rec in sequenced_records:
            all_diff = self.are_all_window_values_different(prev_records, cur_rec, value_field, cur_window_value, window_size)            
            if all_diff:
                # set new status                
                cur_window_value = cur_rec
            window_rec = {}            
            window_rec["id"] = cur_rec[id_field]
            window_rec["value"] = cur_window_value[value_field]
            # todo: hack - now assuming passed in data has llm_predict_id column. imrpove
            window_rec["llm_predict_id"] = cur_rec["llm_predict_id"]
            window_values.append(window_rec)    
            #l.info('\n Id: {}, Rec value: {}, Value for the Window It Is In: {}',window_rec["id"] , cur_rec[value_field], window_rec["value"] )               

            # Because assuming sequenced_records is not a structure I can go backwards in 
            # capture rolling list of previous records
            # Note: if window size is 3, then only want two records in the prev_records list by end of a loop iteration
            # because the prev_records is passed in with the cur_record for each comparision. Want that to equal 3.
            if len(prev_records) >= (window_size -1):
                self.trim_prev_records(prev_records, window_size - 1)
            prev_records.append(cur_rec)
        
        return window_values
