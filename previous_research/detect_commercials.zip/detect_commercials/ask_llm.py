import json
import requests
from loguru import logger as l
import arrow
from time import sleep
import copy
import dataset
import nltk
from nltk import download as nltk_download
import math

# this download process here seems a hack and hard to share code now?
# workarounds on stackechange didn't work
nltk_download('punkt')

# CONFIG VALUES AS CONSTANTS FOR NOW. MOVE TO CMD LINE OR CONFIG LATER.
DATA_LABEL = 'data part 1: '
strict_mode = False
llm_invalid_responses = 0


if strict_mode:
    LLM_API_FAIL_LIMIT = 5
    LLM_INVALID_RESPONSE_LIMIT = 10
else:
    LLM_API_FAIL_LIMIT = 10
    LLM_INVALID_RESPONSE_LIMIT = 100
LLM_CHIP_RECOMBINE = "llm_chip_recombine"
LLM_SINGLE_CALL = "llm_single_call"

# hack - using index of the tuple
FIRST_HALF_CHIPS = 0
SECOND_HALF_CHIPS = 1

class ChatGPT(object):
    def __init__(self, input_instructions, input_block, llm_exp_name):
        
        self.is_valid = None
        self.classification_code = None
        self.response = None
        self.response_json = None
        self.instructions = input_instructions
        self.block = input_block
        self.bearer_key = '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'
        self.endpoint = "https://api.openai.com/v1/chat/completions"
        # self.model = 'gpt-4-1106-preview'
        #self.model = 'gpt-4-turbo-preview'
        self.model = 'gpt-4-turbo'
        #self.model = 'gpt-3.5-turbo' 
        self.temp = 0.3
        self.start_requests = arrow.now().to('US/Central').datetime
        self.get_gpt_response()
        self.stop_requests = arrow.now().to('US/Central').datetime
        self.llm_exec_time = (self.stop_requests - self.start_requests).microseconds
        self.fully_formed_requests = '"' + self.instructions['instr_text'] + '\n\n' + self.block['cur_chunk'] + '"'
        self.category = self.response_json['choices'][0]['message']['content']
        self.llm_exp_name = llm_exp_name
        self.eval_response()

    def get_class_num(self, class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 2
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 3
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 4
        elif class_code == 'OTHER':
            return 5
        
    def get_class_c(self, class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 1
        elif class_code == 'OTHER':
            return 0

    def eval_response(self):
        response_map = dict()
        response_map['Commercial'] = 'COMMERCIAL'
        response_map['Sports Broadcast'] = 'SPORTS_BROADCASTING'
        # gave an extra space at end a few times
        response_map['Sports Broadcast '] = 'SPORTS_BROADCASTING'
        
        response_map['Sports Broadcast Followed By A Commercial'] = 'SPORTS_BROADCASTING-TO-COMMERCIAL'
        response_map['Commercial Then A Second Commercial'] = 'COMMERCIAL-TO-ANOTHER COMMERCIAL'
        response_map['Commercial Followed By A Sports Broadcast'] = 'COMMERCIAL-TO-SPORTS_BROADCASTING'
        #response_map['Not a Commercial and not a Sports Broadcast'] = 'OTHER'
        response_map['Something Else'] = 'OTHER'

        try:
            self.is_valid = True
            self.classification_code = response_map[self.category.replace('"', '').replace("'", '')]     
            # weird formatting cases                   
        except KeyError:
            fix_found = False
            if self.category == "'Sports Broadcast'":
                self.classification_code = 'SPORTS_BROADCASTING'
                fix_found = True
            if self.category == "'Something Else'":
                self.classification_code = 'OTHER' 
                fix_found = True  
            if not fix_found:
                global llm_invalid_responses
                llm_invalid_responses += 1
                if llm_invalid_responses > LLM_INVALID_RESPONSE_LIMIT:
                    exc_str = f'Too many invalid responses: {llm_invalid_responses}'
                    llm_invalid_responses = 0
                    raise Exception(exc_str)
                    
                self.is_valid = False

    @property
    def db_output(self):
        output = dict()
        output['instr_prompt_used_name'] = self.instructions['instr_name']
        output['instr_prompt_used_text'] = self.instructions['instr_text']
        output['cur_block_id_used'] = self.block['block_id']
        output['text_chunk_used'] = self.block['cur_chunk']
        output['llm_name'] = self.model
        output['llm_other_params'] = self.temp
        output['fully_formed_request'] = self.fully_formed_requests
        output['requested_at'] = self.start_requests
        output['response_is_valid'] = self.is_valid
        output['response_text'] = self.category
        output['response_classification'] = self.classification_code
        output['response_at'] = self.stop_requests
        output['llm_exec_time'] = self.llm_exec_time
        output['input_tokens'] = self.response_json['usage']['prompt_tokens']
        output['output_tokens'] = self.response_json['usage']['completion_tokens']
        output['code'] = self.response_json['choices'][0]['finish_reason']
        output['llm_exp_name'] = self.llm_exp_name
        output['response_classification_num'] = self.get_class_num(self.classification_code)
        output['response_classification_c'] = self.get_class_c(self.classification_code)

        #print(output['text_chunk_used'])
        #print(output['response_classification'])
        if output['code'] != 'stop':
            global llm_api_failures
            llm_api_failures += 1
            sleep(min(60,12*llm_api_failures))
            if llm_api_failures > LLM_API_FAIL_LIMIT:
                exc_str = f"Too many api failures: {llm_api_failures}"
                llm_api_failures = 0
                raise Exception(exc_str)
        return output

    def get_gpt_response(self):
        headers = {
            "Authorization": f"Bearer {self.bearer_key}",
            "Content-Type": "application/json",
            "User-Agent": "OpenAI Python Client",
        }

        data = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": self.instructions['instr_text']},
                {"role": "user", "content": DATA_LABEL + ' ' +  self.block['cur_chunk']},
            ],
            "temperature": self.temp
        }

        response = requests.post(self.endpoint, headers=headers, data=json.dumps(data))
        # Hacky way of trying twice with sleep delays before giving up to other logic to decide next step
        if response.status_code != 200:
            l.error("API Call failed: {}, {}", response.status_code, response.text)
            l.error("Will sleep 10 seconds and try again")
            sleep(10)
            response = requests.post(self.endpoint, headers=headers, data=json.dumps(data))
            if response.status_code != 200:
                l.error("API Call failed: {}, {}", response.status_code, response.text)
                l.error("Will sleep 10 seconds and try again")
                sleep(10)
                response = requests.post(self.endpoint, headers=headers, data=json.dumps(data))

        if response.status_code != 200:
            raise ValueError(f"API call failed with status code {response.status_code}: {response.text}")
        else:
            self.response = response
            try:
                self.response_json = response.json()
            except Exception as ERR:
                l.error(ERR)

class NLTools():
    def get_sentences_from_block(self,block):
        sentences = nltk.sent_tokenize(block["cur_chunk"])        
        # check for issues with result
        return sentences, len(sentences)

    def get_sentences_from_text(self,text):
        sentences = nltk.sent_tokenize(text)        
        # check for issues with result
        return sentences, len(sentences)

class AskLLM():
    def __init__(self, db, state_mapping, approach):
        self.db = db
        self.approach = approach
        self.state_mapping = state_mapping

    def merge_blocks(self, block, prev_blocks):
        input_block_text = block['cur_chunk']
        for a_prev_block in prev_blocks:
            # should I add a blank space?
            input_block_text = a_prev_block['cur_chunk'] + ' ' + input_block_text 
        input_block = copy.copy(block)
        input_block['cur_chunk'] = input_block_text
        return input_block

    def single_block(self, block):
        input_block = copy.copy(block)
        return input_block

    def get_chip_section_breaks(self, section_pct, sent_count, overlap_mode):
        if sent_count == 0:
            return None,None,None,None
        if section_pct == 1:
            return 0, sent_count, None, None
        if sent_count == 1:
            if overlap_mode:
                return 0,1,0,1
            else:
                return 0,1,None, None
            
        section_break = section_pct*sent_count
        sect1_start = 0
        sect1_end = math.ceil(section_break)        
        if sect1_end == section_break:
            # does divide evenly
            # so sections will be precise percentage requested            
            sect2_start = sect1_end
        elif overlap_mode:
            # does not divide evenly and IS overlap mode
            sect2_start = sect1_end-1
        else:
            # does not divide evenly and IS NOT overlap mode
            sect2_start = sect1_end

        sect2_end = sent_count
        return sect1_start, sect1_end, sect2_start, sect2_end
                                     
    def copy_part_of_block(self,block, sentences, s_start, s_end):
        sec_block = copy.copy(block)
        chunk_so_far = ""
        for i in range(s_start, s_end):
            # subtle thing here. I am adding a space back in but I think
            # nltk does not handle spaces consisently in what it reads and returns
            # will this impact LLM?
            chunk_so_far = chunk_so_far + " " + sentences[i]        
        sec_block["cur_chunk"] = chunk_so_far
        return sec_block

    def chip_block(self,block, prev_blocks, sect1_pct = 0.5, overlap_mode=False):        

        # not implementing prev_blocks yet

        nlt = NLTools()        
        sentences, sent_count = nlt.get_sentences_from_block(block)
        if sect1_pct == 1:
            sect1_block = copy.copy(block)
            return sect1_block, None

        if (sent_count == 0) or (sent_count == 1):              
                sect1_block = copy.copy(block)
                sect2_block = None
        else:
            s1b_start, s1b_end, s2b_start,s2b_end = self.get_chip_section_breaks(sect1_pct, sent_count, overlap_mode)
            sect1_block = self.copy_part_of_block(block, sentences, s1b_start, s1b_end)            
            sect2_block = self.copy_part_of_block(block, sentences, s2b_start, s2b_end)                        

        return sect1_block, sect2_block                

    def chip_merge(self,df1, df2, df3, df4):
        pass


    def one_chip_classify(self, full_instr, block, prev_blocks, exp_name):
        if block is None:
            #l.debug("one_chip_classify() asked to classify a null block. skipping and returning none")
            return None
        if prev_blocks is None:
            block = self.single_block(block)                        
        else:
            block = self.merge_blocks(block, prev_blocks)        
        sleep(0.05)        
        ai_data = ChatGPT(full_instr, block, exp_name)   
        return ai_data
    
    def chips_classify(self, full_instr, a_chip_blocks, exp_name):
        # pair of chips to classify
        first_prediction = self.one_chip_classify(full_instr, a_chip_blocks[0], None, exp_name)
        second_prediction = self.one_chip_classify(full_instr, a_chip_blocks[1], None, exp_name)
        return first_prediction, second_prediction
    
    def chip_vote(self,all_chips, which_half_index):
        votes = {}
        votes['COMMERCIAL'] = 0
        votes['SPORTS_BROADCASTING'] = 0
        votes['SPORTS_BROADCASTING-TO-COMMERCIAL'] = 0
        votes['COMMERCIAL-TO-ANOTHER COMMERCIAL'] = 0
        votes['COMMERCIAL-TO-SPORTS_BROADCASTING'] = 0
        votes['OTHER'] = 0

        v_one_chip_half = all_chips['one_chip_ai_data'][which_half_index] 
        v_50_50_chips_half = all_chips['50_50_chips_ai_data'][which_half_index]
        v_75_25_chips_half = all_chips['75_25_chips_ai_data'][which_half_index]
        v_25_75_chips_half = all_chips['25_75_chips_ai_data'][which_half_index]

        if v_one_chip_half is not None:
            votes[v_one_chip_half.classification_code] +=1
        if v_50_50_chips_half is not None:
            votes[v_50_50_chips_half.classification_code] +=1
        if v_75_25_chips_half is not None:
            votes[v_75_25_chips_half.classification_code] +=1        
        if v_25_75_chips_half is not None:
            votes[v_25_75_chips_half.classification_code] +=1
        
        # don't choose 'OTHER' unless one_chip is also 'OTHER'
        if (v_one_chip_half is not None) and (v_one_chip_half.classification_code != 'OTHER'):
            # clear other
            votes['OTHER'] = 0

        max_key = max(votes, key=lambda k: votes[k])
        max_value = votes[max_key]
        if max_value == 0:
            return None, None
        else:            
            return max_key, max_value
      

    def get_chip_final_response(self, first_half_prediction, second_half_prediction):        
        if first_half_prediction is None:
            raise Exception('No prediction produced from chip approach')

        if second_half_prediction is None:
            return first_half_prediction
        else:
            return self.state_mapping.loc[(self.state_mapping['first_half'] == first_half_prediction) & \
                          (self.state_mapping['second_half'] == second_half_prediction), 'result'].values[0]


    def ask_chip_recombine_way(self,full_instr, block, prev_blocks, exp_name):    
        all_chips = {}
        all_chips['one_chip_blocks'] = self.chip_block(block, prev_blocks, 1)
        all_chips['50_50_chips_blocks'] = self.chip_block(block, prev_blocks, 0.5)
        all_chips['75_25_chips_blocks'] = self.chip_block(block, prev_blocks, 0.75)   
        all_chips['25_75_chips_blocks'] = self.chip_block(block, prev_blocks, 0.25)   
        all_chips['one_chip_ai_data'] = self.chips_classify( full_instr, all_chips['one_chip_blocks'], exp_name)                            
        all_chips['50_50_chips_ai_data'] = self.chips_classify( full_instr, all_chips['50_50_chips_blocks'], exp_name)                            
        all_chips['75_25_chips_ai_data'] = self.chips_classify( full_instr, all_chips['75_25_chips_blocks'], exp_name)                            
        all_chips['25_75_chips_ai_data'] = self.chips_classify( full_instr, all_chips['25_75_chips_blocks'], exp_name)                            
        first_half_prediction, first_half_winning_votes =  self.chip_vote(all_chips, FIRST_HALF_CHIPS)
        second_half_prediction, second_half_winning_votes = self.chip_vote(all_chips, SECOND_HALF_CHIPS)        
        final_ai_data = all_chips['one_chip_ai_data'][0]
        prev_class = final_ai_data.classification_code
        final_ai_data.classification_code = self.get_chip_final_response( first_half_prediction, second_half_prediction)
        if  (final_ai_data.classification_code != prev_class):
            l.debug(f"final class:{final_ai_data.classification_code} changed from {prev_class} \
                    for block: {final_ai_data.block['cur_chunk']}")

        return final_ai_data
    
    def ask(self, full_instr, block, prev_blocks, exp_name):
        if block is None:
            raise Exception("null block  was sent to ask()")
        if self.approach == LLM_CHIP_RECOMBINE:
            ai_data = self.ask_chip_recombine_way(full_instr, block, prev_blocks, exp_name)        
        elif self.approach == LLM_SINGLE_CALL:
            # create an input block from current and as appropriate previous blocks
            # input_block keeps the same block_id as original block
            if prev_blocks is None:
                input_block = self.single_block(block)                
            else:
                input_block = self.merge_blocks(block, prev_blocks)                
            sleep(0.05)
            if input_block['cur_chunk'] is None:
                l.debug(f"Input block text is set to None. Ask() cannot interpret {input_block['block_id']}. Skipping.")
                ai_data = None
            else:
                l.debug(f"\n\nInput block text USED: {input_block['cur_chunk']}\n")
                ai_data = ChatGPT(full_instr, input_block, exp_name)   
        else:
            raise Exception("Unknown questioning method")
        
        return ai_data


if __name__ == "__main__": 
    
    db = dataset.connect('sqlite:///db.db')
    llm_predictions = db['llm_predictions']
    blocks = db['text_blocks']    
    ask_llm = AskLLM(db, LLM_CHIP_RECOMBINE)
    print(ask_llm.get_chip_final_response('SPORTS_BROADCASTING', 'OTHER'))

    