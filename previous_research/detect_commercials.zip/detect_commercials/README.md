## Instructions on how to use

To configure automatic reads of record and to indicate strict or normal mode, see run_config.yaml

First you need to install required modules by typing in the command prompt:

```cmd
pip install -r requirements.txt
```

To create a database, simply type in the command prompt the following:

```cmd
python create_database.py
```

To delete all text blocks entity in a database:

```cmd
python main.py del_all_tb
```

To process a file:

```cmd
python main.py file testfile1.txt
```

To read all text blocks entity in a database:

```cmd
python main.py read_tb
```

To read one text block entity from the database:

```cmd
python main.py read_one_tb 1
```

Where 1 is the ID of the row

To delete one text block entity from the database:

```cmd
python main.py del_one_tb 1
```

To read all session data

```cmd
python main.py read_sess
```

To delete all session data

```cmd
python main.py del_sess
```

To read all source data

```cmd
python main.py read_src
```

To delete all source data

```cmd
python main.py del_src
```

To set ground truth labels
NOTE: THIS ASSUMES THAT YOU ALREADY PROCESSED A TEXT BLOCK BEFORE

```cmd
python main.py excelfile warrs_vs_nets.xlsx 0
```

Where warrs_vs_nets.xlsx is the input excel file and 0 is the session id

To read all transition data

```cmd
python main.py read_trans
```

To delete all transition data

```cmd
python main.py del_trans
```
