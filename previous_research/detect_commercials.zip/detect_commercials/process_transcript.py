# -*- coding: utf-8 -*-

# region Description
"""
process_transcript.py: Commands related to loading and parsing transcript files and related labels to the databsae.
"""
# endregion

from models import Base
from components.source_data import SourceData
from components.session_data import SessionData
from components.text_block_data import TextBlockData
from components.chunk_data import ChunkData
from components.log_writers import LogWriters
from components.file_processor import FileProcessor
from components.excel_processor import ExcelProcessor
from components.transition_data import TransitionData
from components.dc_report import DCReport

import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import sys
import yaml
import os

engine = create_engine("sqlite:///db.db", echo=False)
Base.metadata.create_all(bind=engine)

# NOTE: SESSION IS NOT RELATED TO SESSION ENTITY SCHEMA IN THE DATABASE
Session = sessionmaker(bind=engine)
session = Session()

# NOTE: DO NOT MODIFY THIS VARIABLE. run_config.yaml contains the configuration
is_strict_mode = False
is_automatic_read = True
max_suspicious_block_length = 0
max_allowed_file_size = 0
cur_chunk_window = 0.0
num_prev_chunks = 1.0
default_ind = False

current_session_id = 0


def process_data_from_file(target_file, current_source_id, current_session_id):
    file_processor = FileProcessor(
        db_session=session,
        current_source_id=current_source_id,
        current_session_id=current_session_id,
        cur_chunk_window=cur_chunk_window,
        num_prev_chunks=num_prev_chunks,
        max_file_size=max_allowed_file_size,
        target_file=target_file
    )

    file_processor.file_exists()
    file_processor.is_large_file(is_strict_mode)
    file_processor.process_data_from_file(is_strict_mode)


def process_data_from_excel_file(excel_filename, current_session_id, target_session_id):
    excel_processor = ExcelProcessor(
        db_session=session,
        excel_filename=excel_filename,
        current_session_id=current_session_id
    )

    excel_processor.load_transitions()
    excel_processor.set_ground_truth_label(
        int(target_session_id), is_strict_mode)


def verify_command():
    mode_error = "\nProgram halted because mode is not specify. Please specify mode\n\nAVAILABLE MODES: " \
        "\n- del_all_tb\n- read_one_tb\n- del_one_tb\n- file\n- read_tb\n- read_sess\n- read_src\n- del_sess\n- del_src\n- excelfile\n- " \
        " report\n- del_all_chunk\n- read_one_chunk\n- del_one_chunk\n- file\n- read_chunk\n-" \
        "read_trans\n- del_trans\n\nEXAMPLE USAGE: python main.py file testfile1.txt\n\n*Read README.md file for more information."

    if len(sys.argv) < 2:
        print(mode_error)
        return False

    arg_modes = [
        "del_all_tb", "read_one_tb", "del_one_tb", "read_tb", "file",
        "read_sess", "read_src", "del_sess", "del_src",
        "excelfile", "read_trans", "del_trans", "report",
        "del_all_chunk", "read_one_chunk", "del_one_chunk", "read_chunk"]
    if sys.argv[1] not in arg_modes:
        print(mode_error)
        return False

    return True


def create_session_data(argv_list):
    global current_session_id
    current_session_id = SessionData.create_session_data(
        db_session=session,
        cur_chunk_window=cur_chunk_window,
        num_prev_chunks=num_prev_chunks,
        argv_list=argv_list,
        default_ind=default_ind)


def check_if_db_exists():
    if not os.path.exists("db.db"):
        message = "No database file db.db found, please create a database"
        LogWriters.log_general_error(message)
        print(message)
        return False
    return True


def main():
    global is_strict_mode, is_automatic_read, max_suspicious_block_length, max_allowed_file_size, cur_chunk_window, num_prev_chunks, default_ind

    # Verify if commands are valid
    if not verify_command():
        return

    # Check if database file exists
    if not check_if_db_exists():
        return

    # Load and set the runtime configuration from run_config.yaml
    with open("run_config.yaml", "r") as f:
        config = yaml.load(f, Loader=yaml.SafeLoader)
    is_strict_mode = config["run_in_strict_mode"]
    is_automatic_read = config["automatic_read"]
    max_suspicious_block_length = config["max_suspicious_block_length"]
    max_allowed_file_size = config["max_allowed_file_size"]
    cur_chunk_window = config["cur_chunk_window"]
    num_prev_chunks = config["num_prev_chunks"]
    default_ind = config["default_ind"]

    def sess_start():
        LogWriters.log_general_session(
            "Session started", current_session_id, 'i')

    def sess_end():
        LogWriters.log_general_session(
            "Session ended", current_session_id, 'i')
        
    def continue_matching(argv, engine, session, current_session_id, is_automatic_read):
        match argv[1]:
            case "report":
                create_session_data(sys.argv)
                sess_start()
                report = DCReport(engine, session, current_session_id, "all", argv[2])
                report.report_all()
            case "del_all_chunks":
                create_session_data(sys.argv)
                sess_start()
                ChunkData.delete_all_chunk_data(
                    session, current_session_id)
                sess_end()
            case "read_one_chunk":
                if len(sys.argv) != 3:
                    print("Please specify id of the row")
                    return
                create_session_data(sys.argv)
                sess_start()
                ChunkData.read_one_chunk_data(
                    sys.argv[2], session, current_session_id)
                sess_end()
            case "del_one_chunk":
                if len(sys.argv) != 3:
                    print("Please specify id of the row")
                    return
                create_session_data(sys.argv)
                sess_start()
                ChunkData.delete_one_chunk_data(
                    sys.argv[2], session, current_session_id)
                sess_end()
            case "read_chunk":
                create_session_data(sys.argv)
                sess_start()
                if len(sys.argv) == 4:
                    cur_chunk_window = float(sys.argv[2])
                    num_prev_chunks = float(sys.argv[3])

                ChunkData.read_all_chunk_data(
                    session, is_automatic_read, current_session_id)
                sess_end()




    match sys.argv[1]:
        case "del_all_tb":
            create_session_data(sys.argv)
            sess_start()
            TextBlockData.delete_all_text_block_data(
                session, current_session_id)
            sess_end()
        case "read_one_tb":
            if len(sys.argv) != 3:
                print("Please specify id of the row")
                return
            create_session_data(sys.argv)
            sess_start()
            TextBlockData.read_one_text_block_data(
                sys.argv[2], session, current_session_id)
            sess_end()
        case "del_one_tb":
            if len(sys.argv) != 3:
                print("Please specify id of the row")
                return
            create_session_data(sys.argv)
            sess_start()
            TextBlockData.delete_one_text_block_data(
                sys.argv[2], session, current_session_id)
            sess_end()
        case "read_tb":
            create_session_data(sys.argv)
            sess_start()
            if len(sys.argv) == 4:
                cur_chunk_window = float(sys.argv[2])
                num_prev_chunks = float(sys.argv[3])

            TextBlockData.read_all_text_block_data(
                session, is_automatic_read, current_session_id)
            sess_end()
        case "file":
            if len(sys.argv) < 3:
                print("Please specify file name")
                return

            create_session_data(sys.argv)
            sess_start()
            current_source_id = SourceData.get_new_source_id(
                session, sys.argv[2])
            SourceData.create_source_data(
                session, current_source_id, current_session_id, sys.argv[2])
            process_data_from_file(
                sys.argv[2], current_source_id, current_session_id)
            sess_end()

        case "read_sess":
            SessionData.read_all_session_data(session, is_automatic_read)
            pass
        case "read_src":
            SourceData.read_all_source_data(session, is_automatic_read)
            pass
        case "del_sess":
            SessionData.delete_all_session_data(session)
            pass
        case "del_src":
            SourceData.delete_all_source_data(session)
            pass

        case "excelfile":
            if len(sys.argv) < 3:
                print("Please specify file name")
                return
            elif len(sys.argv) < 4:
                print("Please specify target session id to process")
                return

            create_session_data(sys.argv)
            sess_start()
            process_data_from_excel_file(
                sys.argv[2], current_session_id, sys.argv[3])
            sess_end()
        case "read_trans":
            create_session_data(sys.argv)
            sess_start()
            TransitionData.read_all_transition_data(
                session, is_automatic_read, current_session_id)
            sess_end()
        case "del_trans":
            create_session_data(sys.argv)
            sess_start()
            TransitionData.delete_all_transition_data(
                session, current_session_id)
            sess_end()
        case _:
            continue_matching(sys.argv, engine, session, current_session_id, is_automatic_read)


if __name__ == "__main__":
    main()
