import json
import requests
from loguru import logger as l
import dataset
import arrow
from time import sleep
import copy
import pandas as pd

from models import Base

import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import llm_stage_eval
import components.llm_stats as llm_stats
import neptune
import ask_llm
from models import TextBlocksEntity

db = dataset.connect('sqlite:///db.db')
llm_predictions = db['llm_predictions']
instruction_prompts = db['instruction_prompts']


# creating a second instance because this system has mixed db access models for same db. 
# ugh. Fix.
engine = create_engine("sqlite:///db.db", echo=False)
Base.metadata.create_all(bind=engine)

# NOTE: SESSION IS NOT RELATED TO SESSION ENTITY SCHEMA IN THE DATABASE
Session = sessionmaker(bind=engine)
session = Session()

# note for now using entire table
# but this depends on natural sort order and not able to get delta update
blocks = db['text_blocks']
chunks = db['chunks']

# CONFIG VALUES AS CONSTANTS FOR NOW. MOVE TO CMD LINE OR CONFIG LATER.
strict_mode = False

if strict_mode:
    LLM_API_FAIL_LIMIT = 5
    LLM_INVALID_RESPONSE_LIMIT = 10
else:
    LLM_API_FAIL_LIMIT = 10
    LLM_INVALID_RESPONSE_LIMIT = 100

BLOCK_ID_RESTART_FILTER = 0

llm_api_failures = 0
llm_invalid_responses = 0

# new design starts here


class LLMStageParams():
    def __init__(self, exp_name="Unnamed",  stat_loc=None, inc_prev_answer=False, prev_ans_loc=None, \
                  inc_sample_data=False, sample_data_loc=None, inc_prev_blocks=True, num_prev_blocks = 2, \
                      prev_block_loc = None, sleep_time=0,do_block_chip_and_recombine=True ):
        self.exp_name = exp_name
        self.stat_loc = stat_loc
        self.inc_prev_answer = inc_prev_answer
        self.prev_ans_loc = prev_ans_loc        
        self.inc_sample_data = inc_sample_data
        self.sample_data_loc = sample_data_loc
        self.inc_prev_blocks = inc_prev_blocks
        self.num_prev_blocks = num_prev_blocks        
        self.prev_block_loc = prev_block_loc
        self.sleep_time = sleep_time
        self.do_block_chip_and_recombine = do_block_chip_and_recombine

    def convert_to_dict(self):
        p_dict = copy.copy(self.__dict__)
        return p_dict

class LLMStage():
    def __init__(self, params, chunk_filter, instr_filter):
         self.params = params
         self.chunk_filter = chunk_filter
         self.instr_filter = instr_filter   
         self.state_mapping = pd.read_excel('.\input_files\state_mappings.xlsx')      
     
    def get_actl_pred_llm_stage(self, exp_name, df_block_ids = None):
        if df_block_ids is not None:
            raise Exception("not implemented block id filter yet")
        #t.ground_truth_label_c
        q = 'select p.response_classification_c, p.response_classification_num, t.ground_truth_label_c, t.ground_truth_label_num '
        q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
        q = q + ' and p.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name) 
        df_act_pred = pd.DataFrame(rs)          
        return df_act_pred


    def get_chunks(self, chunk_filter):
        # for now hacking around to create filter format
        # let pattern emerge from real usage

        # all
        match chunk_filter:
            case None:
                return chunks
            case "all":
                return chunks
            #Otherwise assume filter is a session_id
            case _:
                return chunks.find(session_id=chunk_filter)




    def get_blocks_by_chunk(self, chunk_id):
        return blocks.find(chunk_id=chunk_id)
       

    def get_instr_set(self, instr_filter):    
        # for now hacking around to create filter format
        # let pattern emerge from real usage

        # all
        match instr_filter:
            case None:
                return instruction_prompts
            case "all":
                return instruction_prompts
            #Otherwise assume filter is a instr_id
            case _:
                return instruction_prompts.find(instr_id=instr_filter)

    def add_prev_answers(self):
        pass

    def add_examples(self):
        pass

    def add_response(self,responses, ai_data):
        responses.append(copy.copy(ai_data))
        return responses
    

    def get_final_instr(self, instr_so_far):
        # place holder for overall validation check
        # and for final tweaks

        # for now do nothing
        return instr_so_far

    def choose_best_response(self,responses, prev_final_response):
        sb_weight = 0.4
        c_weight = 0.35
        o_weight = 0.25
        if len(responses) == 1:
            return responses[0]
        else:
            SB_votes = 0
            C_votes = 0
            O_votes = 0
            for response in responses:
                if response.classification_code == 'SPORTS_BROADCASTING':
                    SB_votes = SB_votes + (1*sb_weight)
                if response.classification_code == 'COMMERCIAL':
                    C_votes = C_votes + (1*c_weight)
                if response.classification_code == 'OTHER':
                    O_votes = O_votes + (1*o_weight)
            winner = None                    
            if SB_votes > C_votes and SB_votes > O_votes:
                winner = 'SPORTS_BROADCASTING'
            if C_votes > SB_votes and C_votes > O_votes:
                winner = 'COMMERCIAL'
            if O_votes > SB_votes and O_votes > C_votes:
                winner = 'OTHER'
                l.debug('\nOTHER vote wins')
            
            
            l.warning('\nWinning response: {}', winner)
            l.warning('\n SB votes: {}, C votes: {}, O votes: {}', SB_votes, C_votes, O_votes)            
            # just use last prediction if can't decide
            #if winner == 'OTHER' and prev_final_response is not None:
            #        l.debug('\nChanging winning response to: {}', prev_final_response.classification_code)
            #        return prev_final_response            
                
            winner_idx_found = False
            loop_idx = 0
            if winner is not None:               
                while not winner_idx_found and loop_idx < len(responses):
                    response = responses[loop_idx]
                    if response.classification_code == winner:
                        winner_response = response
                        winner_idx_found = True
                    loop_idx += 1
                if winner_idx_found:
                    return winner_response
            # if you get here didn't find a winner    
            raise Exception("Wining vote not found")
                



                



    def save_final_response(self,ai_data, stat_loc):
        # for now not using stat_loc parameter (stats location)
        llm_predictions.insert(ai_data.db_output)
        db.commit()

    def update_stats_and_windowed(self,params):
        # for now not using stat_loc parameter (stats location)
        llm_s = llm_stats.LLMStatsUtils(db)
        llm_s.update_llm_stats(params.exp_name,'response_classification')
        llm_s.update_llm_stats(params.exp_name,'ground_truth_label_c')
        w_preds_with_block_id = self.calc_windowed_predictions(params.exp_name)
        self.save_windowed_set_of_predictions_to_db(w_preds_with_block_id)


    def calc_windowed_predictions(self,exp_name):
        q = 'SELECT t.session_id, t.block_id, t.sequence_num, l.response_classification_c, l.llm_predict_id, l.llm_exp_name'
        q = q + ' FROM text_blocks t, llm_predictions l'
        q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        # really gotta clean up how I access DBs!
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)

        llm_s_eval = llm_stage_eval.LLMStageEval()
        windowed_predictions = llm_s_eval.calc_block_window_states(rs, "block_id", "response_classification_c", window_size=2)
        return windowed_predictions


    def retrieve_fields_for_eval(self, rs, id_field, value_field):
        # I made a mistake and applied windowing to ground truth so
        # writing this function to just give the raw labels in the same format
        results = []
        for rec in rs:
            result_rec = {}            
            result_rec["id"] = rec[id_field]
            result_rec["value"] = rec[value_field]            
            results.append(result_rec)
        return results


    def get_windowed_predictions(self,exp_name, df_block_ids = None):
        if df_block_ids is not None:
           raise Exception("not implemented block id filter yet")

        q = 'SELECT t.session_id, t.block_id, t.sequence_num, l.windowed_resp_class_c, l.llm_predict_id, l.llm_exp_name'
        q = q + ' FROM text_blocks t, llm_predictions l'
        q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        # really gotta clean up how I access DBs!
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
        # actually ground truth should not be windowed...hacked to work. fix later.
        raw_labels = self.retrieve_fields_for_eval(rs, "block_id", "windowed_resp_class_c")
        return raw_labels


    def get_ground_truth_labels(self,exp_name, df_block_ids):
        if df_block_ids is not None:
           raise Exception("not implemented block id filter yet")

        q = 'SELECT t.session_id, t.block_id, t.sequence_num, t.ground_truth_label_c, l.llm_predict_id, l.llm_exp_name'
        q = q + ' FROM text_blocks t, llm_predictions l'
        q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        # really gotta clean up how I access DBs!
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
        # actually ground truth should not be windowed...hacked to work. fix later.
        raw_labels = self.retrieve_fields_for_eval(rs, "block_id", "ground_truth_label_c")
        return raw_labels

    def save_windowed_single_prediction_to_db(self,windowed_resp_class_c, llm_predict_id):
        p_dict = {'windowed_resp_class_c':windowed_resp_class_c, 'llm_predict_id':llm_predict_id}  
        uq = 'update llm_predictions set '
        uq = uq + ' windowed_resp_class_c = :windowed_resp_class_c '
        uq = uq + ' where llm_predict_id =:llm_predict_id '
        rs = db.engine.execute(sqlalchemy.text(uq), p_dict)

    def save_windowed_set_of_predictions_to_db(self,windowed_predictions):
        for w_pred in windowed_predictions:
            self.save_windowed_single_prediction_to_db(w_pred['value'], w_pred['llm_predict_id'])
    

    def eval_llm_stage(self, exp_name, run, df_block_ids = None, stage_desc = "stage_1"):
        # df_block_ids is a join condition so this eval runs only for a certain set of text_block_id records
        df_act_pred = self.get_actl_pred_llm_stage(exp_name, df_block_ids)
        actual_binary = df_act_pred['ground_truth_label_c']
        pred_binary = df_act_pred['response_classification_c']
        actual_multi = df_act_pred['ground_truth_label_num']
        pred_multi = df_act_pred['response_classification_num']
        l.info("\nCalculate accuracy for experiment: {} using all llm raw predictions in " + stage_desc, exp_name)
        llm_stage_eval.LLMStageEval.eval_accuracy(exp_name, run, actual_binary, pred_binary, actual_multi, pred_multi)
        w_preds_with_block_id = self.get_windowed_predictions(exp_name, df_block_ids)
        w_actuals_with_block_id = self.get_ground_truth_labels(exp_name, df_block_ids)
        df_w_preds_with_block_id = pd.DataFrame(w_preds_with_block_id)
        df_w_actuals_with_block_id = pd.DataFrame(w_actuals_with_block_id)
        df_w_preds = df_w_preds_with_block_id['value']
        df_w_actuals = df_w_actuals_with_block_id['value']        
        l.info("\nCalculate accuracy for experiment: {} using all llm WINDOWED predictions in " + stage_desc, exp_name)
        llm_stage_eval.LLMStageEval.eval_accuracy(exp_name + "_WINDOWED" + stage_desc, run, df_w_actuals, df_w_preds, None, None)
        #df_w_preds_with_block_id.to_excel('.\output\windowed_preds.xlsx', index=False)
        #df_w_actuals_with_block_id.to_excel('.\output\windowed_actuals.xlsx', index=False)
        
        
        #df_every_3rd_preds = df_w_preds_with_block_id.iloc[::3]
        #df_every_3rd_actuals = df_w_actuals_with_block_id.iloc[::3]
        #df_w_preds_3 = df_every_3rd_preds['value']
        #df_w_actuals_3 = df_every_3rd_actuals['value'] 
        #l.info("\nCalculate accuracy for experiment: {} using every 3rd row of an llm WINDOWED predictions in stage 1", exp_name)
        #llm_stage_eval.LLMStageEval.eval_accuracy(exp_name + "_WINDOWED_ever3rd", run, df_w_actuals_3, df_w_preds_3, None, None)        

    # 3rd time creatingg these functions - centralize and rationalize to 1 function
    def get_class_num(self,class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 2
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 3
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 4
        elif class_code == 'OTHER':
            return 5

    def get_class_c(self,class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 1
        elif class_code == 'OTHER':
            return 0


    def get_prev_blocks(self,block,num_prev_blocks):
        prev_blocks = []
        loop_block = block['prev_block_link']
        valid_prev_block_count = 0
        while valid_prev_block_count < num_prev_blocks:
            if loop_block is None:
                break
            if loop_block['block_id'] is not None:
                prev_blocks.append(loop_block)
                valid_prev_block_count +=1
            loop_block = loop_block['prev_block_link']
        return prev_blocks



    def process_chunks(self,chunks, instr_set, params, nept_run):
        def get_instr_set_mem(instr_set):
            instr_set_mem = []
            for instr in instr_set:
                instr_set_mem.append(instr)
            return instr_set_mem
        
        # get this once and put in memory
        instr_set_mem = get_instr_set_mem(instr_set)

        prev_chunk = None
        prev_chunk_last_block = None
        prev_chunk_last_block_is_partial = False
        for chunk in chunks:
            # if this set of chunks is from different sessions then reset key state
            if (prev_chunk is not None) and (prev_chunk['session_id'] != chunk['session_id']):
                prev_chunk = None
                prev_chunk_last_block = None
                prev_chunk_last_block_is_partial = False

            # process each chunk
            # pass in what is needed from previous chunk
            # - was the last block of previous chunk a partial sentence? Id so, this chunk will complete it and proces
            # - what was the last block of the previous chunk? Need this to build a linked list of all blocks in session
            prev_chunk_last_block, prev_chunk_last_block_is_partial = self.process_single_chunk(chunk, prev_chunk_last_block_is_partial, prev_chunk_last_block, instr_set_mem, params, nept_run)
                        
            prev_chunk = chunk


    def get_block_ground_truth(self,chunk, sentence_count):

        code_to_return = None
        if chunk['ground_truth_label'] == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            if sentence_count < chunk['first_sent_to_second_state']:
                code_to_return = 'SPORTS_BROADCASTING'
            else:                
                code_to_return = 'COMMERCIAL'

        if chunk['ground_truth_label'] == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            if sentence_count < chunk['first_sent_to_second_state']:
                code_to_return = 'COMMERCIAL'
            else:                
                code_to_return = 'SPORTS_BROADCASTING'

        if chunk['ground_truth_label'] == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            code_to_return = 'COMMERCIAL'

        if code_to_return is None:
            code_to_return = chunk['ground_truth_label']

        return code_to_return, self.get_class_num(code_to_return), self.get_class_c(code_to_return)
                

    def get_block_start_end(self,chunk, sentence_count):
            first_sent_to_second_state = chunk['first_sent_to_second_state']
            # if None, then this is not a block with a major transition, nothing to change
            if first_sent_to_second_state is None:
                start_time = chunk['cur_chunk_start']                
                end_time = chunk['cur_chunk_end']
            else:                
                
                # don't squeeze the block start and end if all blocks will be one side of the transition
                if first_sent_to_second_state == 0 or first_sent_to_second_state == 1:
                    start_time = chunk['cur_chunk_start']                
                    end_time = chunk['cur_chunk_end']
                else:                    
                    # otherwise squeeze time of current block based on which side of transition it is on
                    if sentence_count < chunk['first_sent_to_second_state']:
                        start_time = chunk['cur_chunk_start']                
                        end_time = chunk['major_trans_timestamp']
                    else:                
                        start_time = chunk['major_trans_timestamp']
                        end_time = chunk['cur_chunk_end']
            return start_time, end_time

    def create_block_from_chunk(self,chunk, sentence, sentence_count):
        # session_id, source_id set by this             
        block = copy.copy(chunk) 
        block['block_id'] = None
        block['sequence_num'] = None
        block['chunk_overlap_ind'] = None
        block['cur_chunk'] = sentence                
        b_gt_label, bg_gt_label_num, b_gt_label_c = self.get_block_ground_truth(chunk, sentence_count)
        block['ground_truth_label'] = b_gt_label
        block['ground_truth_label_num'] = bg_gt_label_num
        block['ground_truth_label_c'] = b_gt_label_c        
        b_start, b_end = self.get_block_start_end(chunk, sentence_count)
        block['cur_chunk_start'] = b_start
        block['cur_chunk_end'] = b_end

        return block
    
    def get_sentences_as_blocks(self,chunk, prev_chunk_last_block,prev_chunk_last_block_is_partial):
        if prev_chunk_last_block_is_partial:
            text_to_tokenize = prev_chunk_last_block['cur_chunk'] + chunk['cur_chunk']
            chunk_overlap_ind = "Y"
        else:
            text_to_tokenize = chunk['cur_chunk'] 
            chunk_overlap_ind = "N"

        nlt = ask_llm.NLTools()        
        sentences, _ = nlt.get_sentences_from_text(text_to_tokenize)    
        blocks = []        
        sentence_count = 1
        for sentence in sentences:            
            # block_id field will be None here - not set until saved to db
            block = self.create_block_from_chunk(chunk, sentence, sentence_count)            
            blocks.append(block)  
            sentence_count +=1          
        return blocks, chunk_overlap_ind
    
    def is_complete(self,block):
        
        # for now assume block is a sentence
        sentence = block['cur_chunk']
        # Check if the last character is a period, question mark, or exclamation point
        last_char = sentence[-1]        
        return last_char in ['.', '?', '!']

    def get_latest_id(self):
        # Get latest data or the last row from the database
        last_row = session.query(TextBlocksEntity).order_by(
            TextBlocksEntity.block_id.desc()).first()
        if last_row != None:
            return last_row.block_id + 1
        else:
            return 0

    def get_latest_sequence(self, session_id):
        # Get latest data or the last row from the database
        last_row = session.query(TextBlocksEntity).filter(
            TextBlocksEntity.session_id == session_id).order_by(
            TextBlocksEntity.sequence_num.desc()).first()
        if last_row != None:
            return last_row.sequence_num + 1
        else:
            return 1

    def save_block_in_db(self,block, chunk_overlap_ind):
        block_id = self.get_latest_id()
        sequence_num = self.get_latest_sequence(block["session_id"])
        text_block_entity = TextBlocksEntity(
            block_id=block_id,
            session_id=block["session_id"],            
            sequence_num=sequence_num,
            source_id= block["source_id"],
            cur_chunk=block["cur_chunk"],
            cur_chunk_start=block["cur_chunk_start"],
            cur_chunk_end=block["cur_chunk_end"],
            ground_truth_label=block["ground_truth_label"],
            ground_truth_label_num=block["ground_truth_label_num"],
            ground_truth_label_c=block["ground_truth_label_c"],
            chunk_id=block["chunk_id"],
            chunk_overlap_ind=chunk_overlap_ind)

        session.add(text_block_entity)
        session.commit()
        return block_id

    def save_eligible_blocks_to_db(self,blocks, chunk_overlap_ind):
        block_num = 1
        first_block = True        
        eligible_blocks = []
        for block in blocks:
            #The last block in a chunk will not be saved to db and will not get a block_id
            if self.is_complete(block) or block_num < len(blocks):                
                if first_block:                    
                    block['block_id'] = self.save_block_in_db(block, chunk_overlap_ind)
                    eligible_blocks.append(block)
                    first_block = False
                else:
                    block['block_id'] = self.save_block_in_db(block, "N")                                            
                    eligible_blocks.append(block)
            block_num +=1
        return eligible_blocks

    def trim_links(self,block):
        depth_count = 0
        cur_block = block
        to_release_list = []
        while depth_count < 10:
            if cur_block is not None:
                cur_block = cur_block['prev_block_link']
            else:
                break
            depth_count += 1
        if cur_block is not None:
            # hopefully this allows GC to clear up nested links
            cur_block['prev_link'] = None
        
    def process_single_chunk(self,chunk, prev_chunk_last_block_is_partial, prev_chunk_last_block, instr_set_mem, params, nept_run):                   

        # Assumes blocks are saved in db already
        blocks = self.get_blocks_by_chunk(chunk['chunk_id'])

        prev_blocks = None
        prev_block = prev_chunk_last_block
        prev_final_response = None
        for block in blocks:
            # link this block to previous ones so next iteration can retrieve previous blocks as needed
            block['prev_block_link'] = prev_block
            #block['prev_block_link'] = None
            self.trim_links(block)            
            if block['block_id'] is not None:
                responses = []
                final_response = None
                first_instr = True
                for instr in instr_set_mem:
                        instr_so_far = instr
                        # test - move this to instrument schema instead of hardcodign if it works
                        # reduce num_prev blocks to 1 after first instruction prompt
                        if first_instr:
                            temp_hack_inc_prev_blocks = params.inc_prev_blocks 
                            first_instr = False
                        else:
                            temp_hack_inc_prev_blocks = False                            
                        if params.inc_prev_answer:
                            instr_so_far = self.add_prev_answers(instr_so_far, prev_block,params.prev_ans_loc)
                        if params.inc_sample_data:
                            instr_so_far = self.add_prev_sample_data(instr_so_far, params.sample_data_loc)
                        full_instr = self.get_final_instr(instr_so_far)

                        # this is different than using prev_chunk_last_block to find a complete sentence as done in get_sentences(), 
                        # which is just to define the single block in a clear way (a full sentence).
                        # Below signals the algorithm caller wants to use multiple blocks in the evaluation by the LLM in other ways
                        # to help evaluate this particular block
                        if temp_hack_inc_prev_blocks:
                            # current implementation assumes blocks are connected as a linked list
                            prev_blocks = self.get_prev_blocks( block, params.num_prev_blocks)
                        else:
                            prev_blocks = None
                        llm = ask_llm.AskLLM(db,self.state_mapping,ask_llm.LLM_SINGLE_CALL)
                        ai_data = llm.ask(full_instr, block, prev_blocks, params.exp_name)                    
                        responses = self.add_response(responses, ai_data)
                final_response = self.choose_best_response(responses, prev_final_response)
                l.debug('Response for block: {} \n is : {}', block['cur_chunk'],\
                            final_response.classification_code)
                self.save_final_response(final_response, params.stat_loc)
                prev_final_response = final_response
            else:
                l.debug('Skipping prediction on ineligible block: {}', block['cur_chunk'])
                
            # always get a copy of current block
            prev_block = copy.copy(block)                            
        
        # So prev_block represents the last block in the sentence list. 
        # See if block is complete
        if prev_block is None or self.is_complete(prev_block):
            # no, last block is NOT a partial
            return prev_block, False
        else:
            # yes, last block is a partial sentence
            return prev_block, True
                
   
    def exec(self, nept_run):
        chunks_to_process = self.get_chunks(self.chunk_filter)
                
        instr_set = self.get_instr_set(self.instr_filter)
                
        # uncomment before you check in the code!
        self.process_chunks(chunks_to_process,instr_set, self.params, nept_run)

        self.update_stats_and_windowed(self.params)

        self.eval_llm_stage(self.params.exp_name, nept_run)


   
    def update_stats_and_eval(self, nept_run):

        self.update_stats_and_windowed(self.params)

        self.eval_llm_stage(self.params.exp_name, nept_run)

    def eval(self, nept_run):

        self.eval_llm_stage(self.params.exp_name, nept_run)


if __name__ == "__main__":    
    llm_stage_params = LLMStageParams(exp_name = "1")       
    stage1 = LLMStage(llm_stage_params, "3", "1")
    ##stage1.eval_llm_stage('30 seconds v1')
    ##stage1.exec()
    stage1.update_stats(llm_stage_params)

