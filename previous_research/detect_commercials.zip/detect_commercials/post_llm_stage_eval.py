import dataset
import matplotlib.pyplot as plt
import numpy as np
from sklearn.calibration import LabelEncoder
from sklearn.pipeline import Pipeline
import sqlalchemy
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix, recall_score, precision_score,f1_score
from sklearn.metrics import classification_report
import seaborn as sns
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import time
from sklearn.model_selection import learning_curve
import json
from loguru import logger as l
import accuracy_metrics

class PostLLMStageEval():
    @staticmethod
    def eval_accuracy(exp_name, stage_suffix, nept_run, actual_binary, pred_binary, actual_multi, pred_multi):       
        accuracy_metrics.AccuracyMetrics.eval_accuracy_detail(exp_name, 'post_llm_stage'+ stage_suffix, nept_run, 'binary', actual_binary, pred_binary)
        #accuracy_metrics.AccuracyMetrics.eval_accuracy_detail(exp_name, 'post_llm_stage'+ stage_suffix, nept_run, 'multi', actual_multi, pred_multi)

        
