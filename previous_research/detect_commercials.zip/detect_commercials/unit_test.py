# -*- coding: utf-8 -*-

# region Description
"""
unit_test.py: This file is only use for testing functions
"""
# endregion

import re

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, TextBlocksEntity, TransitionsEntity

engine = create_engine("sqlite:///db.db", echo=True)
Base.metadata.create_all(bind=engine)

Session = sessionmaker(bind=engine)
session = Session()

is_strict_mode = False
pattern = r'(\[([\d:.]+)\]|\[inaudible ([\d:.]+)\])'


def process_data_from_file(target_file):
    current_text_block = ""
    suspected_timestamp = ""

    cur_chunk_start = "00:00:00.000"
    cur_chunk_end = ""
    is_inside_bracket = False

    number_of_lines = 0
    with open(f"input_files/{target_file}", "r", encoding="utf-8") as f:
        for line in f:
            number_of_lines += 1
            for char in line:
                # Check for non-ascii characters
                if ord(char) > 127 and is_strict_mode:
                    raise Exception("Non-ascii character detected")
                elif ord(char) > 127 and not is_strict_mode:
                    # Do not pass data to db
                    continue

                # Check for unbalance and nested brackets
                if char == "[" and is_inside_bracket:
                    # Possible nested bracket detected
                    raise Exception("Nested bracket detected")
                elif char == "]" and not is_inside_bracket:
                    # Possible unbalance bracket detected
                    raise Exception("Unbalance bracket detected")

                # Check if current character is "[]"
                if char == "[":
                    suspected_timestamp += char
                    is_inside_bracket = True
                    continue
                elif char == "]":
                    suspected_timestamp += char
                    is_inside_bracket = False

                    # Check if characters inside the bracket is a valid timestamp
                    is_timestamp = bool(re.match(pattern, suspected_timestamp))
                    if is_timestamp:
                        with open(f"processed_files/{target_file}", "a", encoding="utf-8") as f:
                            f.write(
                                f"{current_text_block}\n{suspected_timestamp}")
                        cur_chunk_end = suspected_timestamp.replace(
                            "[", "").replace("]", "")
                        # TODO: Save text block into database

                        cur_chunk_start = cur_chunk_end

                    current_text_block = ""
                    suspected_timestamp = ""
                    continue

                if is_inside_bracket:
                    suspected_timestamp += char
                else:
                    current_text_block += char


def test_regex_pattern():
    pattern = r'(\[([\d:.]+)\]|\[inaudible ([\d:.]+)\])'
    print(bool(re.match(pattern, "[inaudible 00:15:16.211]")))
    print(bool(re.match(pattern, "[00:13:45.314]")))


def test_reading_of_file(target_file):
    with open(f"input_files/{target_file}", "r", encoding="utf-8") as f:
        for line in f:
            print(line)


def detect_unbalance_bracket(target_file):
    f = open(f"input_files/{target_file}", "r", encoding="utf-8")
    is_inside_bracket = False

    for line in f:
        for char in line:
            if char == "[" and is_inside_bracket:
                raise Exception("Unbalance bracket")
            elif char == "]" and not is_inside_bracket:
                raise Exception("Unbalance bracket")

            if char == "[":
                is_inside_bracket = True
                continue
            elif char == "]":
                is_inside_bracket = False
                continue

    print("NO UNBALANCE BRACKET DETECTED")
    f.close()


def print_out_text_block_entity(text_block_entity: TextBlocksEntity):
    cur_chunk_start = text_block_entity.cur_chunk_start.strftime(
        "%H:%M:%S")
    cur_chunk_end = text_block_entity.cur_chunk_end.strftime(
        "%H:%M:%S")
    transcription_date = text_block_entity.trans_dt.strftime(
        "%Y-%m-%d %H:%M:%S")

    print(f"---\nBLOCK ID: {text_block_entity.block_id}")
    print(f"SESSION ID: {text_block_entity.session_id}")
    print(f"SEQUENCE NUM: {text_block_entity.sequence_num}")
    print(f"TRANS DT: {transcription_date}")
    print(f"SOURCE ID: {text_block_entity.source_id}")
    print(f"CUR CHUNK: {text_block_entity.cur_chunk}")
    print(f"CUR CHUNK START: {cur_chunk_start}")
    print(f"CUR CHUNK END: {cur_chunk_end}")
    print(f"GROUND TRUTH LABEL: {text_block_entity.ground_truth_label}\n")
    print(f"GROUND TRUTH LABEL NUM: {text_block_entity.ground_truth_label_num}\n")
    print(f"CHUNK ID: {text_block_entity.chunk_id}")
    print(f"CHUNK OVERLAP IND: {text_block_entity.chunk_overlap_ind}")


def test_get_text_block_by_session_id(target_session_id):
    q_text_block = session.query(TextBlocksEntity).filter(
        TextBlocksEntity.session_id == int(target_session_id)).all()

    for tb in q_text_block:
        print_out_text_block_entity(tb)
        input()


def print_out_transition_data(transitions_entity: TransitionsEntity):
    timestamp = transitions_entity.timestamp.strftime(
        "%H:%M:%S")
    last_modify_dt = transitions_entity.last_modify_dt.strftime(
        "%Y-%m-%d %H:%M:%S")

    print(f"---\nTRANSITION ID: {transitions_entity.transition_id}")
    print(f"TRANSITION CODE: {transitions_entity.transition_code}")
    print(f"TIMESTAMP: {timestamp}")
    print(
        f"TRANSITION EXCEL FILE NAME: {transitions_entity.transition_excel_filename}")
    print(
        f"TRANSITION EXCEL FILE PATH: {transitions_entity.transition_excel_filepath}")
    print(f"SOURCE FILE NAME: {transitions_entity.source_filename}")
    print(f"SOURCE FILE PATH: {transitions_entity.source_file_path}")
    print(f"LAST MODIFY DT: {last_modify_dt}")
    print(f"SOURCE ID: {transitions_entity.source_id}")
    mt_timestamp = transitions_entity.major_trans_timestamp.strftime(
        "%H:%M:%S")
    print(f"MAJOR TRANS TIMESTAMP: {mt_timestamp}")
    print(f"FIRST SENT TO SECOND STATE: {transitions_entity.first_sent_to_second_state}")


def test_get_transition_data_by_source_id(target_source_id):
    q_transition_data = session.query(TransitionsEntity).filter(
        TransitionsEntity.source_id == target_source_id).all()

    for td in q_transition_data:
        print_out_transition_data(td)
        input()


# test_get_text_block_by_session_id(0)
# test_get_transition_data_by_source_id(0)
