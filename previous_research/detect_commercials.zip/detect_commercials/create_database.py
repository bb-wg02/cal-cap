# -*- coding: utf-8 -*-

# region Description
"""
create_database.py: This script is use to create db.db file which contains a database and table
"""
# endregion

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import ChunksEntity, TextBlocksEntity, SessionEntity, SourceEntity, TransitionsEntity, Base
from components.log_writers import LogWriters
from datetime import time, datetime
import os


def main():
    # Check if database file exists
    if os.path.exists("db.db"):
        is_delete = input(
            "Database file db.db already exists, do you want to delete? [Y/N]: ")

        if is_delete == "Y":
            # Deletes the database and proceeds to create new one
            message = "Deleting database file db.db because already exists"
            print(message)
            LogWriters.log_general_warning(message)
            os.remove("db.db")
        elif is_delete == "N":
            message = "Cannot create database because file db.db already exists"
            print(message)
            LogWriters.log_general_error(message)
            return

    engine = create_engine("sqlite:///db.db", echo=True)
    Base.metadata.create_all(bind=engine)

    # NOTE: SESSION IS NOT RELATED TO SESSION ENTITY SCHEMA IN THE DATABASE
    Session = sessionmaker(bind=engine)
    session = Session()

    # Set first default value for text block in database
    chunks_entity = ChunksEntity(
        chunk_id=0,
        session_id=0,
        sequence_num=0,
        source_id=0,
        cur_chunk="text",
        cur_chunk_start=time(hour=0, minute=0, second=0, microsecond=0),
        cur_chunk_end=time(hour=0, minute=0, second=0, microsecond=0),
        ground_truth_label="None",
        ground_truth_label_num=-1,
        ground_truth_label_c=-1,
        major_trans_timestamp = time(hour=0, minute=0, second=0, microsecond=0),
        first_sent_to_second_state = -1)


    # Set first default value for text block in database
    text_block_entity = TextBlocksEntity(
        block_id=0,
        session_id=0,
        sequence_num=0,
        source_id=0,
        cur_chunk="text",
        cur_chunk_start=time(hour=0, minute=0, second=0, microsecond=0),
        cur_chunk_end=time(hour=0, minute=0, second=0, microsecond=0),
        ground_truth_label="None",
        ground_truth_label_num=-1,
        ground_truth_label_c=-1,
        chunk_id = 0,
        chunk_overlap_ind = "N")
    # Set first default value for session in database
    session_entity = SessionEntity(
        session_id=0,
        cur_chunk_window=0.0,
        num_prev_chunks=0.0,
        default_ind=False,
        completion_status_ind="r",
        command="command",
        session_log_filename="file name",
        session_log_filepath="file path"
    )
    # Set first default value for source in database
    source_entity = SourceEntity(
        source_id=0,
        file_name="file",
        file_path="path",
        description="None",
        last_modified=datetime(year=2000, month=1, day=1,
                               hour=1, minute=1, second=1),
        category="None",
        sub_category="None"
    )
    # Set first default value for transitions in database
    transitions_entity = TransitionsEntity(
        transition_id=0,
        transition_code="SPORTS_BROADCASTING-TO-COMMERCIAL",
        timestamp=time(hour=0, minute=0, second=0, microsecond=0),
        transition_excel_filename="filename",
        transition_excel_filepath="filepath",
        source_filename="filename",
        source_file_path="filepath",
        last_modify_dt=datetime(year=2000, month=1, day=1,
                                hour=1, minute=1, second=1),
        source_id = 0,
        major_trans_timestamp=time(hour=0, minute=0, second=0, microsecond=0),
        first_sent_to_second_state=-1
    )

    session.add(chunks_entity)    
    session.add(text_block_entity)
    session.add(session_entity)
    session.add(source_entity)
    session.add(transitions_entity)
    session.commit()

    # Then delete them all for a fresh start
    session.query(ChunksEntity).delete()
    session.query(TextBlocksEntity).delete()
    session.query(SessionEntity).delete()
    session.query(SourceEntity).delete()
    session.query(TransitionsEntity).delete()
    session.commit()

    print("\nSUCCESSFULLY CREATED THE DATABASE AND TABLES\n")


if __name__ == "__main__":
    main()
