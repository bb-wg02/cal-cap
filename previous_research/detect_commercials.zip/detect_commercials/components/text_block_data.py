# -*- coding: utf-8 -*-

# region Description
"""
text_block_data.py: Create and save metadata of each text block from a file
"""
# endregion

from models import TextBlocksEntity
from components.log_writers import LogWriters
from components.session_data import SessionData


class TextBlockData:
    @staticmethod
    def print_out_text_block_entity(text_block_entity: TextBlocksEntity):
        cur_chunk_start = text_block_entity.cur_chunk_start.strftime(
            "%H:%M:%S")
        cur_chunk_end = text_block_entity.cur_chunk_end.strftime(
            "%H:%M:%S")
        transcription_date = text_block_entity.trans_dt.strftime(
            "%Y-%m-%d %H:%M:%S")

        print(f"---\nBLOCK ID: {text_block_entity.block_id}")
        print(f"SESSION ID: {text_block_entity.session_id}")
        print(f"SEQUENCE NUM: {text_block_entity.sequence_num}")
        print(f"TRANS DT: {transcription_date}")
        print(f"SOURCE ID: {text_block_entity.source_id}")
        print(f"CUR CHUNK: {text_block_entity.cur_chunk}")
        print(f"CUR CHUNK START: {cur_chunk_start}")
        print(f"CUR CHUNK END: {cur_chunk_end}")
        print(f"GROUND TRUTH LABEL: {text_block_entity.ground_truth_label}\n")
        print(f"GROUND TRUTH LABEL NUM: {text_block_entity.ground_truth_label_num}\n")
        print(f"GROUND TRUTH LABEL C: {text_block_entity.ground_truth_label_c}\n")
        print(f"CHUNK ID: {text_block_entity.chunk_id}\n")
        print(f"CHUNK OVERLAP IND: {text_block_entity.chunk_overlap_ind}\n")        

    @staticmethod
    def read_all_text_block_data(db_session, is_automatic_read, current_session_id):
        # Reads and prints all data from the database
        results = db_session.query(TextBlocksEntity).all()

        for r in results:
            TextBlockData.print_out_text_block_entity(r)
            if not is_automatic_read:
                input()

        message = f"read_all_data -> Printed a total of {len(results)} text block data"
        LogWriters.log_general_session(message, current_session_id, 'i')
        SessionData.modify_session_data(db_session, current_session_id, "s")
        print(f"TOTAL ENTITIES: {len(results)}")

    @staticmethod
    def read_one_text_block_data(id, db_session, current_session_id):
        # Get a single row data based on id
        result = db_session.query(TextBlocksEntity).filter(
            TextBlocksEntity.block_id == id).first()

        if result:
            TextBlockData.print_out_text_block_entity(result)
            message = f"get_one_data -> Got one text block entity with id {id}"
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")
        else:
            message = f"get_one_data -> No matching text block entity with id {id} was found"
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")
            print(message)

    @staticmethod
    def delete_all_text_block_data(db_session, current_session_id):
        # Deletes all row data from the database
        db_session.query(TextBlocksEntity).delete()
        db_session.commit()

        message = "delete_all_data -> Deleted all text block data"
        LogWriters.log_general_session(message, current_session_id, 'i')
        SessionData.modify_session_data(db_session, current_session_id, "s")
        print("SUCCESSFULLY DELETED ALL TEXT BLOCK DATA")

    @staticmethod
    def delete_one_text_block_data(id, db_session, current_session_id):
        # Deletes a single row data based on id
        entity_to_delete = db_session.query(
            TextBlocksEntity).filter(TextBlocksEntity.block_id == id).first()

        if entity_to_delete:
            # Delete the entity
            db_session.delete(entity_to_delete)
            db_session.commit()
            message = f"delete_one_data -> Entity with id {id} deleted successfully"
            print(message)
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")
        else:
            message = f"delete_one_data -> No matching text block entity with id {id} was found"
            print(message)
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")

