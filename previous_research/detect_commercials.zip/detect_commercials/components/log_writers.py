# -*- coding: utf-8 -*-

# region Description
"""
log_writers.py: Writes log information in the logs and session_logs directory
"""
# endregion

import datetime


class LogWriters:
    @staticmethod
    def log_general_warning(message):
        date_str = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
        with open("logs/warning_logs.txt", "a", encoding="utf-8") as f:
            f.write(f"{date_str} [WARNING] {message}\n")

    @staticmethod
    def log_general_error(message):
        date_str = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
        with open("logs/error_logs.txt", "a", encoding="utf-8") as f:
            f.write(f"{date_str} [ERROR] {message}\n")

    @staticmethod
    def log_general_session(message, session_id, context):
        # 'i' for informations, 'w' for warnings and 'e' for errors
        context_formatted = "[INFO]"
        if context == "w":
            context_formatted = "[WARNING]"
        elif context == "e":
            context_formatted = "[ERROR]"

        date_str = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
        with open(f"session_logs/session{session_id}.txt", "a", encoding="utf-8") as f:
            f.write(f"{date_str} {context_formatted} {message}\n")
