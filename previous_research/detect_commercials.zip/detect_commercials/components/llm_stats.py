from loguru import logger as l
from time import sleep
import pandas as pd
import sqlalchemy
import copy

#db = dataset.connect('sqlite:///db.db')
#llm_predictions = db['llm_predictions']
#instruction_prompts = db['instruction_prompts']


class LLMStatsUtils():
    def __init__(self, db):
        self.db = db
    
    def re_init_stats(self):
        llm_stats = {'sports_broadcasting_streak':0,
                    'commercial_streak':0,
                    'sb_to_c_streak':0,
                    'c_to_c_streak':0,
                    'c_to_sb_streak':0,
                    'other_streak':0,
                    'c_blocks_so_far':0,
                    'sb_blocks_so_far':0,
                    'other_blocks_so_far':0,
                    'num_blocks_since_sb':0,
                    'num_blocks_since_c':0,
                    'llm_predict_id':-1,
                    'block_id':-1,
                    'text_block_stat_id':-1}
                    

        return llm_stats

    def update_sb(self,llm_stats):
        llm_stats['sports_broadcasting_streak'] += 1
        llm_stats['num_blocks_since_sb'] = 0

        llm_stats['commercial_streak'] = 0
        llm_stats['sb_to_c_streak'] = 0
        llm_stats['c_to_c_streak'] = 0
        llm_stats['c_to_sb_streak'] = 0
        llm_stats['other_streak'] = 0

        llm_stats['num_blocks_since_c'] +=1

        llm_stats['sb_blocks_so_far'] +=1

        llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far']
        llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']
                    
    def update_sb_to_c(self,llm_stats):
        llm_stats['sports_broadcasting_streak'] = 0
        llm_stats['num_blocks_since_sb'] += 1

        llm_stats['commercial_streak'] = 0
        llm_stats['sb_to_c_streak'] += 1
        llm_stats['c_to_c_streak'] = 0
        llm_stats['c_to_sb_streak'] = 0
        llm_stats['other_streak'] = 0

        llm_stats['num_blocks_since_c'] +=1

        llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']

        llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far']
        llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']
                

    def update_c(self,llm_stats):
        llm_stats['sports_broadcasting_streak'] = 0
        llm_stats['num_blocks_since_sb'] += 1

        llm_stats['commercial_streak'] += 1
        llm_stats['sb_to_c_streak'] = 0
        llm_stats['c_to_c_streak'] = 0
        llm_stats['c_to_sb_streak'] = 0
        llm_stats['other_streak'] = 0

        llm_stats['num_blocks_since_c'] = 0

        llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']

        llm_stats['c_blocks_so_far'] += 1 
        llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']


    def update_c_to_c(self,llm_stats):
        llm_stats['sports_broadcasting_streak'] = 0
        llm_stats['num_blocks_since_sb'] += 1

        llm_stats['commercial_streak'] = llm_stats['commercial_streak'] 
        llm_stats['sb_to_c_streak'] = 0
        llm_stats['c_to_c_streak'] += 1
        llm_stats['c_to_sb_streak'] = 0
        llm_stats['other_streak'] = 0

        llm_stats['num_blocks_since_c'] = llm_stats['num_blocks_since_c'] 

        llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']

        llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far'] 
        llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']


    def update_c_to_sb(self,llm_stats):
        llm_stats['sports_broadcasting_streak'] = 0
        llm_stats['num_blocks_since_sb'] = llm_stats['num_blocks_since_sb'] 

        llm_stats['commercial_streak'] = llm_stats['commercial_streak'] 
        llm_stats['sb_to_c_streak'] = 0
        llm_stats['c_to_c_streak'] = 0
        llm_stats['c_to_sb_streak'] += 1
        llm_stats['other_streak'] = 0

        llm_stats['num_blocks_since_c'] = llm_stats['num_blocks_since_c'] 

        llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']

        llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far'] 
        llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']

    def update_o(self,llm_stats):
        llm_stats['sports_broadcasting_streak'] = 0
        llm_stats['num_blocks_since_sb'] += 1

        llm_stats['commercial_streak'] = 0
        llm_stats['sb_to_c_streak'] = 0
        llm_stats['c_to_c_streak'] = 0
        llm_stats['c_to_sb_streak'] = 0
        llm_stats['other_streak'] += 1

        llm_stats['num_blocks_since_c'] += 1

        llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']

        llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far'] 
        llm_stats['other_blocks_so_far'] += 1

    def save_stats_to_db(self,llm_stats, key_id, stat_field):
        if stat_field == 'response_classification':
            self.save_stats_to_db_rc(llm_stats, key_id)
        elif stat_field == 'ground_truth_label_c':
            self.save_stats_to_db_gt(llm_stats, key_id)
        elif stat_field == 'windowed_resp_class_c':
            self.save_stats_to_db_wrcc(llm_stats, key_id)
        else:
            raise Exception(f"Unknown stat field: {stat_field} - can't save")
        
    def save_stats_to_db_wrcc(self,llm_stats, llm_predict_id):
        raise Exception("Not implemented yet")
    
    def save_stats_to_db_rc(self,llm_stats, llm_predict_id):
        to_save_llm_stats = copy.copy(llm_stats)
        to_save_llm_stats['llm_predict_id'] = llm_predict_id 
        uq = 'update llm_predictions set '
        uq = uq + ' sports_broadcasting_streak = :sports_broadcasting_streak, '
        uq = uq + ' num_blocks_since_sb = :num_blocks_since_sb, '    
        uq = uq + ' commercial_streak = :commercial_streak, '
        uq = uq + ' sb_to_c_streak = :sb_to_c_streak, '
        uq = uq + ' c_to_c_streak = :c_to_c_streak, ' 
        uq = uq + ' c_to_sb_streak = :c_to_sb_streak, ' 
        uq = uq + ' other_streak = :other_streak, '   
        uq = uq + ' num_blocks_since_c = :num_blocks_since_c, '   
        uq = uq + ' sb_blocks_so_far = :sb_blocks_so_far, '    
        uq = uq + ' c_blocks_so_far = :c_blocks_so_far, '
        uq = uq + ' other_blocks_so_far = :other_blocks_so_far '    
        uq = uq + ' where llm_predict_id =:llm_predict_id '
        rs = self.db.engine.execute(sqlalchemy.text(uq), to_save_llm_stats)

    def save_stats_to_db_gt(self,llm_stats, block_id):
        # serious hack to re-use the id of the foreign key. it is a 1:1 dependent table though
        to_save_llm_stats = copy.copy(llm_stats)
        to_save_llm_stats['text_block_stat_id'] = block_id 
        to_save_llm_stats['block_id'] = block_id 
        uq = 'delete from text_block_stat where text_block_stat_id = :text_block_stat_id   '
        uq = ' insert into text_block_stat'
        uq = uq + '(sports_broadcasting_streak, '
        uq = uq + ' num_blocks_since_sb, '    
        uq = uq + ' commercial_streak, '
        uq = uq + ' num_blocks_since_c, '   
        uq = uq + ' sb_blocks_so_far, '    
        uq = uq + ' c_blocks_so_far, '
        uq = uq + ' block_id, '    
        uq = uq + ' text_block_stat_id ) '    
        uq = uq + ' values( :sports_broadcasting_streak, '
        uq = uq + '  :num_blocks_since_sb, '    
        uq = uq + '  :commercial_streak, '
        uq = uq + '  :num_blocks_since_c, '   
        uq = uq + '  :sb_blocks_so_far, '    
        uq = uq + '  :c_blocks_so_far, '
        uq = uq + '  :block_id, '            
        uq = uq + '  :text_block_stat_id ) '  
        rs = self.db.engine.execute(sqlalchemy.text(uq), to_save_llm_stats)


    def update_llm_stats(self,exp_name, stat_field = 'response_classification'):
        key_id = None
        if stat_field == 'response_classification':
            q = 'SELECT t.session_id, t.block_id, t.sequence_num, l.response_classification, l.llm_predict_id, l.llm_exp_name'
            q = q + ' FROM text_blocks t, llm_predictions l'
            q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
            key_id = 'llm_predict_id'
        elif stat_field == 'ground_truth_label_c':
            # using CASE to avoid changing field names for this case. Rework this function when dropping the 5 labels to 2 in code base
            q = 'SELECT t.session_id, t.block_id, t.sequence_num, '
            q = q + ' CASE WHEN t.ground_truth_label_c = 0 THEN "SPORTS_BROADCASTING" '
            q = q + ' WHEN t.ground_truth_label_c = 1 THEN "COMMERCIAL" ' 
            q = q + ' END as response_classification, '           
            q = q + ' l.llm_predict_id, l.llm_exp_name'
            q = q + ' FROM text_blocks t, llm_predictions l'
            q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
            key_id = 'block_id'
        elif stat_field == 'windowed_resp_class_c':
            # using CASE to avoid changing field names for this case. Rework this function when dropping the 5 labels to 2 in code base
            q = 'SELECT t.session_id, t.block_id, t.sequence_num, '
            q = q + ' CASE WHEN l.windowed_resp_class_c = 0 THEN "SPORTS_BROADCASTING" '
            q = q + ' WHEN l.windowed_resp_class_c = 1 THEN "COMMERCIAL" ' 
            q = q + ' END as response_classification, '           
            q = q + ' l.llm_predict_id, l.llm_exp_name'
            q = q + ' FROM text_blocks t, llm_predictions l'
            q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
            key_id = 'llm_predict_id'
        else:
            raise Exception(f"Unrecognized stat_field: {stat_field}")

        rs = self.db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)

        prev_session_id = -1
        for row in rs:
            if row['session_id'] != prev_session_id:
                print('New session')
                llm_stats = self.re_init_stats()            
                prev_session_id = row['session_id']           
                # relax the rule that it needs to start with 1 for every session
                #if row['sequence_num'] != 1:
                #    raise Exception('Invalid order for llm prediction in update_llm_stats')
            else:
                if row['sequence_num'] != prev_sequence_num + 1:
                    raise Exception('Invalid order for llm prediction in update_llm_stats')
                
            # Once I am sure we are doing measuring stats around transition classes, simplify this to just 2 choices
            # currently text blocks will only have SPORTS_BROADCASTING or COMMERCIAL values so these extra checks are dormant
            if row['response_classification'] == 'SPORTS_BROADCASTING':
                self.update_sb(llm_stats)
            
            if row['response_classification'] == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
                self.update_sb_to_c(llm_stats)

            if row['response_classification'] == 'COMMERCIAL':
                self.update_c(llm_stats)

            if row['response_classification'] == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
                self.update_c_to_c(llm_stats)

            if row['response_classification'] == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
                self.update_c_to_sb(llm_stats)

            if row['response_classification'] == 'OTHER':
                self.update_o(llm_stats)
            
            self.save_stats_to_db(llm_stats, row[key_id], stat_field )

            prev_session_id = row['session_id']
            prev_sequence_num = row['sequence_num']

            #print(llm_stats)
        return

