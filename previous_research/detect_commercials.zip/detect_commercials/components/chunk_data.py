# -*- coding: utf-8 -*-

# region Description
"""
chunk_data.py: Create and save metadata of each chunk from a file
"""
# endregion

from models import ChunksEntity
from components.log_writers import LogWriters
from components.session_data import SessionData


class ChunkData:
    @staticmethod
    def print_out_chunks_entity(chunks_entity: ChunksEntity):
        cur_chunk_start = chunks_entity.cur_chunk_start.strftime(
            "%H:%M:%S")
        cur_chunk_end = chunks_entity.cur_chunk_end.strftime(
            "%H:%M:%S")
        transcription_date = chunks_entity.trans_dt.strftime(
            "%Y-%m-%d %H:%M:%S")

        print(f"---\nCHUNK ID: {chunks_entity.chunk_id}")
        print(f"SESSION ID: {chunks_entity.session_id}")
        print(f"SEQUENCE NUM: {chunks_entity.sequence_num}")
        print(f"TRANS DT: {transcription_date}")
        print(f"SOURCE ID: {chunks_entity.source_id}")
        print(f"CUR CHUNK: {chunks_entity.cur_chunk}")
        print(f"CUR CHUNK START: {cur_chunk_start}")
        print(f"CUR CHUNK END: {cur_chunk_end}")
        print(f"GROUND TRUTH LABEL: {chunks_entity.ground_truth_label}\n")
        print(f"GROUND TRUTH LABEL NUM: {chunks_entity.ground_truth_label_num}\n")
        print(f"GROUND TRUTH LABEL C: {chunks_entity.ground_truth_label_c}\n")
        print(f"MAJOR TRANS TIMESTAMP: {chunks_entity.major_trans_timestamp}\n")
        print(f"FIRST SENT TO SECOND STATE: {chunks_entity.first_sent_to_second_state}\n")

    @staticmethod
    def read_all_chunk_data(db_session, is_automatic_read, current_session_id):
        # Reads and prints all data from the database
        results = db_session.query(ChunksEntity).all()

        for r in results:
            ChunkData.print_out_chunks_entity(r)
            if not is_automatic_read:
                input()

        message = f"read_all_data -> Printed a total of {len(results)} chunk data"
        LogWriters.log_general_session(message, current_session_id, 'i')
        SessionData.modify_session_data(db_session, current_session_id, "s")
        print(f"TOTAL ENTITIES: {len(results)}")

    @staticmethod
    def read_one_chunk_data(id, db_session, current_session_id):
        # Get a single row data based on id
        result = db_session.query(ChunksEntity).filter(
            ChunksEntity.chunk_id == id).first()

        if result:
            ChunkData.print_out_chunks_entity(result)
            message = f"get_one_data -> Got one chunk entity with id {id}"
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")
        else:
            message = f"get_one_data -> No matching chunk entity with id {id} was found"
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")
            print(message)

    @staticmethod
    def delete_all_chunk_data(db_session, current_session_id):
        # Deletes all row data from the database
        db_session.query(ChunksEntity).delete()
        db_session.commit()

        message = "delete_all_data -> Deleted all chunk data"
        LogWriters.log_general_session(message, current_session_id, 'i')
        SessionData.modify_session_data(db_session, current_session_id, "s")
        print("SUCCESSFULLY DELETED ALL CHUNK DATA")

    @staticmethod
    def delete_one_chunk_data(id, db_session, current_session_id):
        # Deletes a single row data based on id
        entity_to_delete = db_session.query(
            ChunksEntity).filter(ChunksEntity.chunk_id == id).first()

        if entity_to_delete:
            # Delete the entity
            db_session.delete(entity_to_delete)
            db_session.commit()
            message = f"delete_one_data -> Entity with id {id} deleted successfully"
            print(message)
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")
        else:
            message = f"delete_one_data -> No matching chunk entity with id {id} was found"
            print(message)
            LogWriters.log_general_session(message, current_session_id, 'i')
            SessionData.modify_session_data(
                db_session, current_session_id, "s")

