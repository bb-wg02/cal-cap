NONE_TYPE_FOR_NEPT = '-'

class CommDetectUtils():    
    @staticmethod
    def nept_send_params(run, key, myparams):
        no_none_types_p_dict = {}
        p_dict = myparams.convert_to_dict()
        for pkey, pvalue in p_dict.items():
            if p_dict[pkey] is None:
                no_none_types_p_dict[pkey]= NONE_TYPE_FOR_NEPT
            else:
                no_none_types_p_dict[pkey] = pvalue
        run[key] = no_none_types_p_dict
