class bb_util:
    @staticmethod
    def get_class_num(class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 2
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 3
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 4
        elif class_code == 'OTHER':
            return 5