# post_llm_input_processor.py
# Help get inputs to the model that runs after the LLM makes its predictions

import sqlalchemy
import pandas as pd
from sklearn.model_selection import train_test_split

TEST_SPLIT_SIZE = 0.2
CLASS_BIN = 'bin'
CLASS_MULTI = 'multi'

class PostLLMUtils():
    
    def get_post_llm_input_X_y_data(self, db,exp_name,game_session_filter):
        if game_session_filter is not None:
            # only game filter allowed right now is a string representing an integer
            # other formats will not return results
            qf = ' and p.llm_exp_name = :v_parameter1 and t.session_id = :v_parameter2 '
            p_dict = {'v_parameter1':exp_name, 'v_parameter2':game_session_filter}            
        else:
            qf = ' and p.llm_exp_name = :v_parameter1 '
            p_dict = {"v_parameter1":exp_name}
        
        # return block_id also for reconciliation later in pipeline
        q = 'select '
        q = q + 'p.response_classification_c, p.response_classification_num, '
        q = q + ' p.sports_broadcasting_streak, p.commercial_streak, '
        q = q + ' p.other_streak, p.sb_to_c_streak, p.c_to_c_streak, p.c_to_sb_streak,'
        q = q + ' p.sb_blocks_so_far, p.c_blocks_so_far, p.other_blocks_so_far,  p.num_blocks_since_sb,'
        q = q + '  p.num_blocks_since_c, t.sequence_num,'
        q = q + ' t.ground_truth_label_c, t.ground_truth_label_num '
        q = q + ', p.windowed_resp_class_c, t.block_id '
        q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
        q = q + qf
        q = q + ' order by t.session_id, t.sequence_num '
        rs = db.engine.execute(sqlalchemy.text(q), p_dict) 
        df_X_y = pd.DataFrame(rs.fetchall(), columns=rs.keys())
        return df_X_y

    
    def get_X_data_for_stage_2_binary(self,df_X_y):
        df_features_w_id = df_X_y[[ \
            "response_classification_c","sports_broadcasting_streak",\
                            "commercial_streak","other_streak","sb_blocks_so_far",\
                                "c_blocks_so_far","num_blocks_since_c",\
                                    "sb_to_c_streak", "c_to_c_streak", "c_to_sb_streak",\
                                        "other_blocks_so_far", "num_blocks_since_sb", "sequence_num", "windowed_resp_class_c","block_id"]]
                                        #"other_blocks_so_far", "num_blocks_since_sb", "sequence_num"]]
        return df_features_w_id

    
    def get_y_data_for_stage_2_binary(self,df_X_y):
        df_y = df_X_y["ground_truth_label_c"]    
        return df_y

    
    def get_X_data_for_stage_2_multi(self,df_X_y):
        df_features_w_id = df_X_y[[ \
            "response_classification_num","sports_broadcasting_streak",\
                            "commercial_streak","other_streak","sb_blocks_so_far",\
                                "c_blocks_so_far","num_blocks_since_c",\
                                    "sb_to_c_streak", "c_to_c_streak", "c_to_sb_streak",\
                                        "other_blocks_so_far", "num_blocks_since_sb", "sequence_num", "windowed_resp_class_c", "block_id"]]
                                        #"other_blocks_so_far", "num_blocks_since_sb", "sequence_num"]]
        return df_features_w_id

    
    def get_y_data_for_stage_2_multi(self,df_X_y):
        df_y = df_X_y["ground_truth_label_num"]    
        return df_y
    
    
    def get_data(self,db, exp_name, bin_or_multi, llm_stage_exp_filter, game_session_filter):
        if llm_stage_exp_filter is not None:
            exp_filter_to_use = llm_stage_exp_filter 
        else:
            exp_filter_to_use = exp_name
        # this will have block_id in it            
        df_X_y = self.get_post_llm_input_X_y_data(db,exp_filter_to_use,game_session_filter)
        if bin_or_multi == CLASS_BIN:
            df_X_w_id = self.get_X_data_for_stage_2_binary(df_X_y)
            df_y = self.get_y_data_for_stage_2_binary(df_X_y)
        elif bin_or_multi == CLASS_MULTI:
            df_X_w_id = self.get_X_data_for_stage_2_multi(df_X_y)
            df_y = self.get_y_data_for_stage_2_multi(df_X_y)
        else:
            raise Exception('Asking for class of data that is not available')
                
        return df_X_w_id, df_y


    def train_test_split(self, X, y, y_stratify_label):
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SPLIT_SIZE,stratify=y_stratify_label)
        # default is to use k-fold validation so no explicit valiation set created
        return X_train, y_train, X_test, y_test



