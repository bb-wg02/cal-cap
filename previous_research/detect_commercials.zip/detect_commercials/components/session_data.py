# -*- coding: utf-8 -*-

# region Description
"""
session_data.py: Create and save metadata of each session or whenever a user uses the app
"""
# endregion

from models import SessionEntity
from components.log_writers import LogWriters
import os


class SessionData:
    @staticmethod
    def get_new_session_id(db_session):
        # Get latest session data or the last row from the database
        last_row = db_session.query(SessionEntity).order_by(
            SessionEntity.session_id.desc()).first()

        if last_row == None:
            # Session table is empty, return 0 as the default starting index
            return 0

        return last_row.session_id + 1

    @staticmethod
    def print_out_source_entity(session_entity: SessionEntity):
        session_time = session_entity.session_time.strftime(
            "%Y-%m-%d %H:%M:%S")

        print(f"---\nSESSION ID: {session_entity.session_id}")
        print(f"CUR CHUNK WINDOW: {session_entity.cur_chunk_window}")
        print(f"NUM PREV CHUNKS: {session_entity.num_prev_chunks}")
        print(f"DEFAULT IND: {session_entity.default_ind}")
        print(f"SESSION TIME: {session_time}")
        print(f"COMPLETION STATUS IND: {session_entity.completion_status_ind}")
        print(f"COMMAND: {session_entity.command}")
        print(f"SESSION LOG FILEPATH: {session_entity.session_log_filepath}")
        print(f"SESSION LOG FILENAME: {session_entity.session_log_filename}\n")

    @staticmethod
    def read_all_session_data(db_session, is_automatic_read):
        # Reads and prints all data from the database
        results = db_session.query(SessionEntity).all()

        for r in results:
            SessionData.print_out_source_entity(r)
            if not is_automatic_read:
                input()

        print(f"TOTAL SESSION ENTITIES: {len(results)}")

    @staticmethod
    def delete_all_session_data(db_session):
        # Deletes all row data from the database
        db_session.query(SessionEntity).delete()
        db_session.commit()

        print("SUCCESSFULLY DELETED ALL SESSION DATA")

    @staticmethod
    def create_session_data(db_session, cur_chunk_window, num_prev_chunks, argv_list, default_ind, status="r"):
        current_session_id = SessionData.get_new_session_id(db_session)

        file_path = f"{os.getcwd()}\\session_logs\\"
        file_name = f"session{current_session_id}.txt"
        str_argv_list = " ".join(argv_list)

        if current_session_id == None:
            message = "No session id was found"
            LogWriters.log_general_error(message)
            raise Exception(message)

        session_entity = SessionEntity(
            session_id=current_session_id,
            cur_chunk_window=cur_chunk_window,
            num_prev_chunks=num_prev_chunks,
            default_ind=default_ind,
            completion_status_ind=status,
            command=str_argv_list,
            session_log_filepath=file_path,
            session_log_filename=file_name
        )

        db_session.add(session_entity)
        db_session.commit()
        return current_session_id

    @staticmethod
    def modify_session_data(db_session, session_id, new_status):
        db_session.query(SessionEntity).filter(
            SessionEntity.session_id == session_id
        ).update({SessionEntity.completion_status_ind: new_status})
        db_session.commit()
