# -*- coding: utf-8 -*-

# region Description
"""
file_processor.py: Reads and processes text files and stores them in the database in chunks table
"""
# endregion

from components.log_writers import LogWriters
from components.session_data import SessionData
from components.source_data import SourceData
from models import ChunksEntity

from datetime import time
import re
import os
from loguru import logger as l


class FileProcessor:
    def __init__(self, db_session, current_source_id, current_session_id, cur_chunk_window, num_prev_chunks, max_file_size, target_file):
        self.db_session = db_session
        self.current_source_id = current_source_id
        self.current_session_id = current_session_id
        self.cur_chunk_window = cur_chunk_window
        self.num_prev_chunks = num_prev_chunks
        self.max_file_size = max_file_size
        self.target_file = target_file

    def file_exists(self):
        # Check if file exists
        if not os.path.exists(f"input_files/{self.target_file}"):
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, "e")
            message = f"The file \"{self.target_file}\" does not exists"
            LogWriters.log_general_session(
                message, self.current_session_id, 'e')
            LogWriters.log_general_error(message)
            SourceData.delete_source_data(
                self.db_session, self.current_source_id, self.current_session_id)
            raise Exception(message)

    def is_large_file(self, is_strict_mode):
        # Check for excessively large input file
        size_in_bytes = os.path.getsize(f"input_files/{self.target_file}")
        if size_in_bytes > self.max_file_size:
            if is_strict_mode:
                SessionData.modify_session_data(
                    self.db_session, self.current_session_id, "e")
                message = f"The file \"{self.target_file}\" is excessively large"
                LogWriters.log_general_session(
                    message, self.current_session_id, 'e')
                LogWriters.log_general_error(message)
                SourceData.delete_source_data(
                    self.db_session, self.current_source_id, self.current_session_id)
                raise Exception(message)
            else:
                message = f"The file \"{self.target_file}\" is excessively large"
                print(f"[WARNING] {message}")
                LogWriters.log_general_session(
                    message, self.current_session_id, 'w')
                LogWriters.log_general_warning(message)
                SessionData.modify_session_data(
                    self.db_session, self.current_session_id, "w")

    def get_latest_id(self):
        # Get latest data or the last row from the database
        last_row = self.db_session.query(ChunksEntity).order_by(
            ChunksEntity.chunk_id.desc()).first()
        if last_row != None:
            return last_row.chunk_id + 1
        else:
            return 0

    def save_chunk_in_db(self, chunk, sequence_number, cur_chunk_start, cur_chunk_end, tiny_bump_start=True):
        cur_chunk_start_date_list = cur_chunk_start.split(":")
        start_date_hour = int(cur_chunk_start_date_list[0])
        if start_date_hour > 23:
            start_date_hour -= 1
        start_date_minute = int(cur_chunk_start_date_list[1])
        if start_date_minute > 59:
            start_date_minute -= 1

        if not "." in cur_chunk_start_date_list[2]:
            cur_chunk_start_date_list[2] = cur_chunk_start_date_list[2] + ".000"

        start_date_sec = int(cur_chunk_start_date_list[2].split(".")[0])
        if start_date_sec > 59:
            start_date_sec -= 1
        start_date_microsec = int(cur_chunk_start_date_list[2].split(".")[1])

        # spec change/clarification - do not want start of next chunk to be exactly equal to end of previous
        # the way the string processing is working, the only  place to adjust is inside this routine
        if tiny_bump_start:
            if start_date_microsec < 999:
                start_date_microsec +=1
            else:
                l.warning("start date microsecond greater than 999 {}, start_data_microsec")
        final_start_date = time(hour=start_date_hour, minute=start_date_minute,
                                second=start_date_sec, microsecond=start_date_microsec)

        cur_chunk_end_date_list = cur_chunk_end.split(":")
        end_date_hour = int(cur_chunk_end_date_list[0])
        if end_date_hour > 23:
            end_date_hour -= 1
        end_date_minute = int(cur_chunk_end_date_list[1])
        if end_date_minute > 59:
            end_date_minute -= 1

        if not "." in cur_chunk_end_date_list[2]:
            cur_chunk_end_date_list[2] = cur_chunk_end_date_list[2] + ".000"

        end_date_sec = int(cur_chunk_end_date_list[2].split(".")[0])
        if end_date_sec > 59:
            end_date_sec -= 1
        end_date_microsec = int(cur_chunk_end_date_list[2].split(".")[1])
        final_end_date = time(hour=end_date_hour, minute=end_date_minute,
                              second=end_date_sec, microsecond=end_date_microsec)

        chunks_entity = ChunksEntity(
            chunk_id=self.get_latest_id(),
            session_id=self.current_session_id,
            sequence_num=sequence_number,
            source_id=self.current_source_id,
            cur_chunk=chunk,
            cur_chunk_start=final_start_date,
            cur_chunk_end=final_end_date,
            ground_truth_label="None",
            ground_truth_label_num="None",
            ground_truth_label_c="None",)

        self.db_session.add(chunks_entity)
        self.db_session.commit()

    def first_stage_preprocessing(self, is_strict_mode):
        # Checks for unbalance brackets and raises an error
        LogWriters.log_general_session(
            f"First stage processing file {self.target_file}", self.current_session_id, "i")
        is_inside_bracket = False

        def unbalance_bracket_error():
            message = f"Unbalance bracket detected on file {self.target_file}"
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, "e")
            LogWriters.log_general_error(message)
            LogWriters.log_general_session(
                message, self.current_session_id, "e")
            SourceData.delete_source_data(
                self.db_session, self.current_source_id, self.current_session_id)
            raise Exception(message)

        def non_ascii_detect_error(char):
            # Check for non-ascii characters
            message = f"Non-ascii character detected -> {char}"
            LogWriters.log_general_error(message)
            LogWriters.log_general_session(
                message, self.current_session_id, "e")
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, "e")
            SourceData.delete_source_data(
                self.db_session, self.current_source_id, self.current_session_id)
            raise Exception(message)

        with open(f"input_files/{self.target_file}", "r", encoding="utf-8") as f:
            for line in f:
                for char in line:
                    if ord(char) > 127 and is_strict_mode:
                        non_ascii_detect_error(char)

                    if char == "[" and is_inside_bracket:
                        unbalance_bracket_error()
                    elif char == "]" and not is_inside_bracket:
                        unbalance_bracket_error()

                    if char == "[":
                        is_inside_bracket = True
                        continue
                    elif char == "]":
                        is_inside_bracket = False
                        continue

        LogWriters.log_general_session(
            f"First stage successfully processed file {self.target_file}", self.current_session_id, "i")

    def process_data_from_file(self, is_strict_mode):
        LogWriters.log_general_session(
            f"Processing file {self.target_file}", self.current_session_id, "i")

        # First stage processing checks for unbalance brackets and non-ascii character
        self.first_stage_preprocessing(is_strict_mode)
        # After first stage processing is done, it is assume that the file is clean and is ready to be stored in the database.

        pattern = r'(\[([\d:.]+)\])'
        current_chunk = ""
        suspected_timestamp = ""

        cur_chunk_start = "00:00:00.000"
        cur_chunk_end = ""
        is_inside_bracket = False

        sequence_number = 1
        f = open(f"input_files/{self.target_file}", "r", encoding="utf-8")

        for line in f:
            for char in line:
                # Check for non-ascii characters
                if ord(char) > 127 and is_strict_mode:
                    message = "Non-ascii character detected"
                    LogWriters.log_general_error(message)
                    LogWriters.log_general_session(
                        message, self.current_session_id, "e")
                    SessionData.modify_session_data(
                        self.db_session, self.current_session_id, "e")
                    SourceData.delete_source_data(
                        self.db_session, self.current_source_id, self.current_session_id)
                    raise Exception(message)
                elif ord(char) > 127 and not is_strict_mode:
                    # Do not pass non-ascii character data to db
                    message = f"Non ascii character detected, not saving this to database -> {char}"
                    LogWriters.log_general_warning(message)
                    LogWriters.log_general_session(
                        message, self.current_session_id, "w")
                    SessionData.modify_session_data(
                        self.db_session, self.current_session_id, "w")
                    continue

                # Check for unbalance and nested brackets
                if char == "[" and is_inside_bracket:
                    message = "Nested bracket detected"
                    LogWriters.log_general_error(message)
                    LogWriters.log_general_session(
                        message, self.current_session_id, "e")
                    SessionData.modify_session_data(
                        self.db_session, self.current_session_id, "e")
                    SourceData.delete_source_data(
                        self.db_session, self.current_source_id, self.current_session_id)
                    raise Exception(message)
                elif char == "]" and not is_inside_bracket:
                    message = "Unbalance bracket detected"
                    LogWriters.log_general_error(message)
                    LogWriters.log_general_session(
                        message, self.current_session_id, "e")
                    SessionData.modify_session_data(
                        self.db_session, self.current_session_id, "e")
                    SourceData.delete_source_data(
                        self.db_session, self.current_source_id, self.current_session_id)
                    raise Exception(message)

                # Check if current character is "[]"
                if char == "[":
                    suspected_timestamp += char
                    is_inside_bracket = True
                    continue
                elif char == "]":
                    suspected_timestamp += char
                    is_inside_bracket = False

                    # Check if characters inside the bracket is a valid timestamp
                    is_timestamp = bool(
                        re.match(pattern, suspected_timestamp))
                    if is_timestamp:
                        with open(f"processed_files/{self.target_file}", "a", encoding="utf-8") as f:
                            f.write(current_chunk)
                        cur_chunk_end = suspected_timestamp.replace(
                            "[", "").replace("]", "")

                        # Save chunk into database
                        self.save_chunk_in_db(
                            chunk=current_chunk,
                            sequence_number=sequence_number,
                            cur_chunk_start=cur_chunk_start,
                            cur_chunk_end=cur_chunk_end
                        )

                        sequence_number += 1
                        # goign to change this so start 000001 bigger than previous end
                        #cur_chunk_start = cur_chunk_end + '001'
                        # remove - not working right
                        cur_chunk_start = cur_chunk_end 
                    else:
                        message = f"This is not a timestamp, not saving this to database -> {suspected_timestamp}"
                        LogWriters.log_general_warning(message)
                        LogWriters.log_general_session(
                            message, self.current_session_id, "w")
                        SessionData.modify_session_data(
                            self.db_session, self.current_session_id, "w")

                    current_chunk = ""
                    suspected_timestamp = ""
                    continue

                if is_inside_bracket:
                    suspected_timestamp += char
                else:
                    current_chunk += char

        f.close()

        LogWriters.log_general_session(
            f"Successfully processed file {self.target_file}", self.current_session_id, "i")
        SessionData.modify_session_data(
            self.db_session, self.current_session_id, "s")
