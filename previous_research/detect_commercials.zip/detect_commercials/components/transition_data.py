from components.log_writers import LogWriters
from components.session_data import SessionData
from models import TransitionsEntity


class TransitionData:
    @staticmethod
    def print_out_transition_data(transitions_entity: TransitionsEntity):
        timestamp = transitions_entity.timestamp.strftime(
            "%H:%M:%S")
        last_modify_dt = transitions_entity.last_modify_dt.strftime(
            "%Y-%m-%d %H:%M:%S")

        print(f"---\nTRANSITION ID: {transitions_entity.transition_id}")
        print(f"TRANSITION CODE: {transitions_entity.transition_code}")
        print(f"TIMESTAMP: {timestamp}")
        print(
            f"TRANSITION EXCEL FILE NAME: {transitions_entity.transition_excel_filename}")
        print(
            f"TRANSITION EXCEL FILE PATH: {transitions_entity.transition_excel_filepath}")
        print(f"SOURCE FILE NAME: {transitions_entity.source_filename}")
        print(f"SOURCE FILE PATH: {transitions_entity.source_file_path}")
        print(f"LAST MODIFY DT: {last_modify_dt}")
        print(f"SOURCE ID: {transitions_entity.source_id}")
        mt_timestamp = transitions_entity.major_trans_timestamp.strftime(
            "%H:%M:%S")
        print(f"MAJOR TRANSITION TIMESTAMP: {mt_timestamp}")
        print(f"FIRST SENT TO SECOND STATE: {transitions_entity.first_sent_to_second_state}")

    @staticmethod
    def read_all_transition_data(db_session, is_automatic_read, current_session_id):
        # Reads and prints all data from the database
        results = db_session.query(TransitionsEntity).all()

        for r in results:
            TransitionData.print_out_transition_data(r)
            if not is_automatic_read:
                input()

        message = f"read_all_data -> Printed a total of {len(results)} transition data"
        LogWriters.log_general_session(message, current_session_id, 'i')
        SessionData.modify_session_data(db_session, current_session_id, "s")
        print(f"TOTAL ENTITIES: {len(results)}")

    @staticmethod
    def delete_all_transition_data(db_session, current_session_id):
        # Deletes all row data from the database
        db_session.query(TransitionsEntity).delete()
        db_session.commit()

        message = "Successfully deleted all transition data"
        LogWriters.log_general_session(message, current_session_id, "i")
        SessionData.modify_session_data(db_session, current_session_id, "s")
        print("SUCCESSFULLY DELETED ALL TRANSITION DATA")
