# -*- coding: utf-8 -*-

# region Description
"""
source_data.py: Create and save metadata of the target file
"""
# endregion

from models import SourceEntity
from components.log_writers import LogWriters
import datetime
import os


class SourceData:
    @staticmethod
    def get_new_source_id(db_session, file_name):
        # Get latest source data or the last row from the database
        last_row = db_session.query(SourceEntity).order_by(
            SourceEntity.source_id.desc()).first()

        if last_row == None:
            # Source table is empty, return 0 as the default starting index
            return 0

        file_path = f"{os.getcwd()}\\input_files"
        query_same_file_path = db_session.query(SourceEntity).filter(
            SourceEntity.file_path == file_path, SourceEntity.file_name == file_name).first()

        if query_same_file_path:
            # Checks if the file has already been processed before by checking database record. Return the source id of that record if found
            return query_same_file_path.source_id

        # Otherwise the file hasn't been processed before so we create new id
        return last_row.source_id + 1

    @staticmethod
    def print_out_source_entity(source_entity: SourceEntity):
        last_modified = source_entity.last_modified.strftime(
            "%Y-%m-%d %H:%M:%S")

        print(f"---\nSOURCE ID: {source_entity.source_id}")
        print(f"FILE NAME: {source_entity.file_name}")
        print(f"FILE PATH: {source_entity.file_path}")
        print(f"DESCRIPTION: {source_entity.description}")
        print(f"LAST MODIFIED: {last_modified}")
        print(f"CATEGORY: {source_entity.category}")
        print(f"SUB CATEGORY: {source_entity.sub_category}\n")

    @staticmethod
    def read_all_source_data(db_session, is_automatic_read):
        # Reads and prints all data from the database
        results = db_session.query(SourceEntity).all()

        for r in results:
            SourceData.print_out_source_entity(r)
            if not is_automatic_read:
                input()

        print(f"TOTAL SOURCE ENTITIES: {len(results)}")

    @staticmethod
    def delete_source_data(db_session, current_source_id, current_session_id):
        entity_to_delete = db_session.query(SourceEntity).filter(
            SourceEntity.source_id == current_source_id).first()

        if entity_to_delete:
            LogWriters.log_general_session(
                f"Source entity with id {current_source_id} will be deleted", current_session_id, "i")
            # Delete the source entity
            db_session.delete(entity_to_delete)
            db_session.commit()

    @staticmethod
    def delete_all_source_data(db_session):
        # Deletes all row data from the database
        db_session.query(SourceEntity).delete()
        db_session.commit()

        print("SUCCESSFULLY DELETED ALL SOURCE DATA")

    @staticmethod
    def create_source_data(db_session, current_source_id, current_session_id, file_name):
        file_path = f"{os.getcwd()}\\input_files\\"
        query_same_file_path = db_session.query(SourceEntity).filter(
            SourceEntity.file_path == file_path, SourceEntity.file_name == file_name).all()

        if len(query_same_file_path) > 0:
            # Checks if the file has already been processed before by checking database record
            message = f"The file {file_path}\\{file_name} has already been processed before"
            LogWriters.log_general_session(message, current_session_id, 'w')
            LogWriters.log_general_warning(message)
            print(f"[WARNING] {message}")
            return

        timestamp = os.stat(f"input_files\\{file_name}").st_mtime
        last_modified_date = datetime.datetime.fromtimestamp(timestamp)

        source_entity = SourceEntity(
            source_id=current_source_id,
            file_name=file_name,
            file_path=file_path,
            description="None",
            last_modified=last_modified_date,
            category="None",
            sub_category="None")

        db_session.add(source_entity)
        db_session.commit()
