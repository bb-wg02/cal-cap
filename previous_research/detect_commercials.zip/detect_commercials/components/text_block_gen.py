from loguru import logger as l
from time import sleep
import copy
from nltk.downloader import Downloader
import dataset
import nltk
from nltk import download as nltk_download

from models import Base

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import components.llm_stats as llm_stats
from models import TextBlocksEntity

# this download process here seems a hack and hard to share code now?
# workarounds on stackechange didn't work
nltk_download('punkt')

engine = create_engine("sqlite:///db.db", echo=False)
Base.metadata.create_all(bind=engine)

# NOTE: SESSION IS NOT RELATED TO SESSION ENTITY SCHEMA IN THE DATABASE
Session = sessionmaker(bind=engine)
session = Session()

db = dataset.connect('sqlite:///db.db')
chunks = db['chunks']

class NLTools():
    def get_sentences_from_block(self,block):
        sentences = nltk.sent_tokenize(block["cur_chunk"])        
        # check for issues with result
        return sentences, len(sentences)

    def get_sentences_from_text(self,text):
        sentences = nltk.sent_tokenize(text)        
        # check for issues with result
        return sentences, len(sentences)


class BlockGen():
    def __init__(self, db_session):
        self.db_session = db_session
     
    # 3rd time creatingg these functions - centralize and rationalize to 1 function
    def get_class_num(self,class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 2
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 3
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 4
        elif class_code == 'OTHER':
            return 5

    def get_class_c(self,class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 1
        elif class_code == 'OTHER':
            return 0


    def get_prev_blocks(self,block,num_prev_blocks):
        prev_blocks = []
        # Assumes a prev_block_link field exists
        loop_block = block['prev_block_link']
        valid_prev_block_count = 0
        while valid_prev_block_count < num_prev_blocks:
            if loop_block is None:
                break
            if loop_block['block_id'] is not None:
                prev_blocks.append(loop_block)
                valid_prev_block_count +=1
            loop_block = loop_block['prev_block_link']
        return prev_blocks


    def get_chunk_by_id(self, chunk_id):
        # should be only 1 chunk returned !
        chunks_found = chunks.find(chunk_id=chunk_id)        
        for chunk in chunks_found:
            first_and_only_chunk = chunk
            break
        return first_and_only_chunk
        


    def process_chunks(self,chunks):
        # most usage will be from outside calls to gen_blocks_from_chunk()
        # monitor if process_chunks() is useful anymore. if not, deco        
        prev_chunk = None
        prev_chunk_last_block = None
        prev_chunk_last_block_is_partial = False
        for chunk in chunks:
            # if this set of chunks is from different sessions then reset key state
            if (prev_chunk is not None) and (prev_chunk['session_id'] != chunk['session_id']):
                prev_chunk = None
                prev_chunk_last_block = None
                prev_chunk_last_block_is_partial = False

            # process each chunk
            # pass in what is needed from previous chunk
            # - was the last block of previous chunk a partial sentence? Id so, this chunk will complete it and proces
            # - what was the last block of the previous chunk? Need this to build a linked list of all blocks in session
            prev_chunk_last_block, prev_chunk_last_block_is_partial = self.gen_blocks_from_chunk(chunk, prev_chunk_last_block_is_partial, prev_chunk_last_block)                        
            prev_chunk = chunk


    def get_block_ground_truth(self,chunk, sentence_count):

        code_to_return = None
        if chunk['ground_truth_label'] == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            if sentence_count < chunk['first_sent_to_second_state']:
                code_to_return = 'SPORTS_BROADCASTING'
            else:                
                code_to_return = 'COMMERCIAL'

        if chunk['ground_truth_label'] == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            if sentence_count < chunk['first_sent_to_second_state']:
                code_to_return = 'COMMERCIAL'
            else:                
                code_to_return = 'SPORTS_BROADCASTING'

        if chunk['ground_truth_label'] == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            code_to_return = 'COMMERCIAL'

        if code_to_return is None:
            code_to_return = chunk['ground_truth_label']

        return code_to_return, self.get_class_num(code_to_return), self.get_class_c(code_to_return)
                

    def get_block_start_end(self,chunk, sentence_count):
            first_sent_to_second_state = chunk['first_sent_to_second_state']
            # if None, then this is not a block with a major transition, nothing to change
            if first_sent_to_second_state is None:
                start_time = chunk['cur_chunk_start']                
                end_time = chunk['cur_chunk_end']
            else:                                
                # don't squeeze the block start and end if all blocks will be one side of the transition
                if first_sent_to_second_state == 0 or first_sent_to_second_state == 1:
                    start_time = chunk['cur_chunk_start']                
                    end_time = chunk['cur_chunk_end']
                else:                    
                    # otherwise squeeze time of current block based on which side of transition it is on
                    if sentence_count < chunk['first_sent_to_second_state']:
                        start_time = chunk['cur_chunk_start']                
                        end_time = chunk['major_trans_timestamp']
                    else:                
                        start_time = chunk['major_trans_timestamp']
                        end_time = chunk['cur_chunk_end']
            return start_time, end_time

    def create_block_from_chunk(self,chunk, sentence, sentence_count):
        # session_id, source_id set by this copy() call
        # a few other fields copied but not sed by block,
        # such as major_trans_timestamp and first_sent_to_second_state
        # Clean this up        
        block = copy.copy(chunk) 

        #manually set the rest
        block['block_id'] = None
        block['sequence_num'] = None
        block['chunk_overlap_ind'] = None
        block['cur_chunk'] = sentence                
        b_gt_label, bg_gt_label_num, b_gt_label_c = self.get_block_ground_truth(chunk, sentence_count)
        block['ground_truth_label'] = b_gt_label
        block['ground_truth_label_num'] = bg_gt_label_num
        block['ground_truth_label_c'] = b_gt_label_c        
        b_start, b_end = self.get_block_start_end(chunk, sentence_count)
        block['cur_chunk_start'] = b_start
        block['cur_chunk_end'] = b_end
        # settings this for use later but doesn't save to DB
        block['prev_block_link'] = None

        return block
    
    def get_sentences_as_blocks(self,chunk, prev_chunk_last_block_is_partial, prev_chunk_last_block):
        if prev_chunk_last_block_is_partial:
            text_to_tokenize = prev_chunk_last_block['cur_chunk'] + chunk['cur_chunk']
            # Indicates that this block relied on previous chunk
            chunk_overlap_ind = "Y"
        else:
            text_to_tokenize = chunk['cur_chunk'] 
            # Indicates that this block did NOT rely on previous chunk to form the block
            chunk_overlap_ind = "N"

        nlt = NLTools()        
        sentences, _ = nlt.get_sentences_from_text(text_to_tokenize)    
        blocks = []        
        sentence_count = 1
        for sentence in sentences:            
            # block_id field will be None here - not set until saved to db
            block = self.create_block_from_chunk(chunk, sentence, sentence_count)            
            blocks.append(block)  
            sentence_count +=1          
        return blocks, chunk_overlap_ind # indicate whether or not this set of blocks relied on previous chunk
    
    def is_complete(self,block):        
        # for now assume block is a sentence
        sentence = block['cur_chunk']
        # Check if the last character is a period, question mark, or exclamation point
        last_char = sentence[-1]        
        return last_char in ['.', '?', '!']

    def get_latest_id(self):
        # Get latest data or the last row from the database
        last_row = self.db_session.query(TextBlocksEntity).order_by(
            TextBlocksEntity.block_id.desc()).first()
        if last_row != None:
            return last_row.block_id + 1
        else:
            return 0

    def get_latest_sequence(self, session_id):
        # Get latest data or the last row from the database
        last_row = self.db_session.query(TextBlocksEntity).filter(
            TextBlocksEntity.session_id == session_id).order_by(
            TextBlocksEntity.sequence_num.desc()).first()
        if last_row != None:
            return last_row.sequence_num + 1
        else:
            return 1

    def save_block_in_db(self,block, chunk_overlap_ind):
        block_id = self.get_latest_id()
        sequence_num = self.get_latest_sequence(block["session_id"])
        text_block_entity = TextBlocksEntity(
            block_id=block_id,
            session_id=block["session_id"],            
            sequence_num=sequence_num,
            source_id= block["source_id"],
            cur_chunk=block["cur_chunk"],
            cur_chunk_start=block["cur_chunk_start"],
            cur_chunk_end=block["cur_chunk_end"],
            ground_truth_label=block["ground_truth_label"],
            ground_truth_label_num=block["ground_truth_label_num"],
            ground_truth_label_c=block["ground_truth_label_c"],
            chunk_id=block["chunk_id"],
            # this is so future readers of this block can now that 
            # some of the text of the block came from the previous block
            chunk_overlap_ind=chunk_overlap_ind)            

        self.db_session.add(text_block_entity)
        self.db_session.commit()
        return block_id

    def save_eligible_blocks_to_db(self,blocks, chunk_overlap_ind):
        block_num = 1
        first_block = True        
        eligible_blocks = []
        for block in blocks:
            #The last block in a chunk will not be saved to db and will not get a block_id
            if self.is_complete(block) or block_num < len(blocks):                
                if first_block:                    
                    block['block_id'] = self.save_block_in_db(block, chunk_overlap_ind)
                    eligible_blocks.append(block)
                    first_block = False
                else:
                    # only the first block can have an overlap with the previous chunk
                    block['block_id'] = self.save_block_in_db(block, "N")                                            
                    eligible_blocks.append(block)
            block_num +=1
        return eligible_blocks

    def trim_links(self,block):
        depth_count = 0
        cur_block = block
        # assumes a prev_block_link field set up prior
        while depth_count < 10:
            if cur_block is not None:
                cur_block = cur_block['prev_block_link']
            else:
                break
            depth_count += 1
        if cur_block is not None:
            # hopefully this allows GC to clear up nested links
            cur_block['prev_link'] = None
        
    def gen_blocks_from_chunk(self,chunk, prev_chunk_last_block_is_partial, prev_chunk_last_block):                   

        # get text to tokenize, adding last sentence from previous chunk if it was incomplete
        # tokenize text into sentences which for now represent the concept of a block
        # for each sentence in sentences:
        #   define a block to hold this sentence
        # if the last sentence was not complete return last sentence
        # else return None

        # for now will assume a block is a single sentence within a chunk
        # make more generic and clever abstraction if needed
        # reminder on terms: overlap_ind is whether or not the first block of this set of blocks was built using previous chunk
        # is_partial is a signal to the system that when creating blocks that the last block of t he previous chunk was a partial sentence
        # right now you can assum that if the previous chunk's last block was a partial sentence, then 
        # the first block of the blocks that come back will have an overlap_ind = "Y" 
        # but  they in practice have the same value
        blocks, chunk_overlap_ind = self.get_sentences_as_blocks(chunk, prev_chunk_last_block_is_partial, prev_chunk_last_block)        
        # See if last block in blocks is a complete sentence
        if blocks:
            # write the blocks to db            
            self.save_eligible_blocks_to_db(blocks, chunk_overlap_ind)        
            if self.is_complete(blocks[-1]):            
                # no, last block is NOT a partial
                return blocks, False
            else:
                # yes, last block is a partial sentence
                return blocks, True
        else:
            # if no blocks in a chunk - should this code handle (raise)
            # or should it let caller deal with it?
            return None, False
        

if __name__ == "__main__":     
    pass


