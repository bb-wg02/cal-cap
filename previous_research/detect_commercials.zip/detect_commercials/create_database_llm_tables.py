import pandas as pd
from loguru import logger
import dataset
import arrow

db = dataset.connect('sqlite:///db.db')

# blocks = db.create_table('primary_vs_secondary_blocks', primary_id='block_id')
# blocks.create_column('session_id', db.types.integer)
# blocks.create_column('trans_dt', db.types.datetime)
# blocks.create_column('source_id', db.types.integer)
# blocks.create_column('cur_chunk_text', db.types.text)
# blocks.create_column('cur_chunk_start', db.types.text)
# blocks.create_column('cur_chunk_end', db.types.text)
# blocks.create_column('merged_chunk', db.types.text)
# blocks.create_column('sec_since_start', db.types.text)
# blocks.create_column('secs_since_last_p', db.types.text)
# blocks.create_column('secs_since_last_c', db.types.text)
# blocks.create_column('num_p_blocks', db.types.text)
# blocks.create_column('num_s_blocks', db.types.text)
# blocks.create_column('prediction', db.types.text)
# blocks.create_column('ground_truth_label', db.types.text)
#
# df = pd.read_excel('sample_input_to_LLM.xlsx', sheet_name='text_blocks', parse_dates=['trans_dt'])
# df.fillna('', inplace=True)
# for row in df.to_dict('records'):
#     row['trans_dt'] = arrow.get(row['trans_dt']).datetime
#     logger.info(row)
#     try:
#         blocks.insert(row)
#     except Exception as e:
#         logger.error(e)

llm_predictions = db.create_table('llm_predictions', primary_id='llm_predict_id')
llm_predictions.create_column('instr_prompt_used_name', db.types.text)
llm_predictions.create_column('instr_prompt_used_text', db.types.text)
llm_predictions.create_column('cur_block_id_used', db.types.text)
llm_predictions.create_column('text_chunk_used', db.types.text)
llm_predictions.create_column('llm_name', db.types.text)
llm_predictions.create_column('llm_other_params', db.types.text)
llm_predictions.create_column('fully_formed_request', db.types.text)
llm_predictions.create_column('requested_at', db.types.datetime)
llm_predictions.create_column('response_is_valid', db.types.boolean)
llm_predictions.create_column('response_text', db.types.text)
llm_predictions.create_column('requested_at', db.types.datetime)
llm_predictions.create_column('response_classification', db.types.text)
llm_predictions.create_column('response_confidence', db.types.text)
llm_predictions.create_column('response_at', db.types.datetime)
llm_predictions.create_column('code', db.types.text)
llm_predictions.create_column('response_confidence', db.types.integer)
llm_predictions.create_column('input_tokens', db.types.integer)
llm_predictions.create_column('output_tokens', db.types.integer)
llm_predictions.create_column('sports_broadcasting_streak', db.types.integer),
llm_predictions.create_column('commercial_streak', db.types.integer),
llm_predictions.create_column('sb_to_c_streak', db.types.integer),
llm_predictions.create_column('c_to_c_streak', db.types.integer),
llm_predictions.create_column('c_to_sb_streak', db.types.integer),
llm_predictions.create_column('c_blocks_so_far', db.types.integer),
llm_predictions.create_column('sb_blocks_so_far', db.types.integer),
llm_predictions.create_column('num_blocks_since_sb', db.types.integer),
llm_predictions.create_column('num_blocks_since_c', db.types.integer),
llm_predictions.create_column('llm_exp_name', db.types.text),
llm_predictions.create_column('response_classification_num', db.types.integer),
llm_predictions.create_column('other_blocks_so_far', db.types.integer),
llm_predictions.create_column('other_streak', db.types.integer),
llm_predictions.create_column('response_classification_c', db.types.integer)
llm_predictions.create_column('windowed_resp_class_c', db.types.integer)

instruction_prompts = db.create_table('instruction_prompts', primary_id='instr_id')
instruction_prompts.create_column('instr_name', db.types.text)
instruction_prompts.create_column('instr_descr', db.types.text)
instruction_prompts.create_column('instr_text', db.types.text)
instruction_prompts.create_column('last_modify_dt', db.types.datetime)
instruction_prompts.create_column('default_ind', db.types.boolean)
instruction_prompts.delete()

base_prompt = "You are a helpful assistant. Your goal is to correctly categorize the text in the section labeled data part 1.  The text in the section labeled data part 1 is part of the transcript from the audio recording of a television. The transcript includes every word spoken including the words spoken from the commercial breaks as well as the words spoken during the non-commercial, primary content of the TV broadcast. Evaluate the data in the section labeled data part 1 and tell me if you think it represents text from a TV commercial or the transcript from a sports broadcast. " \
+ " You are evaluating only a portion of the much longer transcript. The goal and challenge is to interpret the text in this context and categorize it." \
+ " Decide if text is one of these two categories : 'Commercial'or 'Sports Broadcast'" \
+ " Consider your rationale for the category you decided. Now read your rationale and use that to influence your final answer. So decide again. Use one of the two categories. Answer with no other words besides what I instruct. In 2 words or less, answer with one of these two phrases marked in single quotes no other words: 'Commercial' or 'Sports Broadcast'." 

ones_2opt_prompt = "You are a helpful assistant. Your goal is to correctly categorize the text in the section labeled data part 1.  The text in the section labeled data part 1 is part of the transcript from the audio recording of a television. The transcript includes every word spoken including the words spoken from the commercial breaks as well as the words spoken during the non-commercial, primary content of the TV broadcast. Evaluate the data in the section labeled data part 1 and tell me if you think it represents text from a TV commercial or the transcript from a sports broadcast. " 
+ " You are evaluating only a portion of the much longer transcript. The goal and challenge is to interpret the text in this context and categorize it." \
+ " Decide if text is one of these two categories : 'Commercial'or 'Sports Broadcast'" \
+ " Consider your rationale for the category you decided. Now read your rationale and use that to influence your final answer. So decide again. Use one of the two categories. Answer with no other words besides what I instruct. In 2 words or less, answer with one of these two phrases marked in single quotes no other words: 'Commercial' or 'Sports Broadcast'."

ones_2opt_prompt_desc = "1-sentence2 options"

ones_3opt_prompt = "You are a helpful assistant. Your goal is to correctly categorize the text in the section labeled data part 1.  The text in the section labeled data part 1 is part of the transcript from the audio recording of a television. The transcript includes every word spoken including the words spoken from the commercial breaks as well as the words spoken during the non-commercial, primary content of the TV broadcast. Evaluate the data in the section labeled 'data part 1' and tell me if you think it represents transcript from a TV commercial or the transcript from a sports broadcast. " \
+ " You are evaluating only a portion of the much longer transcript. The goal and challenge is to interpret the text in this context and categorize it." \
+ " If the text is about making a bet about sports or about sports betting terminology, then it is a commercial." \
+ " Decide if text is one of these three categories : 'Commercial' or 'Sports Broadcast' or 'Something Else' "\
+ " Consider your rationale for the category you decided. Now read your rationale and use that to influence your final answer. So decide again. Use one of the three categories. Answer with no other words besides what I instruct. In 2 words or less, answer with one of these three phrases marked in single quotes no other words: 'Commercial' or 'Sports Broadcast' or 'Something Else'"

ones_3opt_prompt_desc =  "1-sentence3 options"

instruction_prompts.insert(
    {
        'instr_id': 1,
        'instr_name': '1s-2opt',
        'instr_descr': ones_2opt_prompt_desc,
        'instr_text': ones_2opt_prompt,
        'last_modify_dt': arrow.now().date(),
        'default_ind': True,
    }
)

instruction_prompts.insert(
    {
        'instr_id': 2,
        'instr_name': '1s-3opt',
        'instr_descr': 'standard default instructions',
        'instr_text': ones_3opt_prompt,
        'last_modify_dt': arrow.now().date(),
        'default_ind': False,
    }
)

instruction_prompts.insert(
    {
        'instr_id': 3,
        'instr_name': 'standard',
        'instr_descr': ones_3opt_prompt_desc,
        'instr_text': base_prompt,
        'last_modify_dt': arrow.now().date(),
        'default_ind': False,
    }
)


text_block_stat = db.create_table('text_block_stat', primary_id='text_block_stat_id')
text_block_stat.create_column('sports_broadcasting_streak', db.types.integer),
text_block_stat.create_column('commercial_streak', db.types.integer),
text_block_stat.create_column('c_blocks_so_far', db.types.integer),
text_block_stat.create_column('sb_blocks_so_far', db.types.integer),
text_block_stat.create_column('num_blocks_since_sb', db.types.integer),
text_block_stat.create_column('num_blocks_since_c', db.types.integer),
text_block_stat.create_column('block_id', db.types.integer),

