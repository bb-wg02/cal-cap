import pandas as pd
from loguru import logger
import dataset
import arrow

db = dataset.connect('sqlite:///db.db')

text_block_stat = db.create_table('text_block_stat', primary_id='text_block_stat_id')
text_block_stat.create_column('sports_broadcasting_streak', db.types.integer),
text_block_stat.create_column('commercial_streak', db.types.integer),
text_block_stat.create_column('c_blocks_so_far', db.types.integer),
text_block_stat.create_column('sb_blocks_so_far', db.types.integer),
text_block_stat.create_column('num_blocks_since_sb', db.types.integer),
text_block_stat.create_column('num_blocks_since_c', db.types.integer),
text_block_stat.create_column('block_id', db.types.integer),

