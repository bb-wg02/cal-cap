import dataset
import matplotlib.pyplot as plt
import numpy as np
from sklearn.calibration import LabelEncoder
from sklearn.pipeline import Pipeline
import sqlalchemy
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix, recall_score, precision_score,f1_score
from sklearn.metrics import classification_report
import seaborn as sns
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import time
from sklearn.model_selection import learning_curve
import json
from loguru import logger as l


class AccuracyMetrics():
    @staticmethod
    def eval_accuracy_detail( exp_name, stage, nept_run, bin_or_multi, actual, predicted):

        cm = confusion_matrix(actual, predicted)

        # Check that resulting shape makes sense
        if (np.shape(cm) != (2,2)) and (bin_or_multi == 'binary'):
            l.error(f"unexpected shape of binary confusion matrix: {np.shape(cm)}. Skipping cm chart.")
            raise Exception('Unable to calculate CM')

        if (np.shape(cm) != (6,6)) and (bin_or_multi == 'multi'):
            if (np.shape(cm) != (5,5)) and (bin_or_multi == 'multi'):
                l.error(f"unexpected shape of multi confusion matrix: {np.shape(cm)}. Skipping cm chart.")            
                raise Exception('Unable to calculate CM')
                
        
        match bin_or_multi:       
            case 'binary':
                cm_df = pd.DataFrame(cm, index = ['YES','NO'],columns = ['YES','NO'])
                cm_title =  'Confusion Matrix for Commercial Detection (Yes/No)' + ' - ' + stage
                
            case 'multi':
                if (np.shape(cm) == (6,6)):            
                    cm_df = pd.DataFrame(cm,
                            index = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB','O'],  
                            columns = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB', 'O']) 
                # must be (5,5) given earlier sanity check
                else:
                    cm_df = pd.DataFrame(cm,
                            index = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB'],  
                            columns = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB']) 
                
                cm_title =  'Confusion Matrix for Commercial Transitions (Multiclass)' + ' - ' + stage                  

            case _:
                    exc_str = f"Only handles binary or multiclass. Received: {bin_or_multi}"
                    l.error(exc_str)            
                    raise Exception(exc_str)

        #Plotting the confusion matrix
        plt.figure(figsize=(10,8))
        sns.heatmap(cm_df, annot=True,  fmt=f'.{0}f')
        sns.heatmap(cm_df,
            vmin=cm_df.values.min(),
            vmax=cm_df.values.max(),
            square=True,
            cmap="YlGnBu",
            linewidths=0.1,
            annot=True,
            fmt=f'.{0}f',
            annot_kws={"size": 35 / np.sqrt(len(cm_df))})

        plt.title(cm_title)
        plt.ylabel('Actual Values')
        plt.xlabel('Predicted Values')    

        fig_file = f"./output/conf_mat_{stage}_{bin_or_multi}_{exp_name}.png"
        plt.savefig(fig_file)
        plt.clf()
        nept_run[f"cm_{stage}_{bin_or_multi}"].upload(fig_file)
        
               
        if (bin_or_multi == 'multi'):
            # These are the metrics that affect user experience the most so capture
            # (Don't want to miss content due to misclassification of SB)
            cl_rpt_dict = classification_report(actual, predicted, target_names=cm_df, output_dict=True)            
            nept_run[f"C_to_SB_f1-score_multi_{stage}"] = cl_rpt_dict['C_to_SB']['f1-score']  
            l.debug(f"C_to_SB_f1-score_multi_{stage} : {cl_rpt_dict['C_to_SB']['f1-score']}" )      
            nept_run[f"SB_f1-score_multi_{stage}"] = cl_rpt_dict['SB']['f1-score']
            l.debug(f"SB_f1-score_multi_{stage} : {cl_rpt_dict['SB']['f1-score']}" )      
        
        recall_score_macro = recall_score(actual, predicted, average='macro')
        nept_run[f"recall_score_macro_{bin_or_multi}_{stage}"] = recall_score_macro
        l.debug(f"recall_score_macro_{bin_or_multi}_{stage} : {recall_score_macro}" )   
        precision_score_macro = precision_score(actual, predicted, average='macro')
        nept_run[f"precision_score_macro_{bin_or_multi}_{stage}"] = precision_score_macro
        l.debug(f"precision_score_macro_{bin_or_multi}_{stage} : {precision_score_macro}" )   

        f1_score_macro = f1_score(actual, predicted, average='macro')
        nept_run[f"f1_score_macro_{bin_or_multi}_{stage}"] = f1_score_macro        
        l.debug(f"f1_score_macro_{bin_or_multi}_{stage} : {f1_score_macro}" )   

        bal_acc_score = balanced_accuracy_score( actual, predicted)
        nept_run[f"bal_acc_score_{bin_or_multi}_{stage}"] = bal_acc_score
        l.debug(f"bal_acc_score_{bin_or_multi}_{stage} : {bal_acc_score}" )   

        return bal_acc_score
    
    @staticmethod
    def eval_accuracy(exp_name, stage, nept_run, actual_binary, pred_binary, actual_multi, pred_multi):    
        AccuracyMetrics.eval_accuracy_detail(exp_name, stage, nept_run, 'binary', actual_binary, pred_binary)
        AccuracyMetrics.eval_accuracy_detail(exp_name, stage, nept_run, 'multi', actual_multi, pred_multi)

        
