# exec_post_llm_stage
import json
import requests
from loguru import logger as l
import dataset
import arrow
from time import sleep
import copy
import pandas as pd
from sklearn.model_selection import cross_validate
import sqlalchemy
import llm_stage_eval
import components.llm_stats as llm_stats
import neptune
import logreg_model
import xgboost_model
import numpy as np
import accuracy_metrics
import post_llm_stage_eval
import components.comm_detect_uitls as cd_utils

db = dataset.connect('sqlite:///db.db')


S2_MODEL_KEY = 's2_model'
EXP_NAME_KEY = 'exp_name'
INPUT_EXP_FILTER_KEY = 's2_input_exp_filter'
GAME_SESSION_FILER_KEY = 's2_game_session_filter'
N_ESTIMATORS_KEY = 's2_n_estimators'
MAX_DEPTH_KEY = 's2_max_depth'
LEARNING_RATE_KEY = 's2_learning_rate'
LOG_REG = 'log_reg'
XGB = 'xgb'
CLASS_BINARY = 'bin'
CLASS_MULTI = 'multi'
# CONFIG VALUES AS CONSTANTS FOR NOW. MOVE TO CMD LINE OR CONFIG LATER.
strict_mode = False


class PostLLMStageParams():
    def __init__(self, experiment_def_row):
        # pull relevant data from row and put in a params data structure
        self.exp_name = experiment_def_row[EXP_NAME_KEY]
        self.llm_stage_exp_filter = experiment_def_row[INPUT_EXP_FILTER_KEY]
        self.game_session_filter =  experiment_def_row[GAME_SESSION_FILER_KEY]
        self.model =  experiment_def_row[S2_MODEL_KEY]
        self.penalty_binary = 'l2'
        self.C_binary = 1   
        self.penalty_multi = 'l2' 
        self.C_multi = 1
        self.n_estimators = experiment_def_row[N_ESTIMATORS_KEY]
        self.max_depth =experiment_def_row[MAX_DEPTH_KEY]
        self.learning_rate = experiment_def_row[LEARNING_RATE_KEY]

    def convert_to_dict(self):
        p_dict = copy.copy(self.__dict__)
        return p_dict

class PostLLMStage():
    def __init__(self, params):
         self.params = params    


#### Begining of code that needs to be moved to a utility function - near duplicate with exec_llm_stage.py code
    def get_actl_pred_llm_stage(self, exp_name, df_block_ids = None):
        #t.ground_truth_label_c
        q = 'select p.response_classification_c, p.response_classification_num, t.ground_truth_label_c, t.ground_truth_label_num, t.block_id '
        q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
        q = q + ' and p.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name) 
        df_act_pred = pd.DataFrame(rs)     
        if df_block_ids is not None:
            df_act_pred = pd.merge(df_act_pred, df_block_ids, on= 'block_id', how='inner')
        return df_act_pred


    def retrieve_fields_for_eval(self, rs, id_field, value_field, df_block_ids):
        results = []
        for rec in rs:
            if df_block_ids is not None and rec[id_field] in df_block_ids[id_field].values:
                result_rec = {}           
                result_rec["id"] = rec[id_field]
                result_rec["value"] = rec[value_field]            
                results.append(result_rec)
        return results


    def get_windowed_predictions(self,exp_name, df_block_ids = None):
        q = 'SELECT t.session_id, t.block_id, t.sequence_num, l.windowed_resp_class_c, l.llm_predict_id, l.llm_exp_name'
        q = q + ' FROM text_blocks t, llm_predictions l'
        q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        # really gotta clean up how I access DBs!
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
        raw_labels = self.retrieve_fields_for_eval(rs, "block_id", "windowed_resp_class_c",df_block_ids)
        return raw_labels


    def get_ground_truth_labels(self,exp_name, df_block_ids):
        q = 'SELECT t.session_id, t.block_id, t.sequence_num, t.ground_truth_label_c, l.llm_predict_id, l.llm_exp_name'
        q = q + ' FROM text_blocks t, llm_predictions l'
        q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
        # really gotta clean up how I access DBs!
        rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
        raw_labels = self.retrieve_fields_for_eval(rs, "block_id", "ground_truth_label_c", df_block_ids)
        return raw_labels

    def eval_llm_stage_by_ids(self,exp_name, run, df_block_ids, stage_desc):        
        # df_block_ids is a join condition so this eval runs only for a certain set of text_block_id records
        df_act_pred = self.get_actl_pred_llm_stage(exp_name, df_block_ids)
        actual_binary = df_act_pred['ground_truth_label_c']
        pred_binary = df_act_pred['response_classification_c']
        actual_multi = df_act_pred['ground_truth_label_num']
        pred_multi = df_act_pred['response_classification_num']
        l.info("\nCalculate accuracy for experiment: {} using all llm raw predictions in " + stage_desc, exp_name)
        llm_stage_eval.LLMStageEval.eval_accuracy(exp_name, run, actual_binary, pred_binary, actual_multi, pred_multi)
        w_preds_with_block_id = self.get_windowed_predictions(exp_name, df_block_ids)
        w_actuals_with_block_id = self.get_ground_truth_labels(exp_name, df_block_ids)
        df_w_preds_with_block_id = pd.DataFrame(w_preds_with_block_id)
        df_w_actuals_with_block_id = pd.DataFrame(w_actuals_with_block_id)
        df_w_preds = df_w_preds_with_block_id['value']
        df_w_actuals = df_w_actuals_with_block_id['value']        
        l.info("\nCalculate accuracy for experiment: {} using all llm WINDOWED predictions in " + stage_desc, exp_name)
        llm_stage_eval.LLMStageEval.eval_accuracy(exp_name + "_WINDOWED" + stage_desc, run, df_w_actuals, df_w_preds, None, None)
        #df_w_preds_with_block_id.to_excel('.\output\windowed_preds.xlsx', index=False)
        #df_w_actuals_with_block_id.to_excel('.\output\windowed_actuals.xlsx', index=False)
        
### end of code that duplicates

    def eval_post_llm_stage(self,exp_name, stage_suffix, nept_run, actual_binary, pred_binary, actual_multi, pred_multi, df_block_ids):
        l.info("\nCalculate accuracy for experiment: {} using test set predictions in stage 2", exp_name)
        post_llm_stage_eval.PostLLMStageEval.eval_accuracy(exp_name, stage_suffix, nept_run, actual_binary, pred_binary, actual_multi, pred_multi)
        self.eval_llm_stage_by_ids(exp_name, nept_run, df_block_ids, "test_set_stage1")

    def exec_train_and_save(self, nept_run):
        # call based on s2_model

        requested_model = self.params.model
        if requested_model == LOG_REG:
            log_reg = logreg_model.Model(db)
            X_binary_w_id, y_binary = log_reg.get_data(self.params.exp_name, CLASS_BINARY,\
                    self.params.llm_stage_exp_filter, self.params.game_session_filter)            
            X_train_binary_w_id,X_test_binary_w_id,y_train_binary, y_test_binary = log_reg.train_test_split(X_binary_w_id,y_binary,y_binary)
            # Now use the copy of data without the id in the modeling process
            X_train_binary = X_train_binary_w_id.drop(["block_id"], axis = 1)
            X_test_binary = X_test_binary_w_id.drop(["block_id"], axis = 1)
 
            # TODO: use factory patter! getting back a specific logreg instance - what's the point of exec_post_llm_stage if it is going to have model specific objects?
            model_instance_binary = log_reg.exec_train(self.params, self.params.exp_name, CLASS_BINARY,\
                                                              X_train_binary,y_train_binary)
            # feels weird not to score it
            # do scoring and log that 

            # Now for Multi
            #X_multi, y_multi = log_reg.get_data(self.params.exp_name, CLASS_MULTI,\
            #        self.params.llm_stage_exp_filter, self.params.game_session_filter)
            
            #X_train_multi,X_test_multi, y_train_multi, y_test_multi = log_reg.train_test_split(X_multi,y_multi)
            #model_instance_multi = log_reg.exec_train(self.params, self.params.exp_name, CLASS_MULTI,\
            #                                                 X_train_binary,y_train_binary)
            # evaluate
            y_hat_binary = log_reg.exec_predict(model_instance_binary, X_test_binary)
            #y_hat_multi =log_reg.exec_predict(model_instance_multi, X_test_multi)
            #self.eval_post_llm_stage(self.params.exp_name, '_train', nept_run,y_test_binary, y_hat_binary, y_test_multi, y_hat_multi)
            self.eval_post_llm_stage(self.params.exp_name, '_train', nept_run,y_test_binary, y_hat_binary, None,None, X_test_binary_w_id[["block_id"]])
            # return storage locations of saved trained models
            return 'save model not impleted yet', 'save model not impleted yet'

        if requested_model == XGB:
            xgb = xgboost_model.Model(db)
            # Binary first
            X_binary_w_id, y_binary = xgb.get_data(self.params.exp_name, CLASS_BINARY,\
                    self.params.llm_stage_exp_filter, self.params.game_session_filter)
            y_binary = y_binary.drop(["block_id"], axis = 1)
            X_train_binary_w_id,X_test_binary_w_id,y_train_binary, y_test_binary = xgb.train_test_split(X_binary_w_id,y_binary, y_binary)
            # Now use the copy of data without the id in the modeling process
            X_train_binary = X_train_binary_w_id.drop(["block_id"], axis = 1)
            X_test_binary = X_test_binary_w_id.drop(["block_id"], axis = 1)

            # TODO: use factory patter! getting back a specific logreg instance - what's the point of exec_post_llm_stage if it is going to have model specific objects?
            model_instance_binary = xgb.exec_train(self.params, self.params.exp_name, CLASS_BINARY,\
                                                              X_train_binary,y_train_binary)
            # feels weird not to score it
            # do scoring and log that 

            # Now for Multi
            #X_multi, y_multi = xgb.get_data(self.params.exp_name, CLASS_MULTI,\
            #        self.params.llm_stage_exp_filter, self.params.game_session_filter)
            
            #X_train_multi,X_test_multi, y_train_multi, y_test_multi = xgb.train_test_split(X_multi,y_multi)
            #model_instance_multi = xgb.exec_train(self.params, self.params.exp_name, CLASS_MULTI,\
            #                                                  X_train_binary,y_train_binary)
            # evaluate
            y_hat_binary = xgb.exec_predict(model_instance_binary, X_test_binary)
            #y_hat_multi =xgb.exec_predict(model_instance_multi, X_test_multi)

            # Note: I have a version of y that have ids so post_llm_stage can evaluate this stage but also with previous stage predictions            
            self.eval_post_llm_stage(self.params.exp_name, '_train', nept_run,y_test_binary, y_hat_binary, None, None, X_test_binary_w_id[["block_id"]])
            


            # return storage locations of saved trained models
            return 'save model not impleted yet', 'save model not impleted yet'

    def score(trained_model, X_train, X_test,y_train, y_test):
        #cv = StratifiedKFold(n_splits=5,random_state=11,shuffle=True) # Creating a StratifiedKFold object with 5 folds
        #cv_scores = cross_val_score(trained_model,X,y,scoring="accuracy",cv=cv) # Storing the CV scores (accuracy) of each fold
        pass


    def exec_tune(self, nept_run):

        requested_model = self.params.model
        if requested_model == LOG_REG:            
            # Binary first
            log_reg = logreg_model.Model(db)

            # Binary first ###########
            X_binary_w_id, y_binary = log_reg.get_data(self.params.exp_name, CLASS_BINARY,\
                    self.params.llm_stage_exp_filter, self.params.game_session_filter)
            
            X_train_binary_w_id,X_test_binary_w_id,y_train_binary, y_test_binary = log_reg.train_test_split(X_binary_w_id,y_binary, y_binary)
            # Now use the copy of data without the id in the modeling process
            X_train_binary = X_train_binary_w_id.drop(["block_id"], axis = 1)
            X_test_binary = X_test_binary_w_id.drop(["block_id"], axis = 1)

            # model specific so do the work at model layer
            tuned_params_binary = log_reg.exec_tune(self.params, CLASS_BINARY, X_train_binary, y_train_binary)            
            
            
            cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model_tuned_binary/parameters", tuned_params_binary)
            model_instance_binary = log_reg.exec_train(tuned_params_binary, tuned_params_binary.exp_name, CLASS_BINARY,\
                                                              X_train_binary,y_train_binary)
            # Multi next ###############
            #X_multi, y_multi = log_reg.get_data(self.params.exp_name, CLASS_MULTI,\
            #        self.params.llm_stage_exp_filter, self.params.game_session_filter)
            
            #X_train_multi,X_test_multi,y_train_multi, y_test_multi = log_reg.train_test_split(X_multi,y_multi)

            # model specific so do the work at model layer
            #tuned_params_multi = log_reg.exec_tune(self.params, CLASS_MULTI, X_train_multi, y_train_multi)            
                       
            #cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model_tuned_multi/parameters", tuned_params_multi)
            # final training using tuned parameters 
            #model_instance_multi = log_reg.exec_train(self.params, tuned_params_multi.exp_name, CLASS_MULTI,\
            #                                                  X_train_multi,y_train_multi)
          
            # evaluate
            y_hat_binary = log_reg.exec_predict(model_instance_binary, X_test_binary)
            #y_hat_multi =log_reg.exec_predict(model_instance_multi, X_test_multi)
            #self.eval_post_llm_stage(self.params.exp_name, '_tune', nept_run,y_test_binary, y_hat_binary, y_test_multi, y_hat_multi)            
            self.eval_post_llm_stage(self.params.exp_name, '_tune', nept_run,y_test_binary, y_hat_binary, None, None, X_test_binary_w_id[["block_id"]])

        if requested_model == XGB:            
            # Binary first
            xgb = xgboost_model.Model(db)

            # Binary first ###########
            X_binary_w_id, y_binary = xgb.get_data(self.params.exp_name, CLASS_BINARY,\
                    self.params.llm_stage_exp_filter, self.params.game_session_filter)
            
            X_train_binary_w_id,X_test_binary_w_id,y_train_binary, y_test_binary = xgb.train_test_split(X_binary_w_id,y_binary, y_binary)
            # Now use the copy of data without the id in the modeling process
            X_train_binary = X_train_binary_w_id.drop(["block_id"], axis = 1)
            X_test_binary = X_test_binary_w_id.drop(["block_id"], axis = 1)
            # model specific so do the work at model layer
            tuned_params_binary = xgb.exec_tune(self.params, CLASS_BINARY, X_train_binary, y_train_binary)            
                        
            cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model_tuned_binary/parameters", tuned_params_binary)
            model_instance_binary = xgb.exec_train(tuned_params_binary, tuned_params_binary.exp_name, CLASS_BINARY,\
                                                              X_train_binary,y_train_binary)
            # Multi next ###############
            #X_multi, y_multi = xgb.get_data(self.params.exp_name, CLASS_MULTI,\
            #        self.params.llm_stage_exp_filter, self.params.game_session_filter)
            
            #X_train_multi,X_test_multi,y_train_multi, y_test_multi = xgb.train_test_split(X_multi,y_multi)

            # model specific so do the work at model layer
            #tuned_params_multi = xgb.exec_tune(self.params, CLASS_MULTI, X_train_multi, y_train_multi)            
                       
            #cd_utils.CommDetectUtils.nept_send_params(nept_run, "s2_model_tuned_multi/parameters", tuned_params_multi)            
            
            # final training using tuned parameters 
            #model_instance_multi = xgb.exec_train(self.params, tuned_params_multi.exp_name, CLASS_MULTI,\
            #                                                  X_train_multi,y_train_multi)
          
            # evaluate
            y_hat_binary = xgb.exec_predict(model_instance_binary, X_test_binary)
            #y_hat_multi = xgb.exec_predict(model_instance_multi, X_test_multi)
            #self.eval_post_llm_stage(self.params.exp_name, '_tune', nept_run,y_test_binary, y_hat_binary, y_test_multi, y_hat_multi)
            self.eval_post_llm_stage(self.params.exp_name, '_tune', nept_run,y_test_binary, y_hat_binary, None, None, X_test_binary_w_id[["block_id"]])


    def exec_predict(self, nept_run):
        pass

    def exec_report(self, nept_run):
        pass    

# new design ends here


if __name__ == "__main__":    
    #post_llm_stage_params = post_LLMStageParams(exp_name = "1")       
    #stage2 = LLMStage(post_llm_stage_params, "3", "1")
    ##stage1.eval_llm_stage('30 seconds v1')
    ##stage1.exec()
    #stage2.get
    pass
