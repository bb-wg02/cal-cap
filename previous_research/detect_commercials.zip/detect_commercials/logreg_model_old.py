import dataset
import matplotlib.pyplot as plt
import numpy as np
from sklearn.calibration import LabelEncoder
from sklearn.pipeline import Pipeline
import sqlalchemy
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix
from sklearn.metrics import classification_report
import seaborn as sns
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import time
from sklearn.model_selection import learning_curve


EXP_15s = '15 second v5'
EXP_30s = '30 second v4  decide again'
#My_C = 1
My_C = 1
#My_C = 10000000


db = dataset.connect('sqlite:///db.db')

def get_X_data_for_stage_2_binary(exp_name):
    #t.ground_truth_label_c
    q = 'select p.response_classification_c, p.sports_broadcasting_streak, p.commercial_streak, '
    q = q + ' p.other_streak, p.sb_to_c_streak, p.c_to_c_streak, p.c_to_sb_streak,'
    q = q + ' p.sb_blocks_so_far, p.c_blocks_so_far, p.other_blocks_so_far,  p.num_blocks_since_sb,'
    q = q + '  p.num_blocks_since_c, t.sequence_num'
    q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
    q = q + ' and p.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name) 
    df_X = pd.DataFrame(rs)          
    return df_X

def get_y_data_for_stage_2_binary(exp_name):
    #t.ground_truth_label_c
    q = 'select t.ground_truth_label_c '
    q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
    q = q + ' and p.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)    
    df_y = pd.DataFrame(rs)
    return df_y

def get_X_data_for_stage_2_multi(exp_name):
    #t.ground_truth_label_c
    q = 'select p.response_classification_num, p.sports_broadcasting_streak, p.commercial_streak, '
    q = q + ' p.other_streak, p.sb_to_c_streak, p.c_to_c_streak, p.c_to_sb_streak,'
    q = q + ' p.sb_blocks_so_far, p.c_blocks_so_far, p.other_blocks_so_far,  p.num_blocks_since_sb,'
    q = q + '  p.num_blocks_since_c, t.sequence_num'
    q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
    q = q + ' and p.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name) 
    df_X = pd.DataFrame(rs)          
    return df_X

def get_y_data_for_stage_2_multi(exp_name):
    #t.ground_truth_label_c
    q = 'select t.ground_truth_label_num '
    q = q + ' from llm_predictions p, text_blocks t where  p.cur_block_id_used = t.block_id '
    q = q + ' and p.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)    
    df_y = pd.DataFrame(rs)
    return df_y


def train_and_score_binary(exp_name, X_train, y_train,X_test, y_test):  
    features_train = X_train[["response_classification_c","sports_broadcasting_streak",\
                          "commercial_streak","other_streak","sb_blocks_so_far",\
                            "c_blocks_so_far","num_blocks_since_c",\
                                 "sb_to_c_streak", "c_to_c_streak", "c_to_sb_streak",\
                                    "other_blocks_so_far", "num_blocks_since_sb", "sequence_num"]]
    y_train_slice = y_train["ground_truth_label_c"]

    # Initialize the scaler
    scaler = StandardScaler()
    print(f"Starting tran_and_score_binary for {exp_name}")
    # Fit the scaler and transform the features
    features_train_scaled = scaler.fit_transform(features_train)

    logisticRegr = LogisticRegression(solver='saga',max_iter = 800, verbose=0, C = My_C)

    print(f"fit with count: {len(y_train_slice)}")
    logisticRegr.fit(features_train_scaled, y_train_slice)

    features_test = X_test[["response_classification_c","sports_broadcasting_streak",\
                          "commercial_streak","other_streak","sb_blocks_so_far",\
                            "c_blocks_so_far","num_blocks_since_c",\
                                 "sb_to_c_streak", "c_to_c_streak", "c_to_sb_streak",\
                                    "other_blocks_so_far", "num_blocks_since_sb", "sequence_num"]]
    y_test_slice = y_test["ground_truth_label_c"]

    # Transform the features using scalar used to fit and tranfsorm train
    features_test_scaled = scaler.transform(features_test)

    print(f"predict with count: {len(features_test_scaled)}")
    y_hat_test = logisticRegr.predict(features_test_scaled)

    print(f"score with count: {len(features_test_scaled)}")
    score = logisticRegr.score(features_test_scaled, y_test_slice)
    conf_mat_bin(exp_name, y_test_slice, y_hat_test)
    bal_acc_score = balanced_accuracy_score( y_test_slice, y_hat_test)    
    print(f"balanced accuracy score binary for {exp_name} is : {bal_acc_score}")
    return score

def train_and_score_multi(exp_name, X_train, y_train,X_test, y_test):  
    features_train = X_train[["response_classification_num","sports_broadcasting_streak",\
                          "commercial_streak","other_streak","sb_blocks_so_far",\
                            "c_blocks_so_far","num_blocks_since_c",\
                                 "sb_to_c_streak", "c_to_c_streak", "c_to_sb_streak",\
                                    "other_blocks_so_far", "num_blocks_since_sb", "sequence_num"]]
    y_train_slice = y_train["ground_truth_label_num"]

    # Initialize the scaler
    scaler = StandardScaler()
    print(f"Starting tran_and_score_multi for {exp_name}")    
    # Fit the scaler and transform the features
    features_train_scaled = scaler.fit_transform(features_train)

    logisticRegr = LogisticRegression(solver='saga',max_iter = 800, verbose=0, multi_class = 'multinomial', C = My_C)

    print(f"fit with count: {len(features_train_scaled)}")
    logisticRegr.fit(features_train_scaled, y_train_slice)

    features_test = X_test[["response_classification_num","sports_broadcasting_streak",\
                          "commercial_streak","other_streak","sb_blocks_so_far",\
                            "c_blocks_so_far","num_blocks_since_c",\
                                 "sb_to_c_streak", "c_to_c_streak", "c_to_sb_streak",\
                                    "other_blocks_so_far", "num_blocks_since_sb", "sequence_num"]]
    y_test_slice = y_test["ground_truth_label_num"]

    # Transform the features using scalar used to fit and tranfsorm train
    features_test_scaled = scaler.transform(features_test)

    print(f"predict with count: {len(features_test_scaled)}")
    y_hat_test = logisticRegr.predict(features_test_scaled)

    print(f"score with count: {len(features_test_scaled)}")
    score = logisticRegr.score(features_test_scaled, y_test_slice)
    conf_mat_multi(exp_name, y_test_slice, y_hat_test)
    bal_acc_score = balanced_accuracy_score( y_test_slice, y_hat_test)
    print(f"balanced accuracy score multi for {exp_name} is : {bal_acc_score}")
    return score

def test_val_train_split(exp_name, X, y):
    # borrowed recommended approach on data science stack exchange to split twice to get validation set    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)
    
    # note - purposely making a smaller validation set
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=1) # 0.2 x 0.8 = 0.16
    
    return X_train, y_train, X_val, y_val, X_test, y_test


###############

def conf_mat_bin(exp_name, actual, predicted):    
    #predicted, actual = get_bin_data_stage1(exp_name)

    print(f"confusion matrix binary for {exp_name}")
    cm = confusion_matrix(actual, predicted)
    cm_df = pd.DataFrame(cm, index = ['YES','NO'],columns = ['YES','NO'])

    #Plotting the confusion matrix
    plt.figure(figsize=(10,8))
    sns.heatmap(cm_df, annot=True,  fmt=f'.{0}f')
    sns.heatmap(cm_df,
        vmin=cm_df.values.min(),
        vmax=cm_df.values.max(),
        square=True,
        cmap="YlGnBu",
        linewidths=0.1,
       annot=True,
       fmt=f'.{0}f',
       annot_kws={"size": 35 / np.sqrt(len(cm_df))})

    plt.title('Confusion Matrix for Commercial Detection (Yes/No)')
    plt.ylabel('Actual Values')
    plt.xlabel('Predicted Values')    

    fig_file = f"./output/conf_mat_bin_{exp_name}.png"
    plt.savefig(fig_file)
    #plt.show()
    #plt.clf()
    print(f"Classification report binary for {exp_name}")
    cl_rpt = classification_report(actual, predicted, target_names=cm_df)
    print(cl_rpt)
    bal_acc_score = balanced_accuracy_score( actual, predicted)
    print(f"Accuracy binary for {exp_name}")
    print(f"balanced accuracy score: {bal_acc_score}")

def conf_mat_multi(exp_name, actual, predicted):    
    #predicted, actual = get_multi_data_stage1(exp_name)

    print(f"confusion matrix multi for {exp_name}")

    cm = confusion_matrix(actual, predicted)
    cm_df = pd.DataFrame(cm,
                     index = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB' ],  # removed 'O' for unknown error
                     columns = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB']) # removed 'O' for unknown error
    
    #Plotting the confusion matrix
    plt.figure(figsize=(10,8))
    sns.heatmap(cm_df, annot=True,  fmt=f'.{0}f')
    sns.heatmap(cm_df,
        vmin=cm_df.values.min(),
        vmax=cm_df.values.max(),
        square=True,
        cmap="YlGnBu",
        linewidths=0.1,
        annot=True,
        fmt=f'.{0}f',
        annot_kws={"size": 35 / np.sqrt(len(cm_df))})

    plt.title('Confusion Matrix for Commercial Transitions')
    plt.ylabel('Actual Values')
    plt.xlabel('Predicted Values')    

    fig_file = f"./output/conf_mat_multi_{exp_name}.png"
    plt.savefig(fig_file)
    #plt.show()
    plt.clf()
    print(f"Classification report multi for {exp_name}")
    cl_rpt = classification_report(actual, predicted, target_names=cm_df)
    print(cl_rpt)
    bal_acc_score = balanced_accuracy_score( actual, predicted)
    print(f"Accuracy for multi for {exp_name}")
    print(f"balanced accuracy score: {bal_acc_score}")


def stage1_conf_mat_multi(exp_name, actual, predicted):    
    #predicted, actual = get_multi_data_stage1(exp_name)

    print(f"confusion matrix multi for {exp_name}")

    cm = confusion_matrix(actual, predicted)
    cm_df = pd.DataFrame(cm,
                     index = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB' ],  
                     columns = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB']) 
    
    #Plotting the confusion matrix
    plt.figure(figsize=(10,8))
    sns.heatmap(cm_df, annot=True,  fmt=f'.{0}f')
    sns.heatmap(cm_df,
        vmin=cm_df.values.min(),
        vmax=cm_df.values.max(),
        square=True,
        cmap="YlGnBu",
        linewidths=0.1,
        annot=True,
        fmt=f'.{0}f',
        annot_kws={"size": 35 / np.sqrt(len(cm_df))})

    plt.title('Confusion Matrix for Commercial Transitions')
    plt.ylabel('Actual Values')
    plt.xlabel('Predicted Values')    

    fig_file = f"./output/conf_mat_multi_{exp_name}.png"
    plt.savefig(fig_file)
    #plt.show()
    plt.clf()
    print(f"Classification report multi for {exp_name}")
    cl_rpt = classification_report(actual, predicted, target_names=cm_df)
    print(cl_rpt)
    print(f"Accuracy for multi for {exp_name}")
    bal_acc_score = balanced_accuracy_score( actual, predicted)
    print(f"balanced accuracy score: {bal_acc_score}")

# hack just to get confusion matrix consistent across stage 1 and stage 2
# distribute the 'Other' columns evenly with other values because LLM didn't know where to put it
def handle_other(stage1_pred):
    stage1_pred_cleaned = stage1_pred.copy(deep=True)
    rr_value = 0
    #print("in handle_other**************************")    
    #stage1_pred_cleaned.update(pd.Series(-1, index=[i]))
    #print(f"stage1_pred_cleaned: {stage1_pred.head()}")
    for i, v in stage1_pred.items():
        if v == 5:
            #print(f"Before clean: {stage1_pred_cleaned[i]}")
            stage1_pred_cleaned[i] = rr_value
            # confirm I set the rows value
            #print(f"After clean: {stage1_pred_cleaned[i]}")
            if rr_value < 4:
                rr_value += 1
            else:
                rr_value = 0
    return stage1_pred_cleaned


#The function below builds the model and returns cross validation scores, train score and learning curve data
# Code adapted from KSV Muhalidar https://towardsdatascience.com/learning-curve-to-identify-overfitting-underfitting-problems-133177f38df5
def learn_curve(X,y,c):
## param X: Matrix of input features
##        param y: Vector of Target/Label
##        c: Inverse Regularization variable to control overfitting (high value causes overfitting, low value causes underfitting)
 
#We aren't splitting the data into train and test because we will use StratifiedKFoldCV.
##       KFold CV is a preferred method compared to hold out CV, since the model is tested on all the examples.
##       Hold out CV is preferred when the model takes too long to train and we have a huge test set that truly represents the universe
##
    
    le = LabelEncoder() # Label encoding the target
    sc = StandardScaler() # Scaling the input features
    y = le.fit_transform(y)#Label Encoding the target
    log_reg = LogisticRegression(max_iter=200,random_state=11,C=c) # LogisticRegression model
# Pipeline with scaling and classification as steps, must use a pipelne since we are using KFoldCV
    lr = Pipeline(steps=(['scaler',sc],    ['classifier',log_reg]))
    
    
    cv = StratifiedKFold(n_splits=5,random_state=11,shuffle=True) # Creating a StratifiedKFold object with 5 folds
    cv_scores = cross_val_score(lr,X,y,scoring="accuracy",cv=cv) # Storing the CV scores (accuracy) of each fold
    
    
    lr.fit(X,y) # Fitting the model

    train_score = lr.score(X,y) # Scoring the model on train set
    
    #Building the learning curve
    train_size,train_scores,test_scores = learning_curve(estimator=lr,X=X,y=y,cv=cv,scoring="accuracy",random_state=11)
    train_scores = 1-np.mean(train_scores,axis=1)#converting the accuracy score to misclassification rate
    test_scores = 1-np.mean(test_scores,axis=1)#converting the accuracy score to misclassification rate
    lc = pd.DataFrame({"Training_size":train_size,"Training_loss":train_scores,"Validation_loss":test_scores}).melt(id_vars="Training_size")
    
    return {"cv_scores":cv_scores,
           "train_score":train_score,
           "learning_curve":lc}


def do_lc(X,y,C):
    lc = learn_curve(X,y,1)
    print(f'Cross Validation Accuracies:\n{"-"*25}\n{list(lc["cv_scores"])}\n\n\
    Mean Cross Validation Accuracy:\n{"-"*25}\n{np.mean(lc["cv_scores"])}\n\n\
    Standard Deviation of Cross Validation Accuracy:\n{"-"*25}\n{np.std(lc["cv_scores"])}\n\n\
    Training Accuracy:\n{"-"*15}\n{lc["train_score"]}\n\n')
    sns.lineplot(data=lc["learning_curve"],x="Training_size",y="value",hue="variable")
    plt.title("2nd Stage Logistic Regression Model C=1, Stratified KFold Validation")
    plt.ylabel("Misclassification Rate ( 1- mean(accuracy) )")
    fig_file = f"./output/lc_{C}.png"
    plt.savefig(fig_file)

print("*************************************************************************************")            
print("*************************************************************************************")    
print(f"Starting program at {time.localtime}")
print("*************************************************************************************")
print("*************************************************************************************")
###############
# load binary 15s data (Commercial or not question)
X_15s_bin = get_X_data_for_stage_2_binary(EXP_15s)
y_15s_bin = get_y_data_for_stage_2_binary(EXP_15s)

# load binary 30s data (Commercial or not question)
X_30s_bin = get_X_data_for_stage_2_binary(EXP_30s)
y_30s_bin = get_y_data_for_stage_2_binary(EXP_30s)

# load multi 15s data (5 states to predict)
X_15s_multi = get_X_data_for_stage_2_multi(EXP_15s)
y_15s_multi = get_y_data_for_stage_2_multi(EXP_15s)

# load multi 30s data (5 states to predict)
X_30s_multi = get_X_data_for_stage_2_multi(EXP_30s)
y_30s_multi = get_y_data_for_stage_2_multi(EXP_30s)



# we have two different experiments that should be trained, tested and evaluated separately 30-second clips and 15-second clips
# do one  split for each experiment for each outcome type (binary or multi)

#15s for binary outcome
X_train_15s_bin, y_train_15s_bin, X_val_15s_bin, y_val_15s_bin, X_test_15s_bin, y_test_15s_bin = test_val_train_split(EXP_15s, X_15s_bin,y_15s_bin)
#30s for binary outcome
X_train_30s_bin, y_train_30s_bin, X_val_30s_bin, y_val_30s_bin, X_test_30s_bin, y_test_30s_bin = test_val_train_split(EXP_30s, X_30s_bin,y_30s_bin)

#15s for multi outcome
X_train_15s_multi, y_train_15s_multi, X_val_15s_multi, y_val_15s_multi, X_test_15s_multi, y_test_15s_multi = test_val_train_split(EXP_15s, X_15s_multi,y_15s_multi)
#30s for multi outcome
X_train_30s_multi, y_train_30s_multi, X_val_30s_multi, y_val_30s_multi, X_test_30s_multi, y_test_30s_multi = test_val_train_split(EXP_30s, X_30s_multi,y_30s_multi)

## OK Have the splits
## Now test various splits

#train_commerical_detect_score_15s = train_and_score_binary(EXP_15s,X_train_15s_bin, y_train_15s_bin,X_train_15s_bin, y_train_15s_bin)
#commerical_detect_score_15s = train_and_score_binary(EXP_15s,X_train_15s_bin, y_train_15s_bin,X_val_15s_bin, y_val_15s_bin)
# Run this one only at the end of our process
commerical_detect_score_15s = train_and_score_binary(EXP_15s, X_train_15s_bin, y_train_15s_bin,X_test_15s_bin, y_test_15s_bin)

#print(f"'TRAIN 15 second v5' binary score: {train_commerical_detect_score_15s}")
#print(f"'15 second v5' binary score: {commerical_detect_score_15s}")

#do_lc(X_15s_bin,y_15s_bin,1)

## temp remove --- train_commerical_detect_score_30s = train_and_score_binary(EXP_30s,X_train_30s_bin, y_train_30s_bin,X_train_30s_bin, y_train_30s_bin)
#commerical_detect_score_30s = train_and_score_binary(EXP_30s,X_train_30s_bin, y_train_30s_bin,X_val_30s_bin, y_val_30s_bin)
# Run this one only at the end of our process
## temp remove --- commerical_detect_score_30s = train_and_score_binary(EXP_30s,X_train_30s_bin, y_train_30s_bin,X_test_30s_bin, y_test_30s_bin)
## temp remove --- print(f"'30 second v4  decide again' binary score: {commerical_detect_score_30s}")
## temp remove --- print(f"'TRAIN 30 second v4  decide again' binary score: {train_commerical_detect_score_30s}")

train_transition_detect_score_15s = train_and_score_multi(EXP_15s,X_train_15s_multi, y_train_15s_multi,X_train_15s_multi, y_train_15s_multi)
#transition_detect_score_15s = train_and_score_multi(EXP_15s,X_train_15s_multi, y_train_15s_multi,X_val_15s_multi, y_val_15s_multi)
#Run this one only at the end of our process
transition_detect_score_15s = train_and_score_multi(EXP_15s, X_train_15s_multi, y_train_15s_multi,X_test_15s_multi, y_test_15s_multi)
## temp remove --- print(f"'15 second v5' multi score: {transition_detect_score_15s}")
## temp remove --- print(f"'TRAIN 15 second v5' multi score: {train_transition_detect_score_15s}")

## temp remove --- train_transition_detect_score_30s = train_and_score_multi(EXP_30s,X_train_30s_multi, y_train_30s_multi,X_train_30s_multi, y_train_30s_multi)
#transition_detect_score_30s = train_and_score_multi(EXP_30s,X_train_30s_multi, y_train_30s_multi,X_val_30s_multi, y_val_30s_multi)
# Run this one only at the end of our process
## temp remove --- transition_detect_score_30s = train_and_score_multi(EXP_30s,X_train_30s_multi, y_train_30s_multi,X_test_30s_multi, y_test_30s_multi)
## temp remove --- print(f"'30 second v4  decide again' multi score: {transition_detect_score_30s}")
## temp remove --- print(f"'TRAIN 30 second v4  decide again' multi score: {train_transition_detect_score_30s}")

# CM for stage 1 15S Multi
# slice out the stage 1 prediction

stage1_prediction = X_test_15s_bin['response_classification_c']
#stage1_prediction_cleaned = handle_other(stage1_prediction)
stage1_EXP_15s = "Stage 1 " +  EXP_15s
print("Stage 1 data")
stage1_y_test_slice = y_test_15s_bin["ground_truth_label_c"]
conf_mat_bin(stage1_EXP_15s, stage1_y_test_slice, stage1_prediction)
bal_acc_score = balanced_accuracy_score( stage1_y_test_slice, stage1_prediction)
print(f"Stage 1 balanced accuracy score: {bal_acc_score}")

