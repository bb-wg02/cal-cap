import json
import requests
from loguru import logger
import dataset
import arrow
from time import sleep
import copy

import sqlalchemy

db = dataset.connect('sqlite:///db.db')
llm_predictions = db['llm_predictions']
instruction_prompts = db['instruction_prompts']
blocks = db['text_blocks_table']

# CONFIG VALUES AS CONSTANTS FOR NOW. MOVE TO CMD LINE LATER.
NUM_PREV_BLOCKS = 2 # currently support 0, 1 or 2 to be sent to LLM with current block as one request
INSTR_OVERRIDE = ""
LLM_EXP_NAME = "45 second v6"
DO_UPDATE_LLM_STATS = "Y"
DO_LLM_PREDICT = "Y"
RESTART_HACK_ON = ""
RESTART_HACK_TID = -1

class ChatGPT(object):
    def __init__(self, input_instructions, input_block, llm_exp_name):
        
        self.is_valid = None
        self.classification_code = None
        self.response = None
        self.response_json = None
        self.instructions = input_instructions
        self.block = input_block
        self.bearer_key = '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'
        self.endpoint = "https://api.openai.com/v1/chat/completions"
        # self.model = 'gpt-4-1106-preview'
        self.model = 'gpt-3.5-turbo'
        self.temp = 0.3
        self.start_requests = arrow.now().to('US/Central').datetime
        self.get_gpt_response()
        self.stop_requests = arrow.now().to('US/Central').datetime
        self.llm_exec_time = (self.stop_requests - self.start_requests).microseconds
        self.fully_formed_requests = '"' + self.instructions['instr_text'] + '\n\n' + self.block['cur_chunk'] + '"'
        self.category = self.response_json['choices'][0]['message']['content']
        self.llm_exp_name = llm_exp_name
        self.eval_response()

    def get_class_num(self, class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 2
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 3
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 4
        elif class_code == 'OTHER':
            return 5
        
    def get_class_c(self, class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 1
        elif class_code == 'OTHER':
            return 0

    def eval_response(self):
        response_map = dict()
        response_map['Commercial'] = 'COMMERCIAL'
        response_map['Sports Broadcast'] = 'SPORTS_BROADCASTING'
        # gave an extra space at end a few times
        response_map['Sports Broadcast '] = 'SPORTS_BROADCASTING'
        
        response_map['Sports Broadcast Followed By A Commercial'] = 'SPORTS_BROADCASTING-TO-COMMERCIAL'
        response_map['Commercial Then A Second Commercial'] = 'COMMERCIAL-TO-ANOTHER COMMERCIAL'
        response_map['Commercial Followed By A Sports Broadcast'] = 'COMMERCIAL-TO-SPORTS_BROADCASTING'
        #response_map['Not a Commercial and not a Sports Broadcast'] = 'OTHER'
        response_map['Something Else'] = 'OTHER'

        try:
            self.is_valid = True
            self.classification_code = response_map[self.category.replace('"', '').replace("'", '')]     
            # weird formatting cases                   
        except KeyError:
            fix_found = False
            if self.category == "'Sports Broadcast'":
                self.classification_code = 'SPORTS_BROADCASTING'
                fix_found = True
            if self.category == "'Something Else'":
                self.classification_code = 'OTHER' 
                fix_found = True  
            if not fix_found:
                global llm_invalid_responses
                llm_invalid_responses += 1
                if llm_invalid_responses > LLM_INVALID_RESPONSE_LIMIT:
                    raise Exception('Too many invalid responses')
                self.is_valid = False

    @property
    def db_output(self):
        output = dict()
        output['instr_prompt_used_name'] = self.instructions['instr_name']
        output['instr_prompt_used_text'] = self.instructions['instr_text']
        output['cur_block_id_used'] = self.block['block_id']
        output['text_chunk_used'] = self.block['cur_chunk']
        output['llm_name'] = self.model
        output['llm_other_params'] = self.temp
        output['fully_formed_request'] = self.fully_formed_requests
        output['requested_at'] = self.start_requests
        output['response_is_valid'] = self.is_valid
        output['response_text'] = self.category
        output['response_classification'] = self.classification_code
        output['response_at'] = self.stop_requests
        output['llm_exec_time'] = self.llm_exec_time
        output['input_tokens'] = self.response_json['usage']['prompt_tokens']
        output['output_tokens'] = self.response_json['usage']['completion_tokens']
        output['code'] = self.response_json['choices'][0]['finish_reason']
        output['llm_exp_name'] = self.llm_exp_name
        output['response_classification_num'] = self.get_class_num(self.classification_code)
        output['response_classification_c'] = self.get_class_c(self.classification_code)

        print(output['text_chunk_used'])
        print(output['response_classification'])
        if output['code'] != 'stop':
            global llm_api_failures
            llm_api_failures += 1
            sleep(min(60,12*llm_api_failures))
            if llm_api_failures > LLM_API_FAIL_LIMIT:
                raise Exception('Too many api failures')
        return output

    def get_gpt_response(self):
        headers = {
            "Authorization": f"Bearer {self.bearer_key}",
            "Content-Type": "application/json",
            "User-Agent": "OpenAI Python Client",
        }

        data = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": self.instructions['instr_text']},
                {"role": "user", "content": self.block['cur_chunk']},
            ],
            "temperature": self.temp
        }

        response = requests.post(self.endpoint, headers=headers, data=json.dumps(data))
        if response.status_code != 200:
            raise ValueError(f"API call failed with status code {response.status_code}: {response.text}")
        else:
            self.response = response
            try:
                self.response_json = response.json()
            except Exception as ERR:
                logger.error(ERR)


def delete_llm_prediction(llm_predict_id=None, cur_block_id_used=None, delete_all=False):
    if llm_predict_id:
        llm_predictions.delete(llm_predict_id=llm_predict_id)
    elif cur_block_id_used:
        llm_predictions.delete(cur_block_id_used=cur_block_id_used)
    elif delete_all:
        llm_predictions.delete()
    else:
        logger.warning('Invalid LLM Deletion Input')


def t_llm_predict_iter():
    return llm_predictions.find()

def merge_prev_chunks(text_block, prev_text_block, prior_prev_text_block, num_blocks):    
    merged_text_block = copy.deepcopy(text_block)
    # if previous blocks are None, not an error. Just don't add.
    if num_blocks == 0:
        # already set
        pass
    elif num_blocks == 1:
        if prev_text_block is not None:
            merged_text_block['cur_chunk'] = prev_text_block['cur_chunk'] + merged_text_block['cur_chunk']  
    elif num_blocks == 2:
        if (prev_text_block is not None) and (prior_prev_text_block is not None): 
            merged_text_block['cur_chunk'] = prior_prev_text_block['cur_chunk'] + prev_text_block['cur_chunk']  + merged_text_block['cur_chunk']  
    else:
        # Raise exception
        raise ValueError(f"Chosen NUM_PREV_BLOCKS {num_blocks} is not supported")
    
    return merged_text_block

def re_init_stats():
    llm_stats = {'sports_broadcasting_streak':0,
                'commercial_streak':0,
                'sb_to_c_streak':0,
                'c_to_c_streak':0,
                'c_to_sb_streak':0,
                'other_streak':0,
                'c_blocks_so_far':0,
                'sb_blocks_so_far':0,
                'other_blocks_so_far':0,
                'num_blocks_since_sb':0,
                'num_blocks_since_c':0,
                'llm_predict_id':-1}
                

    return llm_stats

def update_sb(llm_stats):
    llm_stats['sports_broadcasting_streak'] += 1
    llm_stats['num_blocks_since_sb'] = 0
    
    llm_stats['commercial_streak'] = 0
    llm_stats['sb_to_c_streak'] = 0
    llm_stats['c_to_c_streak'] = 0
    llm_stats['c_to_sb_streak'] = 0
    llm_stats['other_streak'] = 0
    
    llm_stats['num_blocks_since_c'] +=1
    
    llm_stats['sb_blocks_so_far'] +=1
    
    llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far']
    llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']
             
def update_sb_to_c(llm_stats):
    llm_stats['sports_broadcasting_streak'] = 0
    llm_stats['num_blocks_since_sb'] += 1
    
    llm_stats['commercial_streak'] = 0
    llm_stats['sb_to_c_streak'] += 1
    llm_stats['c_to_c_streak'] = 0
    llm_stats['c_to_sb_streak'] = 0
    llm_stats['other_streak'] = 0
    
    llm_stats['num_blocks_since_c'] +=1
    
    llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']
    
    llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far']
    llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']
          

def update_c(llm_stats):
    llm_stats['sports_broadcasting_streak'] = 0
    llm_stats['num_blocks_since_sb'] += 1
    
    llm_stats['commercial_streak'] += 1
    llm_stats['sb_to_c_streak'] = 0
    llm_stats['c_to_c_streak'] = 0
    llm_stats['c_to_sb_streak'] = 0
    llm_stats['other_streak'] = 0
    
    llm_stats['num_blocks_since_c'] = 0
    
    llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']
    
    llm_stats['c_blocks_so_far'] += 1 
    llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']


def update_c_to_c(llm_stats):
    llm_stats['sports_broadcasting_streak'] = 0
    llm_stats['num_blocks_since_sb'] += 1
    
    llm_stats['commercial_streak'] = llm_stats['commercial_streak'] 
    llm_stats['sb_to_c_streak'] = 0
    llm_stats['c_to_c_streak'] += 1
    llm_stats['c_to_sb_streak'] = 0
    llm_stats['other_streak'] = 0
    
    llm_stats['num_blocks_since_c'] = llm_stats['num_blocks_since_c'] 
    
    llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']
    
    llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far'] 
    llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']


def update_c_to_sb(llm_stats):
    llm_stats['sports_broadcasting_streak'] = 0
    llm_stats['num_blocks_since_sb'] = llm_stats['num_blocks_since_sb'] 
    
    llm_stats['commercial_streak'] = llm_stats['commercial_streak'] 
    llm_stats['sb_to_c_streak'] = 0
    llm_stats['c_to_c_streak'] = 0
    llm_stats['c_to_sb_streak'] += 1
    llm_stats['other_streak'] = 0
    
    llm_stats['num_blocks_since_c'] = llm_stats['num_blocks_since_c'] 
    
    llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']
    
    llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far'] 
    llm_stats['other_blocks_so_far'] = llm_stats['other_blocks_so_far']

def update_o(llm_stats):
    llm_stats['sports_broadcasting_streak'] = 0
    llm_stats['num_blocks_since_sb'] += 1
    
    llm_stats['commercial_streak'] = 0
    llm_stats['sb_to_c_streak'] = 0
    llm_stats['c_to_c_streak'] = 0
    llm_stats['c_to_sb_streak'] = 0
    llm_stats['other_streak'] += 1
    
    llm_stats['num_blocks_since_c'] += 1
    
    llm_stats['sb_blocks_so_far'] = llm_stats['sb_blocks_so_far']
    
    llm_stats['c_blocks_so_far'] = llm_stats['c_blocks_so_far'] 
    llm_stats['other_blocks_so_far'] += 1

def save_stats_to_db(llm_stats, llm_predict_id):
    llm_stats['llm_predict_id'] = llm_predict_id 
    uq = 'update llm_predictions set '
    uq = uq + ' sports_broadcasting_streak = :sports_broadcasting_streak, '
    uq = uq + ' num_blocks_since_sb = :num_blocks_since_sb, '    
    uq = uq + ' commercial_streak = :commercial_streak, '
    uq = uq + ' sb_to_c_streak = :sb_to_c_streak, '
    uq = uq + ' c_to_c_streak = :c_to_c_streak, ' 
    uq = uq + ' c_to_sb_streak = :c_to_sb_streak, ' 
    uq = uq + ' other_streak = :other_streak, '   
    uq = uq + ' num_blocks_since_c = :num_blocks_since_c, '   
    uq = uq + ' sb_blocks_so_far = :sb_blocks_so_far, '    
    uq = uq + ' c_blocks_so_far = :c_blocks_so_far, '
    uq = uq + ' other_blocks_so_far = :other_blocks_so_far '    
    uq = uq + ' where llm_predict_id =:llm_predict_id '
    rs = db.engine.execute(sqlalchemy.text(uq), llm_stats)
    llm_stats['llm_predict_id'] = -1 

def update_llm_stats(exp_name):
    q = 'SELECT t.session_id, t.block_id, t.sequence_num, l.response_classification, l.llm_predict_id, l.llm_exp_name'
    q = q + ' FROM text_blocks_table t, llm_predictions l'
    q = q + ' WHERE t.block_id = l.cur_block_id_used and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
    
    prev_session_id = -1
    for row in rs:
        if row['session_id'] != prev_session_id:
            print('New session')
            llm_stats = re_init_stats()            
            prev_session_id = row['session_id']           
            if row['sequence_num'] != 1:
                raise('Invalid order for llm prediction in update_llm_stats')
        else:
            if row['sequence_num'] != prev_sequence_num + 1:
                raise('Invalid order for llm prediction in update_llm_stats')
            
        if row['response_classification'] == 'SPORTS_BROADCASTING':
            update_sb(llm_stats)
        
        if row['response_classification'] == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            update_sb_to_c(llm_stats)

        if row['response_classification'] == 'COMMERCIAL':
            update_c(llm_stats)

        if row['response_classification'] == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            update_c_to_c(llm_stats)

        if row['response_classification'] == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            update_c_to_sb(llm_stats)

        if row['response_classification'] == 'OTHER':
            update_o(llm_stats)
        
        save_stats_to_db(llm_stats, row['llm_predict_id'] )

        prev_session_id = row['session_id']
        prev_sequence_num = row['sequence_num']

        #print(llm_stats)
    return

if __name__ == "__main__":
    strict_mode = False

    if strict_mode:
        LLM_API_FAIL_LIMIT = 5
        LLM_INVALID_RESPONSE_LIMIT = 10
    else:
        LLM_API_FAIL_LIMIT = 10
        LLM_INVALID_RESPONSE_LIMIT = 100

    llm_api_failures = 0
    llm_invalid_responses = 0

    if (DO_LLM_PREDICT == 'Y') and (LLM_EXP_NAME != ""):
        if INSTR_OVERRIDE == "":
            instructions = instruction_prompts.find_one(default_ind=True)
            if instructions is None:
                raise ValueError("No instructions found in database. Database Missing?")

            # set defaults - not first 1 or 2 bocks will not have additional data to send
            prior_prev_text_block = None
            prev_text_block = None

            for text_block in blocks.find():  
                ok_to_process = RESTART_HACK_ON != "Y"
                if not ok_to_process:
                    ok_to_process = text_block['block_id'] > RESTART_HACK_TID
                if ok_to_process:         
                    # Uncomment to add a pause to avoid throttling
                    sleep(1)
                    merged_text_block = merge_prev_chunks(text_block, prev_text_block, prior_prev_text_block, NUM_PREV_BLOCKS)
                    prior_prev_text_block = copy.deepcopy(prev_text_block)
                    prev_text_block = copy.deepcopy(text_block)
                    ai_data = ChatGPT(instructions, merged_text_block, LLM_EXP_NAME)
                    llm_predictions.insert(ai_data.db_output)
                else:
                    print(f"Skipping block: {text_block['block_id']}" )
        else:
            # set defaults - not first 1 or 2 bocks will not have additional data to send
            prior_prev_text_block = None
            prev_text_block = None

            for text_block in blocks.find():            
                # Uncomment to add a pause to avoid throttling
                sleep(0.75)
                merged_text_block = merge_prev_chunks(text_block, prev_text_block, prior_prev_text_block, NUM_PREV_BLOCKS)
                prior_prev_text_block = copy.deepcopy(prev_text_block)
                prev_text_block = copy.deepcopy(text_block)
                ai_data = ChatGPT(INSTR_OVERRIDE, merged_text_block, LLM_EXP_NAME)
                llm_predictions.insert(ai_data.db_output)

            
    
    if (DO_UPDATE_LLM_STATS == 'Y') and (LLM_EXP_NAME != ""):        
        update_llm_stats(LLM_EXP_NAME)
