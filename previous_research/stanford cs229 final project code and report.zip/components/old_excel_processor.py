import pandas as pd
import os

from models import TextBlocksEntity, TransitionsEntity, SourceEntity
from components.log_writers import LogWriters
from components.session_data import SessionData


class ExcelProcessor:
    def __init__(self, db_session, excel_filename, current_session_id):
        self.db_session = db_session
        self.excel_filename = excel_filename
        self.current_session_id = current_session_id

    def get_latest_id(self):
        # Get latest data or the last row from the database
        last_row = self.db_session.query(TransitionsEntity).order_by(
            TransitionsEntity.transition_id.desc()).first()
        if last_row != None:
            return last_row.transition_id + 1
        else:
            return 0

    def query_source_id(self, source_file_path, source_file_name):
        # Queries the source id of a file
        q_source_id = self.db_session.query(SourceEntity).filter(
            SourceEntity.file_path == source_file_path, SourceEntity.file_name == source_file_name).all()

        if len(q_source_id) > 1:
            # Check for duplicate source
            message = f"The file {source_file_path}{source_file_name} has duplicate source in the source table"
            LogWriters.log_general_session(
                message, self.current_session_id, 'w')
            LogWriters.log_general_warning(message)
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, 'w')
            print(f"[WARNING] {message}")

        elif len(q_source_id) == 0:
            # Source text file not found, this is an error
            message = f"Source text file {source_file_path}{source_file_name} was not found in the source table"
            LogWriters.log_general_session(
                message, self.current_session_id, 'e')
            LogWriters.log_general_error(message)
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, 'e')
            raise Exception(message)

        return q_source_id[0].source_id

    def load_transitions_table(self):
        # Save row data from excel file to database
        first_message_log = f"Loading transition data from excel file {self.excel_filename} to database"
        LogWriters.log_general_session(
            first_message_log, self.current_session_id, "i")

        df = pd.read_excel(f"input_excel_files/{self.excel_filename}")
        excel_filepath = f"{os.getcwd()}\\input_excel_files\\"

        for i in range(len(df)):
            row_values = df.iloc[i].to_list()
            transitions_entity = TransitionsEntity(
                transition_id=self.get_latest_id(),
                transition_code=row_values[0],
                timestamp=row_values[1],
                transition_excel_filename=self.excel_filename,
                transition_excel_filepath=excel_filepath,
                source_filename=row_values[2],
                source_file_path=row_values[3],
                last_modify_dt=row_values[4],
                source_id=self.query_source_id(row_values[3], row_values[2]))
            self.db_session.add(transitions_entity)
        self.db_session.commit()

        last_message_log = f"Finished loading {len(df)} transition data from excel file {self.excel_filename} to database"
        LogWriters.log_general_session(
            last_message_log, self.current_session_id, "i")

    def get_state_after_transition(self, transition_code):
        if transition_code == "SPORTS_BROADCASTING-TO-COMMERCIAL":
            return "COMMERCIAL"
        elif transition_code == "COMMERCIAL-TO-SPORTS_BROADCASTING":
            return "SPORTS_BROADCASTING"
        elif transition_code == "COMMERCIAL-TO-ANOTHER COMMERCIAL":
            return "COMMERCIAL"

    def get_state_before_transition(self, transition_code):
        if transition_code == "SPORTS_BROADCASTING-TO-COMMERCIAL":
            return "SPORTS_BROADCASTING"
        elif transition_code == "COMMERCIAL-TO-SPORTS_BROADCASTING" or transition_code == "COMMERCIAL-TO-ANOTHER COMMERCIAL":
            return "COMMERCIAL"

    def save_ground_truth_label(self, text_block_id, new_ground_truth_label):
        # Saves the currently set ground truth label for a block in the database
        self.db_session.query(TextBlocksEntity).filter(
            TextBlocksEntity.block_id == text_block_id
        ).update({TextBlocksEntity.ground_truth_label: new_ground_truth_label})
        self.db_session.commit()

    def there_text_block(self, q_text_block, target_session_id):
        if len(q_text_block) == 0:
            message = f"No text block with session id {target_session_id} was found"
            LogWriters.log_general_session(
                message, self.current_session_id, 'i')
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, 's')
            print(f"[INFO] {message}")
            return False
        return True

    def there_transition_data(self, q_transition_data, source_id):
        if len(q_transition_data) == 0:
            message = f"No transition data with source id {source_id} was found"
            LogWriters.log_general_session(
                message, self.current_session_id, 'i')
            SessionData.modify_session_data(
                self.db_session, self.current_session_id, 's')
            print(f"[INFO] {message}")
            return False
        return True

    def find_next_trans(self, t_index, t_data, cur_chunk_start, cur_chunk_end):
        cur_state = None
        next_t_index = t_index
        # make sure not past end of list
        keep_looking = next_t_index < len(t_data)
        if keep_looking:
            # get current transition data
            cur_t = t_data[next_t_index]
            # make sure text block overlaps with transition record
            keep_looking = cur_chunk_start <= cur_t.timestamp and  cur_chunk_end >= cur_t.timestamp 
        
        if keep_looking:
            # set the state to be used based on current transition code
            cur_state = self.get_state_after_transition(
                cur_t.transition_code)        
        
        # before returning loop to check if this text block overlaps with any other transition records
        while keep_looking:            
            next_t_index += 1
            # have reached end of transition list?
            keep_looking = next_t_index < len(t_data)
            # next get transition data 
            if keep_looking:
                cur_t = t_data[next_t_index]                        
                # is this transition overlapping with the same block
                keep_looking = cur_chunk_start <= cur_t.timestamp and  cur_chunk_end >= cur_t.timestamp             
            if keep_looking:
                # still in same text block so bump the cur_state to because skipping a transition
                cur_state = self.get_state_after_transition(
                    cur_t.transition_code)

        return cur_state, next_t_index

    def set_ground_truth_label(self, target_session_id, is_strict_mode):
        first_message_log = f"Setting ground truth label for text block with session id {target_session_id}"
        LogWriters.log_general_session(
            first_message_log, self.current_session_id, 'i')

        # List of TextBlockEntity
        q_text_block = self.db_session.query(TextBlocksEntity).filter(
            TextBlocksEntity.session_id == target_session_id).all()
        if not self.there_text_block(q_text_block, target_session_id):
            return

        get_source_id = q_text_block[0].source_id
        # List of TransitionEntity
        q_transition_data = self.db_session.query(TransitionsEntity).filter(
            TransitionsEntity.source_id == get_source_id).all()
        if not self.there_transition_data(q_transition_data, get_source_id):
            return

        no_more_trans = False
        q_trans_data_index = 0
        cur_transition = q_transition_data[q_trans_data_index]
        cur_state = self.get_state_before_transition(cur_transition.transition_code)

        for tb in q_text_block:
            if (no_more_trans) or (tb.cur_chunk_start < cur_transition.timestamp and tb.cur_chunk_end < cur_transition.timestamp):
                # Text block is inside the trasition time
                # Update ground truth label of text block to cur_transition
                self.save_ground_truth_label(
                    tb.block_id, cur_state)

            elif (no_more_trans) or (tb.cur_chunk_start <= cur_transition.timestamp and tb.cur_chunk_end >= cur_transition.timestamp):
                # Text block overlaps with transition time
                # Get next state to use for setting tb.ground_truth_label based on the type of transition
                self.save_ground_truth_label(
                    tb.block_id, cur_transition.transition_code)
                
                cur_state, q_trans_data_index = self.find_next_trans(q_trans_data_index, q_transition_data, tb.cur_chunk_start, tb.cur_chunk_end)
                
                no_more_trans = ( (q_trans_data_index) >= len(q_transition_data))
                if no_more_trans:
                    cur_transition = None
                else:
                    cur_transition = q_transition_data[q_trans_data_index]


            elif (no_more_trans) or (tb.cur_chunk_start > cur_transition.timestamp):
                # Error case
                # if strict mode, raise exception
                # otherwise, try next textblock
                message = f"The start time [{tb.cur_chunk_start}] of text block with id {tb.block_id} overlaps with current transition timestamp [{cur_transition.timestamp}]"
                if is_strict_mode:
                    print(f"[ERROR] {message}")
                    LogWriters.log_general_error(message)
                    LogWriters.log_general_session(
                        message, self.current_session_id, 'e')
                    SessionData.modify_session_data(
                        self.db_session, self.current_session_id, 'e')
                    raise Exception(message)
                else:
                    LogWriters.log_general_warning(message)
                    LogWriters.log_general_session(
                        message, self.current_session_id, 'w')
                    SessionData.modify_session_data(
                        self.db_session, self.current_session_id, 'w')
                    print(f"[WARNING] {message}")
                    continue

        last_message_log = f"Finish setting ground truth label for text block with session id {target_session_id}"
        LogWriters.log_general_session(
            last_message_log, self.current_session_id, 'i')
        SessionData.modify_session_data(
            self.db_session, self.current_session_id, 's')
