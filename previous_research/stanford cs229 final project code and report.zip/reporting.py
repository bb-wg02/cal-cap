import json
import requests
from loguru import logger
import dataset
import arrow
from time import sleep
import copy
import matplotlib.pyplot as plt
import numpy as np
from sklearn import metrics
import sqlalchemy
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix
from sklearn.metrics import classification_report
import seaborn as sns

EXP_15s = '15 second v5'
EXP_30s = '30 second v4  decide again'

db = dataset.connect('sqlite:///db.db')

def get_bin_data_stage1(exp_name):
    q = 'SELECT l.response_classification_c, t.ground_truth_label_c'
    q = q + ' FROM text_blocks_table t, llm_predictions l'
    q = q + ' WHERE t.block_id = l.cur_block_id_used and l.response_classification_num <> 5 '    
    q = q + 'and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
    predicted=[]
    actual=[]    
    for row in rs:        
        predicted.append(row['response_classification_c'])
        actual.append(row['ground_truth_label_c'])    
    return predicted, actual


def get_multi_data_stage1(exp_name):
    q = 'SELECT l.response_classification_num, t.ground_truth_label_num'
    q = q + ' FROM text_blocks_table t, llm_predictions l'
    q = q + ' WHERE t.block_id = l.cur_block_id_used and l.response_classification_num <> 5 '    
    q = q + 'and l.llm_exp_name = :v_parameters order by t.session_id, t.sequence_num'
    
    rs = db.engine.execute(sqlalchemy.text(q), v_parameters=exp_name)
    predicted=[]
    actual=[]    
    for row in rs:        
        predicted.append(row['response_classification_num'])
        actual.append(row['ground_truth_label_num'])    
    return predicted, actual


def conf_mat_bin(exp_name):    
    predicted, actual = get_bin_data_stage1(exp_name)

    cm = confusion_matrix(actual, predicted)
    cm_df = pd.DataFrame(cm, index = ['YES','NO'],columns = ['YES','NO'])

    #Plotting the confusion matrix
    plt.figure(figsize=(10,8))
    sns.heatmap(cm_df, annot=True,  fmt=f'.{0}f')
    sns.heatmap(cm_df,
        vmin=cm_df.values.min(),
        vmax=cm_df.values.max(),
        square=True,
        cmap="YlGnBu",
        linewidths=0.1,
        annot=True,
        fmt=f'.{0}f',
        annot_kws={"size": 35 / np.sqrt(len(cm_df))})

    plt.title('Confusion Matrix for Commercial Detection (Yes/No)')
    plt.ylabel('Actual Values')
    plt.xlabel('Predicted Values')    

    fig_file = f"./output/conf_mat_bin_{exp_name}.png"
    plt.savefig(fig_file)
    #plt.show()
    #plt.clf()
    cl_rpt = classification_report(actual, predicted, target_names=cm_df)
    print(cl_rpt)
    bal_acc_score = balanced_accuracy_score( actual, predicted)
    print(f"balanced accuracy score: {bal_acc_score}")
    

def conf_mat_multi(exp_name):    
    predicted, actual = get_multi_data_stage1(exp_name)

    cm = confusion_matrix(actual, predicted)
    cm_df = pd.DataFrame(cm,
                     index = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB'], 
                     columns = ['SB','SB_to_C','C', 'C_to_C', 'C_to_SB']) 
    
    #Plotting the confusion matrix
    #plt.figure(figsize=(10,8))
    #sns.heatmap(cm_df, annot=True,  fmt=f'.{0}f')
    #sns.heatmap(cm_df,
    #    vmin=cm_df.values.min(),
    #    vmax=cm_df.values.max(),
    #    square=True,
     #   cmap="YlGnBu",
      #  linewidths=0.1,
      #  annot=True,
      #  fmt=f'.{0}f',
       # annot_kws={"size": 35 / np.sqrt(len(cm_df))})

    #plt.title('Confusion Matrix for Commercial Transitions')
    #plt.ylabel('Actual Values')
    #plt.xlabel('Predicted Values')    

    #fig_file = f"./output/conf_mat_multi_{exp_name}.png"
    #plt.savefig(fig_file)
    #plt.show()
    #plt.clf()
    cl_rpt = classification_report(actual, predicted, target_names=cm_df)
    print(cl_rpt)    
    bal_acc_score = balanced_accuracy_score( actual, predicted)
    print(f"balanced accuracy score: {bal_acc_score}")

#conf_mat_multi(EXP_30s)
#print('after conf_mat reached')
conf_mat_bin(EXP_15s)
