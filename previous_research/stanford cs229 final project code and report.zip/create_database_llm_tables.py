import pandas as pd
from loguru import logger
import dataset
import arrow

db = dataset.connect('sqlite:///db.db')

# blocks = db.create_table('primary_vs_secondary_blocks', primary_id='block_id')
# blocks.create_column('session_id', db.types.integer)
# blocks.create_column('trans_dt', db.types.datetime)
# blocks.create_column('source_id', db.types.integer)
# blocks.create_column('cur_chunk_text', db.types.text)
# blocks.create_column('cur_chunk_start', db.types.text)
# blocks.create_column('cur_chunk_end', db.types.text)
# blocks.create_column('merged_chunk', db.types.text)
# blocks.create_column('sec_since_start', db.types.text)
# blocks.create_column('secs_since_last_p', db.types.text)
# blocks.create_column('secs_since_last_c', db.types.text)
# blocks.create_column('num_p_blocks', db.types.text)
# blocks.create_column('num_s_blocks', db.types.text)
# blocks.create_column('prediction', db.types.text)
# blocks.create_column('ground_truth_label', db.types.text)
#
# df = pd.read_excel('sample_input_to_LLM.xlsx', sheet_name='text_blocks', parse_dates=['trans_dt'])
# df.fillna('', inplace=True)
# for row in df.to_dict('records'):
#     row['trans_dt'] = arrow.get(row['trans_dt']).datetime
#     logger.info(row)
#     try:
#         blocks.insert(row)
#     except Exception as e:
#         logger.error(e)

llm_predictions = db.create_table('llm_predictions', primary_id='llm_predict_id')
llm_predictions.create_column('instr_prompt_used_name', db.types.text)
llm_predictions.create_column('instr_prompt_used_text', db.types.text)
llm_predictions.create_column('cur_block_id_used', db.types.text)
llm_predictions.create_column('text_chunk_used', db.types.text)
llm_predictions.create_column('llm_name', db.types.text)
llm_predictions.create_column('llm_other_params', db.types.text)
llm_predictions.create_column('fully_formed_request', db.types.text)
llm_predictions.create_column('requested_at', db.types.datetime)
llm_predictions.create_column('response_is_valid', db.types.boolean)
llm_predictions.create_column('response_text', db.types.text)
llm_predictions.create_column('requested_at', db.types.datetime)
llm_predictions.create_column('response_classification', db.types.text)
llm_predictions.create_column('response_confidence', db.types.text)
llm_predictions.create_column('response_at', db.types.datetime)
llm_predictions.create_column('code', db.types.text)
llm_predictions.create_column('response_confidence', db.types.integer)
llm_predictions.create_column('input_tokens', db.types.integer)
llm_predictions.create_column('output_tokens', db.types.integer)
llm_predictions.create_column('sports_broadcasting_streak', db.types.integer),
llm_predictions.create_column('commercial_streak', db.types.integer),
llm_predictions.create_column('sb_to_c_streak', db.types.integer),
llm_predictions.create_column('c_to_c_streak', db.types.integer),
llm_predictions.create_column('c_to_sb_streak', db.types.integer),
llm_predictions.create_column('c_blocks_so_far', db.types.integer),
llm_predictions.create_column('sb_blocks_so_far', db.types.integer),
llm_predictions.create_column('num_blocks_since_sb', db.types.integer),
llm_predictions.create_column('num_blocks_since_c', db.types.integer),
llm_predictions.create_column('llm_exp_name', db.types.text),
llm_predictions.create_column('response_classification_num', db.types.integer),
llm_predictions.create_column('other_blocks_so_far', db.types.integer),
llm_predictions.create_column('other_streak', db.types.integer),
llm_predictions.create_column('response_classification_c', db.types.integer)

instruction_prompts = db.create_table('instruction_prompts', primary_id='instr_id')
instruction_prompts.create_column('instr_name', db.types.text)
instruction_prompts.create_column('instr_descr', db.types.text)
instruction_prompts.create_column('instr_text', db.types.text)
instruction_prompts.create_column('last_modify_dt', db.types.datetime)
instruction_prompts.create_column('default_ind', db.types.boolean)
instruction_prompts.delete()
instruction_prompts.insert(
    {
        'instr_id': 1,
        'instr_name': 'standard',
        'instr_descr': 'standard default instructions',
        'instr_text': "Evaluate the following text in between the sets of double quotation marks and tell me if you think it represents text from a TV commercial or commentary from a sports broadcast or a combination of a sports broadcast and a commercial. While evaluating the text, account for the possibility of the beginning and ending of the text being only partial sentences.  Answer with one of these five phrases marked in single quotes and no other words: 'Commercial', 'Sports Broadcast', 'Commercial Followed By A Sports Broadcast', 'Sports Broadcast Followed By A Commercial', 'Commercial Then A Second Commercial', 'Not a Commercial and not a Sports Broadcast'",
        'last_modify_dt': arrow.now().date(),
        'default_ind': True,
    }
)