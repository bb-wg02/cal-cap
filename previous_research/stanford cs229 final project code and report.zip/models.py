# -*- coding: utf-8 -*-

# region Description
"""
models.py: Database schema for text_blocks, session and source
"""
# endregion

from sqlalchemy import Column, String, Integer, Float, Time, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class SourceEntity(Base):
    __tablename__ = "source_table"
    source_id = Column("source_id", Integer, primary_key=True)
    file_name = Column("file_name", String)
    file_path = Column("file_path", String)
    description = Column("description", String)  # Leave blank
    last_modified = Column("last_modified", DateTime)  # Datetime
    category = Column("category", String)  # Leave blank
    sub_category = Column("sub_category", String)  # Leave blank

    def __init__(self, source_id, file_name, file_path, description, last_modified, category, sub_category):
        self.source_id = source_id
        self.file_name = file_name
        self.file_path = file_path
        self.description = description
        self.last_modified = last_modified
        self.category = category
        self.sub_category = sub_category


class SessionEntity(Base):
    __tablename__ = "session_table"
    session_id = Column("session_id", Integer, primary_key=True)
    # Window size will also be a command line parameter
    cur_chunk_window = Column("cur_chunk_window", Float)
    # Default to 1 but take a command line parameter to set it optionally
    num_prev_chunks = Column("num_prev_chunks", Float)
    # Leave blank
    default_ind = Column("default_ind", Boolean)
    # Time of the start of the session (Datetime)
    session_time = Column("session_time", DateTime, default=datetime.now)
    # Status about the session, 'r' for running, 's' for succeeding, 'w' for warning, 'e' for errors
    completion_status_ind = Column("completion_status_ind", String)
    # The command executed for each session
    command = Column("command", String)
    # Log files include warnings and informational messages as milestones in the program are reached
    session_log_filename = Column("session_log_filename", String)
    session_log_filepath = Column("session_log_filepath", String)

    def __init__(self, session_id, cur_chunk_window, num_prev_chunks, default_ind,  completion_status_ind, command, session_log_filename, session_log_filepath):
        self.session_id = session_id
        self.cur_chunk_window = cur_chunk_window
        self.num_prev_chunks = num_prev_chunks
        self.default_ind = default_ind
        self.completion_status_ind = completion_status_ind
        self.command = command
        self.session_log_filename = session_log_filename
        self.session_log_filepath = session_log_filepath


class TextBlocksEntity(Base):
    __tablename__ = "text_blocks_table"
    block_id = Column("block_id", Integer, primary_key=True)

    # A link to a table that describes details of parameters used and input file
    session_id = Column("session_id", Integer)
    # The order in the sequence of blocks
    sequence_num = Column("sequence_num", Integer)
    # Date of transcript (Datetime)
    trans_dt = Column("trans_dt", DateTime, default=datetime.now)
    # Link to another table holding the description of the event and other details
    source_id = Column("source_id", Integer)
    # This is a portion of the transcript text within the time window
    cur_chunk = Column("cur_chunk", String)
    # Current Text Chunk Start Timestamp relative to the start of the transcript (Datetime)
    cur_chunk_start = Column("cur_chunk_start", Time)
    # Current Text Chunk End Timestamp (Datetime)
    cur_chunk_end = Column("cur_chunk_end", Time)
    ground_truth_label = Column("ground_truth_label", String)
    ground_truth_label_num = Column("ground_truth_label_num", Integer)
    ground_truth_label_c = Column("ground_truth_label_c", Integer)

    def get_class_num(self,class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 2
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 3
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 4
        elif class_code == 'OTHER':
            return 5

    def get_class_c(self,class_code):
        if class_code == 'SPORTS_BROADCASTING':
            return 0
        elif class_code == 'SPORTS_BROADCASTING-TO-COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-ANOTHER COMMERCIAL':
            return 1
        elif class_code == 'COMMERCIAL-TO-SPORTS_BROADCASTING':
            return 1
        elif class_code == 'OTHER':
            return 0

    def __init__(self, block_id, session_id, sequence_num, source_id, cur_chunk, cur_chunk_start, cur_chunk_end, ground_truth_label, ground_truth_label_num,ground_truth_label_c):
        self.block_id = block_id
        self.session_id = session_id
        self.sequence_num = sequence_num
        self.source_id = source_id
        self.cur_chunk = cur_chunk
        self.cur_chunk_start = cur_chunk_start
        self.cur_chunk_end = cur_chunk_end
        self.ground_truth_label = ground_truth_label
        self.ground_truth_label_num = self.get_class_num(ground_truth_label)
        self.ground_truth_label_c = self.get_class_c(ground_truth_label)


class TransitionsEntity(Base):
    __tablename__ = "transitions_table"
    transition_id = Column("transition_id", Integer, primary_key=True)

    transition_code = Column("transition_code", String)
    timestamp = Column("timestamp", Time)
    transition_excel_filename = Column("transition_excel_filename", String)
    transition_excel_filepath = Column("transition_excel_filepath", String)
    source_filename = Column("source_filename", String)
    source_file_path = Column("source_file_path", String)
    last_modify_dt = Column("last_modify_dt", DateTime)
    source_id = Column("source_id", Integer)

    def __init__(self, transition_id, transition_code, timestamp, transition_excel_filename, transition_excel_filepath, source_filename, source_file_path, last_modify_dt, source_id):
        self.transition_id = transition_id
        self.transition_code = transition_code
        self.timestamp = timestamp
        self.transition_excel_filename = transition_excel_filename
        self.transition_excel_filepath = transition_excel_filepath
        self.source_filename = source_filename
        self.source_file_path = source_file_path
        self.last_modify_dt = last_modify_dt
        self.source_id = source_id
